@echo off
REM Run from repository root on Windows/Anaconda Prompt.
python 01_pipeline\scripts\00_check_inputs.py
python 01_pipeline\scripts\run_base_publicTE_pipeline.py
REM For proteomics on Windows, extract data_assets\Heffner_minimal.tsv.gz manually or use 7-Zip.
python 01_pipeline\scripts\run_heffner_ncbi_mapped_multiomics_pipeline.py
python 01_pipeline\scripts\run_plot_multiomics_distributions.py
python 01_pipeline\scripts\run_heavy_rnafold_kmer6_automl.py
python 01_pipeline\scripts\run_jaccard_2000_full_pipeline.py
echo DONE. Final library: 07_library_design\tables\selected_2000_50_100bp_cluster_diverse_evidence_balanced_library.csv
