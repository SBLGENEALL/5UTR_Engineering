# CHO 5′UTR Engineering Pipeline — Final Release

이 repository는 CHO genome/TSS/Ribo-seq/RNA-seq/proteomics 정보를 통합해 **50–100 bp 5′UTR 후보 2000개**를 선별하기 위한 최종본입니다.

## 최종 결론

- regression으로 정확한 1등~2000등 순위를 예측하는 모델이 아니라, **high/low 후보군 enrichment + bad candidate filtering** 용도로 모델을 사용합니다.
- 최종 library는 prediction top list가 아니라 **public TE, proteomics abundance, protein/RNA residual, classifier score, TSS support, sequence QC, Jaccard diversity**를 quota로 균형 있게 반영합니다.
- 최종 산출물은 `07_library_design/tables/selected_2000_50_100bp_cluster_diverse_evidence_balanced_library.csv`입니다.

## 빠른 실행 순서

```bash
conda activate /home/MCET03/conda_envs/utr_env
cd /home/MCET03/03_ChatGPT_5UTR_pipeline

# 0. 입력 파일 확인
python 01_pipeline/scripts/00_check_inputs.py

# 1. NCBI/TSS/RNA/Ribo 기반 public TE pipeline
python 01_pipeline/scripts/run_base_publicTE_pipeline.py

# 2. Heffner proteomics/multiomics 통합
# Heffner_minimal.tsv.gz는 data_assets/에 포함. 아래처럼 해제해 사용.
gunzip -c data_assets/Heffner_minimal.tsv.gz > 00_raw_data/05_cho_proteomics/Heffner_minimal.tsv
python 01_pipeline/scripts/run_heffner_ncbi_mapped_multiomics_pipeline.py

# 3. 분포 QC
python 01_pipeline/scripts/run_plot_multiomics_distributions.py

# 4. heavy RNAfold/k-mer6/tree2000 모델
python 01_pipeline/scripts/run_heavy_rnafold_kmer6_automl.py

# 5. Jaccard cluster + cluster-aware benchmark + 최종 2000개 선별
python 01_pipeline/scripts/run_jaccard_2000_full_pipeline.py
```

## 핵심 결과 파일

| 구분 | 파일 | 의미 |
|---|---|---|
| public TE label | `04_te_labeling/tables/tss_corrected_5utr_robust_public_te_labels.csv` | Ribo/RNA 기반 TE proxy rank |
| proteomics mapping | `00_raw_data/05_cho_proteomics/Heffner_2020_CHO_hamster_proteomics_ncbi_mapped_for_5utr.csv` | Heffner proteomics abundance proxy를 NCBI gene에 매핑 |
| multiomics label | `04_te_labeling/tables/tss_corrected_5utr_multiomics_labels.csv` | TE + protein abundance + protein/RNA residual 통합 label |
| distribution QC | `04_te_labeling/qc/multiomics_distribution_qc_summary.txt` | multiomics/proteomics 분포 및 coverage 해석 |
| cluster benchmark | `06_modeling/tables/cluster_aware_classification_benchmark.csv` | gene/sequence-cluster split 성능 |
| final library | `07_library_design/tables/selected_2000_50_100bp_cluster_diverse_evidence_balanced_library.csv` | 최종 합성 후보 2000개 |
| final FASTA | `07_library_design/fasta/selected_2000_50_100bp_cluster_diverse_evidence_balanced_library.fasta` | 합성/주문용 FASTA |

## 문서

- `docs/FINAL_RUNBOOK.md`: 전체 실행 순서와 결과 해석
- `docs/SCRIPT_CATALOG.md`: 스크립트별 역할/입력/출력
- `docs/RESULT_INTERPRETATION.md`: TE/proteomics/protein residual/ROC-AUC/Jaccard 해석
- `docs/GITHUB_RELEASE_GUIDE.md`: GitHub 업로드/배포 방법
- `docs/ARCHIVE_POLICY.md`: 어떤 파일을 archive로 옮길지 기준

## 정리 원칙

- scripts 폴더에는 최종 실행에 필요한 파일만 남깁니다.
- 과거 시행착오 파일은 삭제하지 않고 `99_archive/final_cleanup_<timestamp>/`로 이동합니다.
- `tools/finalize_repo.py --dry-run`으로 먼저 확인하고, `--apply`로 실제 이동합니다.
