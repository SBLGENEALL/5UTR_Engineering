# NatureComm-style k=5 / tree=1500 benchmark patch

This patch tests whether the current model underperformance is due to hyperparameters.

Your latest fast sensitivity benchmark used:

```text
k_values = (3, 4)
n_estimators = 350
```

This patch tests:

```text
k-mer = 5
k-mer = 3+4+5
n_estimators = 1500
RandomForest / ExtraTrees
full sequence / tail100 / pad100
optional one-hot 100 bp representation
regression + top/bottom classification
```

## Run quick focused benchmark

```bat
python 01_pipeline\scripts\run_naturecomm_style_k5_tree1500_fast.py
```

or:

```bat
python 01_pipeline\scripts\15_naturecomm_style_k5_tree1500_benchmark.py --fast
```

## Run full benchmark

This can take a long time:

```bat
python 01_pipeline\scripts\15_naturecomm_style_k5_tree1500_benchmark.py
```

## Outputs

```text
06_modeling/tables/naturecomm_style_k5_tree1500_regression_results.csv
06_modeling/tables/naturecomm_style_k5_tree1500_classification_results.csv
06_modeling/tables/naturecomm_style_k5_tree1500_summary.txt
06_modeling/plots/naturecomm_style_gene_split_spearman.png
```

## Interpretation

If this improves gene_split Spearman/top10 enrichment over the current ~0.28:

```text
Use k=5 + n_estimators=1500 model for final scoring.
```

If it does not improve:

```text
The limitation is likely label/source/context, not tree count or k-mer setting.
```

Cell type one-hot is not directly applicable unless multiple true cell-type-specific TE labels are available. In this CHO-only pipeline, fixed 100 bp one-hot sequence representation is tested instead.
