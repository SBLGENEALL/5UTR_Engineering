# CHO 5′ UTR full reproducible package with proteomics high/low prediction plots

이 패키지는 오늘 진행한 전체 과정을 회사에서 다시 재현하기 위한 통합본입니다.

포함 범위:

```text
1. 필요한 database/raw data 다운로드
2. CHO genome/GFF에서 5′ UTR annotation 추출
3. TSS atlas 기반 5′ UTR 보정
4. GSE79512 RNA/Ribo-seq count 기반 TE mapping
5. robust_public_te_rank 생성
6. Heffner CHO proteomics 다운로드
7. NCBI gene2accession/gene_info 기반 proteomics accession → GeneID/Symbol mapping
8. protein_abundance_rank / protein_residual_rank 생성
9. multi_omics_utr_rank 생성
10. 여러 filter/window/feature/model/target AutoML-AutoRank benchmark
11. proteomics abundance high/low 실제 gene-split 예측 plot 생성
12. publicTE/proteomics/AutoML/hybrid 최종 1000개 후보 library 생성
```

---

## 0. 새 프로젝트 폴더 만들기

예시:

```bat
mkdir C:\CHO_5UTR_company_test
cd C:\CHO_5UTR_company_test
```

압축을 푼 뒤 `template_project` 안의 내용을 `C:\CHO_5UTR_company_test`에 복사하세요.

---

## 1. 데이터 다운로드

```bat
python 01_pipeline\scripts\00_download_all_databases.py
python 01_pipeline\scripts\00_check_inputs.py
```

다운로드되는 주요 데이터:

```text
NCBI CriGri-PICR genome FASTA
NCBI CriGri-PICR GFF annotation
GSE159044 eTSS NCBI PICR BED
GSE79512 RNA-seq raw count
GSE79512 Ribo-seq raw count
Heffner 2020 CHO proteomics Supplementary Table
NCBI gene2accession.gz
NCBI gene_info.gz
```

---

## 2. CHO genome에서 5′ UTR annotation → TSS correction → public TE mapping

```bat
python 01_pipeline\scripts\run_base_publicTE_pipeline.py
```

주요 output:

```text
02_utr_database\tables\ncbi_annotation_5utr_candidates.csv
03_tss_correction\tables\tss_corrected_5utr_database.csv
04_te_labeling\tables\tss_corrected_5utr_robust_public_te_labels.csv
06_modeling\tables\modeling_summary_train_40_200bp.txt
07_library_design\tables\selected_1000_50_100bp_publicTE_40_200train_model_assisted_library.csv
```

---

## 3. Proteomics mapping + multi-omics label 생성

```bat
python 01_pipeline\scripts\run_heffner_ncbi_mapped_multiomics_pipeline.py
```

주요 output:

```text
00_raw_data\05_cho_proteomics\Heffner_2020_CHO_hamster_proteomics_ncbi_mapped_for_5utr.csv
04_te_labeling\tables\tss_corrected_5utr_multiomics_labels.csv
04_te_labeling\qc\proteomics_mapping_summary.txt
06_modeling\tables\multiomics_model_summary_40_200bp.txt
07_library_design\tables\selected_1000_50_100bp_multiomics_proteomics_library.csv
```

---

## 4. AutoML / AutoRank

빠른 실행:

```bat
python 01_pipeline\scripts\run_automl_autorank_quick.py
```

full tree=1500 실행:

```bat
python 01_pipeline\scripts\run_automl_autorank_full_tree1500.py
```

주요 output:

```text
06_modeling\tables\automl_autorank_model_search_results.csv
06_modeling\tables\automl_autorank_selected_model_weights.csv
06_modeling\tables\automl_autorank_50_100_candidate_scores.csv
06_modeling\tables\automl_autorank_summary.txt
07_library_design\tables\selected_1000_50_100bp_AUTOML_autorank_library.csv
```

---

## 5. Proteomics abundance high/low 실제 예측 plot

protein abundance high/low:

```bat
python 01_pipeline\scripts\run_plot_proteomics_abundance_highlow.py
```

protein residual high/low:

```bat
python 01_pipeline\scripts\run_plot_proteomics_residual_highlow.py
```

생성되는 plot:

```text
06_modeling\plots\proteomics_abundance_highlow\proteomics_protein_abundance_rank_highlow_probability_by_actual_class.png
06_modeling\plots\proteomics_abundance_highlow\proteomics_protein_abundance_rank_highlow_ROC.png
06_modeling\plots\proteomics_abundance_highlow\proteomics_protein_abundance_rank_highlow_precision_recall.png
06_modeling\plots\proteomics_abundance_highlow\proteomics_protein_abundance_rank_regression_predicted_vs_true.png
06_modeling\plots\proteomics_abundance_highlow\proteomics_protein_abundance_rank_highlow_probability_histogram.png
```

생성되는 prediction table:

```text
06_modeling\tables\proteomics_protein_abundance_rank_highlow_classifier_gene_split_predictions.csv
06_modeling\tables\proteomics_protein_abundance_rank_regression_gene_split_predictions.csv
06_modeling\tables\proteomics_protein_abundance_rank_prediction_plot_summary.txt
```

---

## 6. 최종 후보 library 생성

proteomics-enriched:

```bat
python 01_pipeline\scripts\run_select_proteomics_enriched_library.py
```

hybrid final 3종:

```bat
python 01_pipeline\scripts\run_make_hybrid_final_libraries.py
```

주요 output:

```text
07_library_design\tables\selected_1000_50_100bp_proteomics_enriched_library.csv

07_library_design\tables\selected_1000_50_100bp_HYBRID_conservative_publicTE_proteomics.csv
07_library_design\tables\selected_1000_50_100bp_HYBRID_balanced_publicTE_proteomics.csv
07_library_design\tables\selected_1000_50_100bp_HYBRID_exploratory_publicTE_proteomics.csv
```

추천 기본 후보:

```text
selected_1000_50_100bp_HYBRID_balanced_publicTE_proteomics.csv
```

또는 AutoML 중심 후보:

```text
selected_1000_50_100bp_AUTOML_autorank_library.csv
```

---

## 7. 전체 한 번에 실행

```bat
python 01_pipeline\scripts\run_complete_company_workflow_with_plots.py
```

또는:

```bat
RUN_ALL_complete_company_workflow.bat
```

---

## 해석 포인트

1. `gene_split` 결과를 기준으로 보세요. random split은 과대평가될 수 있습니다.
2. public TE regression은 대략 Spearman 0.27–0.28 근처가 ceiling일 수 있습니다.
3. proteomics abundance high/low는 classification 쪽에서 더 유용합니다.
4. 최종 후보는 model score 단독이 아니라 public TE + proteomics + AutoML ensemble + QC로 결정하는 것이 안전합니다.
5. 최종 합성 전에는 duplicate, restriction site, uAUG, GC, length QC를 다시 확인하세요.
