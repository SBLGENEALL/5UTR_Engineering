# CHO 5′ UTR company reproducible package

이 패키지는 집에서 진행한 과정을 회사에서 다시 재현하기 위한 clean template입니다.

데이터 파일 자체는 포함하지 않고, 다운로드 스크립트와 실행 스크립트만 포함합니다.

---

## 0. 새 프로젝트 폴더 만들기

Windows Anaconda Prompt:

```bat
mkdir C:\CHO_5UTR_company_test
cd C:\CHO_5UTR_company_test
```

압축을 풀고 `template_project` 안의 내용을 이 폴더에 복사하세요.

최종 구조:

```text
C:\CHO_5UTR_company_test
├─00_raw_data
├─01_pipeline
├─02_utr_database
├─03_tss_correction
├─04_te_labeling
├─05_feature_extraction
├─06_modeling
└─07_library_design
```

Linux/MobaXterm:

```bash
mkdir -p ~/CHO_5UTR_company_test
cd ~/CHO_5UTR_company_test
cp -r /path/to/template_project/* .
```

---

## 1. 필요한 DB/data 다운로드

```bat
python 01_pipeline\scripts\00_download_all_databases.py
```

다운로드 항목:

```text
NCBI CriGri-PICR genome FASTA
NCBI CriGri-PICR GFF annotation
GSE159044 eTSS NCBI PICR BED
GSE79512 RNA-seq raw count
GSE79512 Ribo-seq raw count
Heffner 2020 CHO proteomics supplementary table
NCBI gene2accession.gz
NCBI gene_info.gz
```

입력파일 확인:

```bat
python 01_pipeline\scripts\00_check_inputs.py
```

---

## 2. Base public TE pipeline 실행

```bat
python 01_pipeline\scripts\run_base_publicTE_pipeline.py
```

생성되는 주요 결과:

```text
02_utr_database\tables\ncbi_annotation_5utr_candidates.csv
03_tss_correction\tables\tss_corrected_5utr_database.csv
04_te_labeling\tables\tss_corrected_5utr_robust_public_te_labels.csv
05_feature_extraction\tables\ml_feature_table_train_40_200bp.csv
06_modeling\tables\modeling_summary_train_40_200bp.txt
07_library_design\tables\selected_1000_50_100bp_publicTE_40_200train_model_assisted_library.csv
```

---

## 3. RNAfold/fixed representation benchmark 실행

회사 서버에서 RNAfold가 잡혀 있으면:

```bat
python 01_pipeline\scripts\07_benchmark_model_strategies_FIXED.py --rnafold
```

결과:

```text
06_modeling\tables\improved_model_benchmark_summary_FIXED.txt
06_modeling\tables\model_strategy_benchmark_regression_FIXED.csv
06_modeling\tables\model_strategy_benchmark_classification_FIXED.csv
```

이전 결과 기준으로 해석:

```text
Regression: Spearman ~0.28 수준
Classification: ROC-AUC ~0.73까지 개선 가능
```

---

## 4. Heffner proteomics + NCBI mapping + multi-omics 실행

```bat
python 01_pipeline\scripts\run_heffner_ncbi_mapped_multiomics_pipeline.py
```

이 스크립트는 아래를 자동 수행합니다.

```text
Heffner numeric Accession/protein GI
→ NCBI gene2accession GeneID
→ NCBI gene_info Symbol
→ UTR gene_id/gene_name mapping
→ abundance_proxy 생성
→ multi_omics_utr_rank 생성
→ multi-omics model 학습
→ proteomics-assisted 1000개 후보 선별
```

결과:

```text
00_raw_data\05_cho_proteomics\Heffner_2020_CHO_hamster_proteomics_ncbi_mapped_report.txt
04_te_labeling\qc\proteomics_mapping_summary.txt
06_modeling\tables\multiomics_model_summary_40_200bp.txt
07_library_design\tables\selected_1000_50_100bp_multiomics_proteomics_library.csv
07_library_design\fasta\selected_1000_50_100bp_multiomics_proteomics_library.fasta
```

---

## 5. 전체 한 번에 실행

회사 환경에서 인터넷과 RNAfold가 모두 준비되어 있으면:

```bat
python 01_pipeline\scripts\run_all_company_reproducible.py
```

또는 Windows에서:

```bat
RUN_ALL_company.bat
```

Linux/MobaXterm:

```bash
bash run_all_company.sh
```

---

## 6. 최종 후보 파일 비교

Base public TE library:

```text
07_library_design\tables\selected_1000_50_100bp_publicTE_40_200train_model_assisted_library.csv
```

Proteomics-assisted multi-omics library:

```text
07_library_design\tables\selected_1000_50_100bp_multiomics_proteomics_library.csv
```

Benchmark model prediction:

```text
06_modeling\tables\improved_model_predictions_50_100bp_FIXED.csv
```

---

## 7. 주의사항

1. `gene_split` 성능을 기준으로 판단하세요. random split은 과대평가됩니다.
2. RNAfold는 regression rank보다 high/low classification에 더 도움이 되는 것으로 보입니다.
3. Heffner proteomics는 true absolute abundance가 아니라 PSM/peptide 기반 `abundance_proxy`입니다.
4. Proteomics는 main label이 아니라 supporting prior입니다.
5. 최종 합성 전에는 반드시 length, GC, uAUG, duplicate, restriction site QC를 다시 확인하세요.
