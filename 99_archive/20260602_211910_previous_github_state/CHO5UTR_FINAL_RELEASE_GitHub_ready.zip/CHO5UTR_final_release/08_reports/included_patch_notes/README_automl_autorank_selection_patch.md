# AutoML / AutoRank selection patch

This patch lets the data choose the best modeling/selection strategy instead of manually deciding filter, k-mer, model, target, and evidence weights.

## What it searches

Filters/windows:

```text
50_100_strict
40_200_strict
20_300_relaxed
20_500_relaxed
proteomics_20_500_relaxed
```

Feature strategies:

```text
full_k5
full_k345
tail100_k5_plus_fullk5
tail100_k5_onehot
pad100_k5_onehot
```

Targets:

```text
robust_public_te_rank
multi_omics_utr_rank
protein_residual_rank
protein_abundance_rank
```

Models:

```text
RandomForest
ExtraTrees
HistGradientBoosting
```

Tasks:

```text
rank regression
high-vs-low classification
```

Validation:

```text
gene_split is the main model-selection criterion
random split is saved for debugging only
```

## Quick run

Recommended first:

```bat
python 01_pipeline\scripts\run_automl_autorank_quick.py
```

Equivalent:

```bat
python 01_pipeline\scripts\16_automl_autorank_selection.py --mode quick --top-models 8
```

## Full tree-1500 run

Slower, closer to your previous Nature Comm-style setting:

```bat
python 01_pipeline\scripts\run_automl_autorank_full_tree1500.py
```

Equivalent:

```bat
python 01_pipeline\scripts\16_automl_autorank_selection.py --mode full --n-estimators 1500 --top-models 12
```

## Outputs

```text
06_modeling/tables/automl_autorank_model_search_results.csv
06_modeling/tables/automl_autorank_selected_model_weights.csv
06_modeling/tables/automl_autorank_50_100_candidate_scores.csv
06_modeling/tables/automl_autorank_summary.txt
06_modeling/plots/automl_autorank_gene_split_performance.png

07_library_design/tables/selected_1000_50_100bp_AUTOML_autorank_library.csv
07_library_design/fasta/selected_1000_50_100bp_AUTOML_autorank_library.fasta
07_library_design/qc/selected_1000_50_100bp_AUTOML_autorank_summary.txt
```

## Important interpretation

This is not magic. If validation remains around Spearman ~0.28 and classification AUC ~0.7, that means the public/proteomics labels are noisy proxies. But the AutoRank approach is still better than manual weighting because it:

1. compares many possible models under gene_split validation,
2. selects top-performing models,
3. ensembles them,
4. uses the ensemble as one component of final candidate selection,
5. still preserves robust public TE and proteomics evidence.
