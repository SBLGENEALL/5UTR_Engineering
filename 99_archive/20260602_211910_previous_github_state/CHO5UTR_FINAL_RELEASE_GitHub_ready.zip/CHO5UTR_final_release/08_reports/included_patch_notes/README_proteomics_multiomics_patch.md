# CHO 5′ UTR proteomics / multi-omics patch

This patch adds CHO proteomics information to the existing robust public TE pipeline.

## Concept

Existing score:

```text
robust_public_te_rank
= Ribo/RNA TE + day consistency + residual TE + ribo abundance + TSS support
```

New score:

```text
multi_omics_utr_score
= robust public TE
+ protein/RNA residual rank
+ protein abundance rank
+ day consistency
+ TSS support
```

Protein data are used as a supporting prior, not as the only label.

---

## Folder

Put your CHO proteomics file here:

```text
00_raw_data/05_cho_proteomics/
```

Supported formats:

```text
.csv
.tsv
.txt
.xlsx
```

---

## Config

Copy:

```bat
copy 01_pipeline\config\proteomics_config.template.json 01_pipeline\config\proteomics_config.json
```

Edit:

```bat
notepad 01_pipeline\config\proteomics_config.json
```

Important fields:

```json
"proteomics_path": "00_raw_data/05_cho_proteomics/YOUR_FILE.csv",
"gene_symbol_column": "auto",
"abundance_columns": "auto"
```

If auto-detection fails, set them manually:

```json
"gene_symbol_column": "Gene names",
"abundance_columns": ["LFQ intensity Sample1", "LFQ intensity Sample2"]
```

---

## Inspect proteomics columns

```bat
python 01_pipeline\scripts\09_integrate_proteomics_multiomics.py --inspect
```

---

## Run full proteomics/multi-omics pipeline

This assumes you already have:

```text
04_te_labeling/tables/tss_corrected_5utr_robust_public_te_labels.csv
05_feature_extraction/tables/ml_feature_table_train_40_200bp.csv
```

Then run:

```bat
python 01_pipeline\scripts\run_proteomics_multiomics_pipeline.py
```

If the 40-200 feature table is missing, first run:

```bat
python 01_pipeline\scripts\04b_extract_features_train_40_200bp.py
```

---

## Outputs

```text
04_te_labeling/tables/tss_corrected_5utr_multiomics_labels.csv
04_te_labeling/qc/proteomics_mapping_summary.txt

06_modeling/tables/multiomics_model_summary_40_200bp.txt
06_modeling/tables/multiomics_model_predictions_40_200bp.csv
06_modeling/plots/multiomics_model_pred_vs_true.png

07_library_design/tables/selected_1000_50_100bp_multiomics_proteomics_library.csv
07_library_design/fasta/selected_1000_50_100bp_multiomics_proteomics_library.fasta
07_library_design/qc/selected_1000_50_100bp_multiomics_proteomics_summary.txt
```

---

## Interpretation

If many UTRs do not map to proteomics genes, the script falls back toward robust public TE rank for those rows. This prevents sparse proteomics coverage from destroying the candidate set.

Best use:

```text
robust public TE = main evidence
proteomics residual/protein abundance = additional prior
model score = weak tie-breaker
```
