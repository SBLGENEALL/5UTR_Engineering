# Proteomics-enriched selection patch

Use this after you have already generated:

```text
04_te_labeling/tables/tss_corrected_5utr_multiomics_labels.csv
```

## Why this patch is needed

The previous multi-omics rank was almost identical to robust public TE:

```text
Spearman(robust_public_te_rank, multi_omics_utr_rank) ≈ 0.98
```

This happens because only a subset of UTR rows have proteomics mapping, and missing proteomics values fall back to robust TE.

Therefore, proteomics should be used as a **forced quota / orthogonal prior**, not simply as a universal weighted rank.

## Run

```bat
python 01_pipeline\scripts\run_select_proteomics_enriched_library.py
```

or:

```bat
python 01_pipeline\scripts\12_select_1000_proteomics_enriched_orthogonal_library.py
```

## Outputs

```text
07_library_design/tables/selected_1000_50_100bp_proteomics_enriched_library.csv
07_library_design/fasta/selected_1000_50_100bp_proteomics_enriched_library.fasta
07_library_design/qc/selected_1000_50_100bp_proteomics_enriched_summary.txt
07_library_design/qc/overlap_publicTE_vs_proteomics_enriched.txt
```

## Selection structure

```text
A. mapped TE + protein consensus
B. protein/RNA residual high + TE supported
C. protein abundance high + TE supported
D. proteomics-orthogonal mid-TE candidates
E. TSS-supported mapped high candidates
F. high publicTE unmapped fill
G. low TE negative controls
```

The goal is not to maximize model Spearman. The goal is to create a biologically useful comparison library that is less redundant with the original publicTE-only library.
