# Hybrid final library patch

This patch creates three final candidate libraries by mixing:

1. publicTE main library
2. proteomics-enriched unique candidates
3. low-TE negative controls

It uses the overlap information between:

```text
selected_1000_50_100bp_publicTE_40_200train_model_assisted_library.csv
selected_1000_50_100bp_proteomics_enriched_library.csv
```

## Why

Your overlap was:

```text
overlap = 622 / 1000
publicTE_only = 378
proteomics_enriched_only = 378
```

This is ideal for hybrid design.

## Run

```bat
python 01_pipeline\scripts\run_make_hybrid_final_libraries.py
```

or:

```bat
python 01_pipeline\scripts\13_make_hybrid_final_libraries.py
```

## Output libraries

```text
selected_1000_50_100bp_HYBRID_conservative_publicTE_proteomics.csv
selected_1000_50_100bp_HYBRID_balanced_publicTE_proteomics.csv
selected_1000_50_100bp_HYBRID_exploratory_publicTE_proteomics.csv
```

## Schemes

```text
conservative: 800 publicTE + 175 proteomics-unique + 25 negative
balanced:     750 publicTE + 225 proteomics-unique + 25 negative
exploratory:  650 publicTE + 325 proteomics-unique + 25 negative
```

Recommended default:

```text
balanced
```
