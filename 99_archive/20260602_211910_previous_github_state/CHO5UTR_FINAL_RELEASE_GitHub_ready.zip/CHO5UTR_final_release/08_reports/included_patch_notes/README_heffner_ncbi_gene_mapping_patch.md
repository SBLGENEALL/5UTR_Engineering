# Heffner proteomics NCBI gene mapping patch

The Heffner table has numeric NCBI-like protein accessions, not gene symbols.
This patch downloads NCBI Gene mapping files and maps:

```text
Heffner Accession numeric protein_gi
→ NCBI gene2accession GeneID
→ NCBI gene_info Symbol
→ UTR label gene_id/gene_name
```

NCBI recommends using Gene FTP DATA conversion files such as `gene2accession.gz` and `gene_info.gz` to convert accessions to Gene IDs and official symbols.

## Apply

Merge the included `01_pipeline` folder into your project root.

## Run all

```bat
python 01_pipeline\scripts\run_heffner_ncbi_mapped_multiomics_pipeline.py
```

## Or step-by-step

```bat
python 01_pipeline\scripts\09b_download_ncbi_gene_mapping.py
python 01_pipeline\scripts\09c_preprocess_heffner_with_ncbi_gene_mapping.py
python 01_pipeline\scripts\09_integrate_proteomics_multiomics.py --inspect
python 01_pipeline\scripts\run_proteomics_multiomics_pipeline.py
```

## Outputs

```text
00_raw_data\05_cho_proteomics\ncbi_gene_mapping\gene2accession.gz
00_raw_data\05_cho_proteomics\ncbi_gene_mapping\gene_info.gz
00_raw_data\05_cho_proteomics\Heffner_2020_CHO_hamster_proteomics_ncbi_mapped_for_5utr.csv
00_raw_data\05_cho_proteomics\Heffner_2020_CHO_hamster_proteomics_ncbi_mapped_report.txt
04_te_labeling\qc\proteomics_mapping_summary.txt
07_library_design\tables\selected_1000_50_100bp_multiomics_proteomics_library.csv
```
