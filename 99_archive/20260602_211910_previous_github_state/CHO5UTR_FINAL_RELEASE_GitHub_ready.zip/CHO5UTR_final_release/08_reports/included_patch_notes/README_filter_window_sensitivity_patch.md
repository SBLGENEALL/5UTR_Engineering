# Filter/window sensitivity benchmark patch

This patch checks whether the current 50-100 bp + GC/uAUG hard filter is suppressing proteomics signal, and whether training on a wider/full UTR length range improves gene-split model performance.

## Why

Current observations:

```text
50-100 bp QC candidates: 3556
proteomics-mapped 50-100 candidates: 573
multi_omics_utr_rank is highly correlated with robust_public_te_rank: ~0.98
multi-omics regression did not improve over publicTE regression
```

So before choosing final 1000 candidates, test:

1. How many proteomics-mapped UTRs survive each filter/window
2. Whether relaxed windows improve model performance
3. Whether full/wider windows recover the previous stronger signal
4. Whether protein-specific targets have any sequence-predictable signal

## Run quick benchmark

```bat
python 01_pipeline\scripts\run_filter_window_sensitivity_fast.py
```

Equivalent:

```bat
python 01_pipeline\scripts\14_filter_window_sensitivity_benchmark.py --fast
```

## Run fuller benchmark

Slower but more complete:

```bat
python 01_pipeline\scripts\14_filter_window_sensitivity_benchmark.py
```

Include 20-1000 bp relaxed window:

```bat
python 01_pipeline\scripts\14_filter_window_sensitivity_benchmark.py --full
```

## Outputs

```text
04_te_labeling/qc/filter_window_proteomics_coverage_diagnostics.txt
06_modeling/tables/filter_window_sensitivity_results.csv
06_modeling/tables/filter_window_sensitivity_summary.txt
06_modeling/plots/filter_window_gene_split_spearman.png
```

## Interpretation

If 20-300 or 20-500 relaxed windows improve gene-split Spearman versus 40-200 strict:

```text
Use wider training range, but keep final selection 50-100 bp.
```

If proteomics-mapped rows increase strongly with relaxed windows but model does not improve:

```text
Proteomics is useful as a selection quota, not as a sequence-predictable label.
```

If protein_residual_rank target performs poorly:

```text
Protein/RNA residual is not directly predictable from 5' UTR sequence with this dataset.
```
