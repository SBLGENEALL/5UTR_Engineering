python 01_pipeline\scripts\00_download_all_databases.py
python 01_pipeline\scripts\00_check_inputs.py
pause
