#!/usr/bin/env bash
set -euo pipefail

# Usage: bash RUN_FINAL_MAIN.sh
# Run from repository root.

python 01_pipeline/scripts/00_check_inputs.py
python 01_pipeline/scripts/run_base_publicTE_pipeline.py

if [ -f data_assets/Heffner_minimal.tsv.gz ]; then
  mkdir -p 00_raw_data/05_cho_proteomics
  gunzip -c data_assets/Heffner_minimal.tsv.gz > 00_raw_data/05_cho_proteomics/Heffner_minimal.tsv
fi

python 01_pipeline/scripts/run_heffner_ncbi_mapped_multiomics_pipeline.py
python 01_pipeline/scripts/run_plot_multiomics_distributions.py
python 01_pipeline/scripts/run_heavy_rnafold_kmer6_automl.py
python 01_pipeline/scripts/run_jaccard_2000_full_pipeline.py

echo "DONE. Final library: 07_library_design/tables/selected_2000_50_100bp_cluster_diverse_evidence_balanced_library.csv"
