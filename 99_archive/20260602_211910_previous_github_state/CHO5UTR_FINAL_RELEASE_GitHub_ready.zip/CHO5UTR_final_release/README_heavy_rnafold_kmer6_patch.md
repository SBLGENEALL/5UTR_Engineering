# Heavy RNAfold + k-mer6 + tree2000 AutoML patch

This is the company-server high-compute version.

It uses:

```text
RNAfold MFE / MFE per nt
full sequence k-mer 3,4,5,6
tail100 k-mer 3,4,5
head100 k-mer 3,4,5
tail100 one-hot
ExtraTrees / RandomForest / HistGradientBoosting
n_estimators = 2000 for tree models
wide training windows:
  40-200 strict
  20-500 relaxed
  proteomics-only 20-500 relaxed
final selection:
  50-100 bp only
```

## Requirements

RNAfold must be available in PATH:

```bash
RNAfold --version
```

If not available, install/activate ViennaRNA first, or run the no-RNAfold fallback.

## Run high-performance version

From project root:

```bash
python 01_pipeline/scripts/run_heavy_rnafold_kmer6_automl.py
```

Direct command:

```bash
python 01_pipeline/scripts/18_heavy_rnafold_kmer6_automl.py --n-estimators 2000 --kmax 6 --top-models 12
```

## If RNAfold is not installed

```bash
python 01_pipeline/scripts/run_heavy_kmer6_no_rnafold.py
```

## Outputs

```text
06_modeling/tables/heavy_rnafold_kmer6_model_search_results.csv
06_modeling/tables/heavy_rnafold_kmer6_selected_model_weights.csv
06_modeling/tables/heavy_rnafold_kmer6_50_100_candidate_scores.csv
06_modeling/tables/heavy_rnafold_kmer6_summary.txt
06_modeling/plots/heavy_rnafold_kmer6_gene_split_performance.png

07_library_design/tables/selected_1000_50_100bp_HEAVY_RNAfold_kmer6_library.csv
07_library_design/fasta/selected_1000_50_100bp_HEAVY_RNAfold_kmer6_library.fasta
07_library_design/qc/selected_1000_50_100bp_HEAVY_RNAfold_kmer6_summary.txt
```

## Notes

This can take a long time. RNAfold results are cached in:

```text
05_feature_extraction/rnafold/rnafold_features_cache.csv
```

Reruns will be faster.
