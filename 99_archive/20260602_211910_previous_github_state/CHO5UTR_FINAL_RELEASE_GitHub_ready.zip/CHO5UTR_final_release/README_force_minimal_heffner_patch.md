# Force minimal Heffner CSV patch

This replaces 09c_preprocess_heffner_with_ncbi_gene_mapping.py.

It ignores the broken XLSX/multi-CSV auto-detection and only uses:

```text
00_raw_data/05_cho_proteomics/Heffner_minimal.csv
```

or

```text
00_raw_data/05_cho_proteomics/Heffner_minimal.tsv
```

## Make minimal file

First row should be exactly:

```text
Accession,GeneSymbol,PSMs,Peptides,UniquePeptides
```

or TSV:

```text
Accession<TAB>GeneSymbol<TAB>PSMs<TAB>Peptides<TAB>UniquePeptides
```

GeneSymbol is strongly recommended. If GeneSymbol is empty, mapping relies on NCBI gene2accession.

## Run

```bash
python 01_pipeline/scripts/09c_preprocess_heffner_with_ncbi_gene_mapping.py
```

Expected output:

```text
00_raw_data/05_cho_proteomics/Heffner_2020_CHO_hamster_proteomics_ncbi_mapped_for_5utr.csv
```
