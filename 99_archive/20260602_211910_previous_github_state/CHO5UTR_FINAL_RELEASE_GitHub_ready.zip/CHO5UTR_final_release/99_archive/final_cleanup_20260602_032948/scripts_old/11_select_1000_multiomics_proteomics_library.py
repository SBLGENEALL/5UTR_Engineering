from __future__ import annotations

from pathlib import Path
import json
import pandas as pd
import numpy as np

BASE = Path.cwd()
SEQ = "utr5_sequence_tss_corrected"

LABEL = BASE / "04_te_labeling/tables/tss_corrected_5utr_multiomics_labels.csv"
PRED = BASE / "06_modeling/tables/multiomics_model_predictions_40_200bp.csv"
OUT = BASE / "07_library_design/tables/selected_1000_50_100bp_multiomics_proteomics_library.csv"
FA = BASE / "07_library_design/fasta/selected_1000_50_100bp_multiomics_proteomics_library.fasta"
SUMMARY = BASE / "07_library_design/qc/selected_1000_50_100bp_multiomics_proteomics_summary.txt"

OUT.parent.mkdir(parents=True, exist_ok=True)
FA.parent.mkdir(parents=True, exist_ok=True)
SUMMARY.parent.mkdir(parents=True, exist_ok=True)


def clean_seq(x):
    if pd.isna(x):
        return ""
    return str(x).upper().replace("U", "T").replace(" ", "").replace("\n", "")


def gc_content(seq):
    seq = clean_seq(seq)
    return (seq.count("G") + seq.count("C")) / len(seq) if len(seq) else np.nan


def write_fasta(df, path, seq_col=SEQ, id_col="utr_id"):
    with open(path, "w", encoding="utf-8") as out:
        for i, r in df.iterrows():
            uid = str(r.get(id_col, f"row_{i}")).replace(" ", "_").replace("/", "_")
            seq = clean_seq(r[seq_col])
            out.write(f">{uid}\n")
            for j in range(0, len(seq), 80):
                out.write(seq[j:j+80] + "\n")


def has_forbidden(seq):
    sites = {
        "BsaI_GGTCTC": "GGTCTC",
        "BsaI_GAGACC": "GAGACC",
        "BsmBI_CGTCTC": "CGTCTC",
        "BsmBI_GAGACG": "GAGACG",
        "EcoRI_GAATTC": "GAATTC",
        "XhoI_CTCGAG": "CTCGAG",
        "NheI_GCTAGC": "GCTAGC",
        "AgeI_ACCGGT": "ACCGGT",
        "NotI_GCGGCCGC": "GCGGCCGC",
    }
    seq = clean_seq(seq)
    return ";".join([name for name, site in sites.items() if site in seq])


def main():
    if not LABEL.exists():
        raise SystemExit(f"Missing multiomics label table: {LABEL}")
    df = pd.read_csv(LABEL)
    df[SEQ] = df[SEQ].apply(clean_seq)

    if PRED.exists():
        pred = pd.read_csv(PRED)[["utr_id", "multiomics_model_pred_rank"]].drop_duplicates("utr_id")
        df = df.merge(pred, on="utr_id", how="left")
    else:
        df["multiomics_model_pred_rank"] = np.nan

    if "utr5_length_final" in df.columns:
        df["length"] = df["utr5_length_final"]
    elif "utr5_length_tss_corrected" in df.columns:
        df["length"] = df["utr5_length_tss_corrected"]
    else:
        df["length"] = df[SEQ].str.len()

    if "gc_content" not in df.columns:
        df["gc_content"] = df[SEQ].apply(gc_content)
    if "uaug_count" not in df.columns:
        df["uaug_count"] = df[SEQ].str.count("ATG")

    df["forbidden_sites"] = df[SEQ].apply(has_forbidden)
    df["has_forbidden_site"] = df["forbidden_sites"].astype(str).str.len() > 0

    df["multiomics_model_pred_rank"] = df["multiomics_model_pred_rank"].fillna(df["multi_omics_utr_rank"])

    # Protein evidence is helpful but may be sparse; keep public TE dominant.
    df["final_multiomics_selection_score"] = (
        0.45 * df["multi_omics_utr_rank"].fillna(0)
        + 0.25 * df["robust_public_te_rank"].fillna(0)
        + 0.10 * df["protein_residual_rank"].fillna(df["robust_public_te_rank"]).fillna(0)
        + 0.10 * df["protein_abundance_rank"].fillna(df["robust_public_te_rank"]).fillna(0)
        + 0.05 * df["day_consensus_TE_rank"].fillna(0)
        + 0.05 * df["multiomics_model_pred_rank"].fillna(0)
    )

    base = df[
        df["length"].between(50, 100)
        & df["gc_content"].between(0.30, 0.75)
        & (df["uaug_count"] <= 1)
        & (~df["has_forbidden_site"])
        & (~df[SEQ].str.contains("N", regex=False))
        & df["multi_omics_utr_rank"].notna()
    ].copy()

    # Exact duplicate removal
    base = base.sort_values(["final_multiomics_selection_score", "multi_omics_utr_rank"], ascending=False).drop_duplicates(subset=[SEQ])

    selected = []
    used = set()

    def avail():
        return base[~base[SEQ].isin(used)].copy()

    def add(x):
        selected.append(x)
        used.update(x[SEQ].tolist())

    def pick(pool, n, sort_cols, group):
        x = pool.sort_values(sort_cols, ascending=[False] * len(sort_cols)).head(n).copy()
        x["library_group"] = group
        return x

    quota = {
        "A_multiomics_top": 300,
        "B_protein_residual_high": 200,
        "C_protein_abundance_TE_high": 150,
        "D_robust_TE_high": 150,
        "E_TSS_supported_multiomics_high": 100,
        "F_diverse_mid_high": 75,
        "G_low_multiomics_negative": 25,
    }

    add(pick(avail(), quota["A_multiomics_top"], ["final_multiomics_selection_score", "multi_omics_utr_rank"], "A_multiomics_top"))

    p = avail()
    p = p[p["protein_residual_rank"].fillna(0) >= 0.75]
    add(pick(p, quota["B_protein_residual_high"], ["protein_residual_rank", "multi_omics_utr_rank"], "B_protein_residual_high"))

    p = avail()
    p = p[(p["protein_abundance_rank"].fillna(0) >= 0.75) & (p["robust_public_te_rank"].fillna(0) >= 0.60)]
    add(pick(p, quota["C_protein_abundance_TE_high"], ["protein_abundance_rank", "robust_public_te_rank"], "C_protein_abundance_TE_high"))

    p = avail()
    p = p[p["robust_public_te_rank"].fillna(0) >= 0.80]
    add(pick(p, quota["D_robust_TE_high"], ["robust_public_te_rank", "final_multiomics_selection_score"], "D_robust_TE_high"))

    p = avail()
    if "tss_confidence" in p.columns:
        p = p[(p["tss_confidence"].astype(str) == "tss_supported_with_signal") & (p["multi_omics_utr_rank"].fillna(0) >= 0.70)]
    add(pick(p, quota["E_TSS_supported_multiomics_high"], ["multi_omics_utr_rank", "final_multiomics_selection_score"], "E_TSS_supported_multiomics_high"))

    p = avail()
    p = p[p["multi_omics_utr_rank"].fillna(0) >= 0.45].copy()
    p["len_bin"] = pd.cut(p["length"], [49, 60, 70, 80, 90, 100], labels=False)
    p["gc_bin"] = pd.cut(p["gc_content"], [0, 0.4, 0.5, 0.6, 0.75, 1], labels=False)
    parts = []
    for _, sub in p.groupby(["len_bin", "gc_bin"], dropna=True):
        parts.append(sub.sort_values(["final_multiomics_selection_score"], ascending=False).head(3))
    x = pd.concat(parts) if parts else p.head(0)
    x = x.drop_duplicates(subset=[SEQ]).head(quota["F_diverse_mid_high"]).copy()
    x["library_group"] = "F_diverse_mid_high"
    add(x)

    p = avail()
    p = p[p["multi_omics_utr_rank"].fillna(1) <= 0.25]
    add(pick(p, quota["G_low_multiomics_negative"], ["gc_content"], "G_low_multiomics_negative"))

    out = pd.concat(selected).drop_duplicates(subset=[SEQ]) if selected else base.head(0)

    if len(out) < 1000:
        extra = avail().sort_values(["final_multiomics_selection_score", "multi_omics_utr_rank"], ascending=False).head(1000 - len(out)).copy()
        extra["library_group"] = "H_fill_remaining"
        out = pd.concat([out, extra])

    out = out.head(1000).copy()
    out["library_index"] = range(1, len(out) + 1)

    front = [c for c in [
        "library_index", "library_group", "utr_id", "gene_name", SEQ,
        "length", "gc_content", "uaug_count", "tss_confidence",
        "multi_omics_utr_rank", "robust_public_te_rank", "protein_residual_rank",
        "protein_abundance_rank", "multiomics_model_pred_rank", "final_multiomics_selection_score",
        "has_proteomics_label", "forbidden_sites"
    ] if c in out.columns]
    out = out[front + [c for c in out.columns if c not in front]]

    out.to_csv(OUT, index=False)
    write_fasta(out, FA, SEQ, "utr_id")

    lines = [
        "Selected 1000 50-100 bp multi-omics/proteomics-assisted UTR library",
        "=" * 80,
        f"Total selected: {len(out)}",
        "",
        "[Group counts]",
        out["library_group"].value_counts().to_string(),
        "",
        "[Length]",
        out["length"].describe().to_string(),
        "",
        "[Multi-omics UTR rank]",
        out["multi_omics_utr_rank"].describe().to_string(),
        "",
        "[Robust public TE rank]",
        out["robust_public_te_rank"].describe().to_string(),
        "",
        "[Protein residual rank]",
        out["protein_residual_rank"].describe().to_string(),
        "",
        "[Protein abundance rank]",
        out["protein_abundance_rank"].describe().to_string(),
        "",
        "[has proteomics label]",
        out["has_proteomics_label"].value_counts(dropna=False).to_string() if "has_proteomics_label" in out.columns else "NA",
        "",
        "[uAUG]",
        out["uaug_count"].value_counts().sort_index().to_string(),
    ]
    SUMMARY.write_text("\n".join(lines), encoding="utf-8")

    print("[SAVED]", OUT)
    print("[SAVED]", FA)
    print("[SAVED]", SUMMARY)
    print(out["library_group"].value_counts().to_string())


if __name__ == "__main__":
    main()
