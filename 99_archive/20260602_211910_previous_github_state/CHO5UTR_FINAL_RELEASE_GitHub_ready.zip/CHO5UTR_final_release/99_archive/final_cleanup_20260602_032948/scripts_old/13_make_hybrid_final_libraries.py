from pathlib import Path
import pandas as pd
import numpy as np

BASE = Path.cwd()
SEQ = "utr5_sequence_tss_corrected"

PUBLIC = BASE / "07_library_design/tables/selected_1000_50_100bp_publicTE_40_200train_model_assisted_library.csv"
PROT = BASE / "07_library_design/tables/selected_1000_50_100bp_proteomics_enriched_library.csv"

OUTDIR = BASE / "07_library_design/tables"
FASTADIR = BASE / "07_library_design/fasta"
QCDIR = BASE / "07_library_design/qc"
for d in [OUTDIR, FASTADIR, QCDIR]:
    d.mkdir(parents=True, exist_ok=True)

HYBRID_SCHEMES = {
    # name: public_core, proteomics_unique, negative_controls
    "conservative": (800, 175, 25),
    "balanced": (750, 225, 25),
    "exploratory": (650, 325, 25),
}

def clean_seq(x):
    if pd.isna(x):
        return ""
    return str(x).upper().replace("U", "T").replace(" ", "").replace("\n", "")

def get_sort_cols(df, preferred):
    return [c for c in preferred if c in df.columns]

def sort_desc(df, preferred):
    cols = get_sort_cols(df, preferred)
    if not cols:
        return df.copy()
    return df.sort_values(cols, ascending=[False] * len(cols))

def write_fasta(df, path, seq_col=SEQ, id_col="utr_id"):
    with open(path, "w", encoding="utf-8") as out:
        for i, r in df.iterrows():
            uid = str(r.get(id_col, f"row_{i}")).replace(" ", "_").replace("/", "_")
            group = str(r.get("hybrid_group", r.get("library_group", "NA"))).replace(" ", "_")
            gene = str(r.get("gene_name", "NA")).replace(" ", "_").replace("/", "_")
            seq = clean_seq(r[seq_col])
            out.write(f">{uid}|{gene}|len={len(seq)}|group={group}\n")
            for j in range(0, len(seq), 80):
                out.write(seq[j:j+80] + "\n")

def qc_filter(df):
    x = df.copy()
    x[SEQ] = x[SEQ].apply(clean_seq)
    if "length" not in x.columns:
        if "seq_len" in x.columns:
            x["length"] = x["seq_len"]
        else:
            x["length"] = x[SEQ].str.len()
    if "gc_content" not in x.columns:
        x["gc_content"] = x[SEQ].apply(lambda s: (s.count("G") + s.count("C")) / len(s) if len(s) else np.nan)
    if "uaug_count" not in x.columns:
        x["uaug_count"] = x[SEQ].str.count("ATG")
    if "forbidden_sites" in x.columns:
        forbid = x["forbidden_sites"].fillna("").astype(str).ne("")
    else:
        forbid = pd.Series(False, index=x.index)
    x = x[
        x["length"].between(50, 100)
        & x["gc_content"].between(0.30, 0.75)
        & (x["uaug_count"] <= 1)
        & (~forbid)
        & (~x[SEQ].str.contains("N", regex=False))
    ].copy()
    return x

def harmonize_columns(pub, prot):
    # Make sure both have same columns for concat.
    all_cols = list(dict.fromkeys(list(pub.columns) + list(prot.columns)))
    for c in all_cols:
        if c not in pub.columns:
            pub[c] = np.nan
        if c not in prot.columns:
            prot[c] = np.nan
    return pub[all_cols].copy(), prot[all_cols].copy()

def make_hybrid(pub, prot, scheme_name, n_public, n_prot_unique, n_negative):
    pub = qc_filter(pub)
    prot = qc_filter(prot)

    pub["source_library"] = "publicTE"
    prot["source_library"] = "proteomics_enriched"

    pub, prot = harmonize_columns(pub, prot)

    public_seqs = set(pub[SEQ])
    prot_unique = prot[~prot[SEQ].isin(public_seqs)].copy()

    # Negative controls: take low robust_public_te_rank from union.
    union = pd.concat([pub, prot], ignore_index=True).drop_duplicates(subset=[SEQ]).copy()
    neg_pool = union[union["robust_public_te_rank"].fillna(1) <= 0.25].copy()
    neg_pool = neg_pool.sort_values(["robust_public_te_rank", "gc_content"], ascending=[True, False])
    neg = neg_pool.head(n_negative).copy()
    neg["hybrid_group"] = "C_low_TE_negative"

    used = set(neg[SEQ])

    # PublicTE main candidates
    pub_pool = pub[~pub[SEQ].isin(used)].copy()
    pub_pool = sort_desc(pub_pool, [
        "robust_public_te_rank",
        "final_selection_score",
        "model_pred_rank_40_200train",
        "day_consensus_TE_rank",
        "sequence_quality_score",
    ])
    public_core = pub_pool.head(n_public).copy()
    public_core["hybrid_group"] = "A_publicTE_core"
    used.update(public_core[SEQ])

    # Proteomics unique candidates
    prot_pool = prot_unique[~prot_unique[SEQ].isin(used)].copy()
    prot_pool = sort_desc(prot_pool, [
        "proteomics_enriched_score",
        "protein_residual_rank",
        "protein_abundance_rank",
        "robust_public_te_rank",
        "multi_omics_utr_rank",
    ])
    prot_add = prot_pool.head(n_prot_unique).copy()
    prot_add["hybrid_group"] = "B_proteomics_unique"

    out = pd.concat([public_core, prot_add, neg], ignore_index=True).drop_duplicates(subset=[SEQ]).copy()

    # If shortage due to duplicate/low unique pool, fill in a defined order.
    if len(out) < 1000:
        used = set(out[SEQ])
        fill1 = prot[~prot[SEQ].isin(used)].copy()
        fill1 = sort_desc(fill1, [
            "proteomics_enriched_score",
            "protein_residual_rank",
            "protein_abundance_rank",
            "robust_public_te_rank",
        ]).head(1000 - len(out))
        fill1["hybrid_group"] = "D_fill_proteomics"
        out = pd.concat([out, fill1], ignore_index=True).drop_duplicates(subset=[SEQ]).copy()

    if len(out) < 1000:
        used = set(out[SEQ])
        fill2 = pub[~pub[SEQ].isin(used)].copy()
        fill2 = sort_desc(fill2, [
            "robust_public_te_rank",
            "final_selection_score",
            "model_pred_rank_40_200train",
        ]).head(1000 - len(out))
        fill2["hybrid_group"] = "E_fill_publicTE"
        out = pd.concat([out, fill2], ignore_index=True).drop_duplicates(subset=[SEQ]).copy()

    out = out.head(1000).copy()
    out["library_index"] = range(1, len(out) + 1)

    # Add indicator columns.
    out["is_from_publicTE_library"] = out[SEQ].isin(set(pub[SEQ]))
    out["is_from_proteomics_enriched_library"] = out[SEQ].isin(set(prot[SEQ]))
    out["is_proteomics_unique_vs_publicTE"] = out[SEQ].isin(set(prot_unique[SEQ]))

    front = [c for c in [
        "library_index", "hybrid_group", "source_library", "library_group",
        "utr_id", "gene_id", "gene_name", SEQ,
        "length", "gc_content", "uaug_count", "tss_confidence",
        "robust_public_te_rank", "multi_omics_utr_rank", "proteomics_enriched_score",
        "protein_residual_rank", "protein_abundance_rank", "day_consensus_TE_rank",
        "ribo_abundance_rank", "model_pred_rank_40_200train",
        "has_proteomics_label", "proteomics_mapping_mode",
        "is_from_publicTE_library", "is_from_proteomics_enriched_library", "is_proteomics_unique_vs_publicTE",
        "forbidden_sites"
    ] if c in out.columns]
    out = out[front + [c for c in out.columns if c not in front]]

    return out, pub, prot, prot_unique

def summarize(out, pub, prot, prot_unique, scheme_name, n_public, n_prot_unique, n_negative):
    A = set(pub[SEQ])
    B = set(prot[SEQ])
    O = set(out[SEQ])
    lines = [
        f"Hybrid final 50-100 bp UTR library summary: {scheme_name}",
        "=" * 90,
        f"Target scheme: publicTE_core={n_public}, proteomics_unique={n_prot_unique}, negative={n_negative}",
        f"Total selected: {len(out)}",
        "",
        "[Source candidate pools]",
        f"publicTE library candidates after QC: {len(pub)}",
        f"proteomics-enriched library candidates after QC: {len(prot)}",
        f"proteomics unique vs publicTE candidates after QC: {len(prot_unique)}",
        f"publicTE vs proteomics overlap: {len(A & B)}",
        "",
        "[Hybrid group counts]",
        out["hybrid_group"].value_counts().to_string(),
        "",
        "[Membership counts]",
        f"from publicTE library: {int(out['is_from_publicTE_library'].sum())}",
        f"from proteomics-enriched library: {int(out['is_from_proteomics_enriched_library'].sum())}",
        f"proteomics unique vs publicTE: {int(out['is_proteomics_unique_vs_publicTE'].sum())}",
        "",
        "[has_proteomics_label]",
        out["has_proteomics_label"].value_counts(dropna=False).to_string() if "has_proteomics_label" in out.columns else "NA",
        "",
        "[Length]",
        out["length"].describe().to_string(),
        "",
        "[Robust public TE rank]",
        out["robust_public_te_rank"].describe().to_string() if "robust_public_te_rank" in out.columns else "NA",
        "",
        "[Protein residual rank]",
        out["protein_residual_rank"].describe().to_string() if "protein_residual_rank" in out.columns else "NA",
        "",
        "[Protein abundance rank]",
        out["protein_abundance_rank"].describe().to_string() if "protein_abundance_rank" in out.columns else "NA",
        "",
        "[uAUG]",
        out["uaug_count"].value_counts().sort_index().to_string(),
        "",
        "[Exact duplicate check]",
        f"unique sequences: {out[SEQ].nunique()}",
        f"duplicate sequences: {len(out) - out[SEQ].nunique()}",
    ]
    return "\n".join(lines)

def main():
    if not PUBLIC.exists():
        raise SystemExit(f"Missing publicTE library: {PUBLIC}")
    if not PROT.exists():
        raise SystemExit(f"Missing proteomics-enriched library: {PROT}")

    pub = pd.read_csv(PUBLIC)
    prot = pd.read_csv(PROT)

    for scheme_name, (n_public, n_prot_unique, n_negative) in HYBRID_SCHEMES.items():
        out, pub_qc, prot_qc, prot_unique = make_hybrid(pub, prot, scheme_name, n_public, n_prot_unique, n_negative)

        out_csv = OUTDIR / f"selected_1000_50_100bp_HYBRID_{scheme_name}_publicTE_proteomics.csv"
        out_fa = FASTADIR / f"selected_1000_50_100bp_HYBRID_{scheme_name}_publicTE_proteomics.fasta"
        out_summary = QCDIR / f"selected_1000_50_100bp_HYBRID_{scheme_name}_summary.txt"

        out.to_csv(out_csv, index=False)
        write_fasta(out, out_fa)
        out_summary.write_text(summarize(out, pub_qc, prot_qc, prot_unique, scheme_name, n_public, n_prot_unique, n_negative), encoding="utf-8")

        print("\n" + "=" * 80)
        print("SAVED", scheme_name)
        print(out_csv)
        print(out_fa)
        print(out_summary)
        print(out["hybrid_group"].value_counts().to_string())

if __name__ == "__main__":
    main()
