import subprocess
import sys

cmd = [sys.executable, "01_pipeline/scripts/15_naturecomm_style_k5_tree1500_benchmark.py", "--fast"]
print("RUN", " ".join(cmd))
r = subprocess.run(cmd)
if r.returncode != 0:
    raise SystemExit("FAILED")
print("DONE")
