from pathlib import Path
import subprocess
import sys

steps = [
    "04b_extract_features_train_40_200bp.py",
    "05b_model_train_40_200bp.py",
    "06b_select_1000_50_100bp_from_40_200train.py",
]

script_dir = Path("01_pipeline") / "scripts"

for step in steps:
    print("\n" + "=" * 80)
    print("RUN", step)
    print("=" * 80)
    r = subprocess.run([sys.executable, str(script_dir / step)])
    if r.returncode != 0:
        raise SystemExit(f"FAILED: {step}")

print("\nDONE: 40–200 bp training / 50–100 bp selection pipeline completed.")
