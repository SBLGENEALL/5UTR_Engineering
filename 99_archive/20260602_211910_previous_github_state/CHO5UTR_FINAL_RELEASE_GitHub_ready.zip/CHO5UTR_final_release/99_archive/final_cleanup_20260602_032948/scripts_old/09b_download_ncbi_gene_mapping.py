from pathlib import Path
import subprocess
import sys
import shutil

BASE = Path.cwd()
OUTDIR = BASE / "00_raw_data/05_cho_proteomics/ncbi_gene_mapping"
OUTDIR.mkdir(parents=True, exist_ok=True)

FILES = {
    "gene2accession.gz": "https://ftp.ncbi.nlm.nih.gov/gene/DATA/gene2accession.gz",
    "gene_info.gz": "https://ftp.ncbi.nlm.nih.gov/gene/DATA/gene_info.gz",
}

def download(url, out):
    out = Path(out)
    if out.exists() and out.stat().st_size > 0:
        print("[SKIP exists]", out)
        return
    if shutil.which("curl"):
        cmd = ["curl.exe" if sys.platform.startswith("win") else "curl", "-L", "-C", "-", "-o", str(out), url]
    elif shutil.which("wget"):
        cmd = ["wget", "-c", "-O", str(out), url]
    else:
        raise SystemExit("curl or wget is required.")
    print("[DOWNLOAD]", url)
    subprocess.check_call(cmd)

def main():
    for fn, url in FILES.items():
        download(url, OUTDIR / fn)
    print("\nDONE")
    for p in sorted(OUTDIR.glob("*")):
        print(p, p.stat().st_size)

if __name__ == "__main__":
    main()
