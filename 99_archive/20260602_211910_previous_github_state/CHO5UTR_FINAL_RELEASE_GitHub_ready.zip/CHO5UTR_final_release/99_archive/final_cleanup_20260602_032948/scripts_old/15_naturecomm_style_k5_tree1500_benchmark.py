from __future__ import annotations

from pathlib import Path
from collections import Counter
from itertools import product
import argparse
import math
import warnings

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

from scipy.stats import spearmanr, pearsonr
from sklearn.model_selection import train_test_split
from sklearn.pipeline import Pipeline
from sklearn.impute import SimpleImputer
from sklearn.preprocessing import StandardScaler
from sklearn.ensemble import ExtraTreesRegressor, RandomForestRegressor, ExtraTreesClassifier, RandomForestClassifier
from sklearn.metrics import r2_score, mean_squared_error, mean_absolute_error, roc_auc_score, average_precision_score

warnings.filterwarnings("ignore")

BASE = Path.cwd()
SEQ = "utr5_sequence_tss_corrected"

LABEL_CANDIDATES = [
    BASE / "04_te_labeling/tables/tss_corrected_5utr_multiomics_labels.csv",
    BASE / "04_te_labeling/tables/tss_corrected_5utr_robust_public_te_labels.csv",
]

OUTDIR = BASE / "06_modeling/tables"
PLOTDIR = BASE / "06_modeling/plots"
for d in [OUTDIR, PLOTDIR]:
    d.mkdir(parents=True, exist_ok=True)

OUT_REG = OUTDIR / "naturecomm_style_k5_tree1500_regression_results.csv"
OUT_CLF = OUTDIR / "naturecomm_style_k5_tree1500_classification_results.csv"
OUT_SUMMARY = OUTDIR / "naturecomm_style_k5_tree1500_summary.txt"
OUT_PLOT = PLOTDIR / "naturecomm_style_gene_split_spearman.png"

def clean_seq(x):
    if pd.isna(x):
        return ""
    return str(x).upper().replace("U", "T").replace(" ", "").replace("\n", "")

def gc_content(seq):
    seq = clean_seq(seq)
    return (seq.count("G") + seq.count("C")) / len(seq) if len(seq) else np.nan

def longest_run(seq, base):
    best = cur = 0
    for b in clean_seq(seq):
        if b == base:
            cur += 1
            best = max(best, cur)
        else:
            cur = 0
    return best

def count_uorf(seq):
    seq = clean_seq(seq)
    stops = {"TAA", "TAG", "TGA"}
    n, longest = 0, 0
    for i in range(max(0, len(seq) - 2)):
        if seq[i:i+3] == "ATG":
            for j in range(i + 3, len(seq) - 2, 3):
                if seq[j:j+3] in stops:
                    n += 1
                    longest = max(longest, j + 3 - i)
                    break
    return n, longest

def get_window(seq, mode):
    seq = clean_seq(seq)
    if mode == "full":
        return seq
    if mode == "tail100":
        return seq[-100:] if len(seq) > 100 else seq
    if mode == "head100":
        return seq[:100]
    if mode == "pad100":
        # NatureComm-like fixed 100 bp representation for short candidates.
        # Padding with N is encoded as no base in one-hot and no k-mer contribution.
        return seq[:100]
    raise ValueError(mode)

def kmer_features(seq, ks=(5,), prefix=""):
    seq = clean_seq(seq)
    out = {}
    for k in ks:
        all_kmers = ["".join(x) for x in product("ACGT", repeat=k)]
        cnt = Counter(seq[i:i+k] for i in range(max(0, len(seq)-k+1)) if set(seq[i:i+k]) <= set("ACGT"))
        total = sum(cnt.values())
        for km in all_kmers:
            out[f"{prefix}{k}mer_{km}"] = cnt.get(km, 0) / total if total else 0.0
    return out

def onehot100(seq, prefix="onehot_"):
    seq = clean_seq(seq)[:100]
    out = {}
    for i in range(100):
        b = seq[i] if i < len(seq) else "N"
        for x in "ACGT":
            out[f"{prefix}{i:03d}_{x}"] = 1.0 if b == x else 0.0
    return out

def make_features(df, strategy):
    mode = strategy["window_mode"]
    ks = tuple(strategy["kmers"])
    use_onehot = strategy.get("onehot100", False)

    rows = []
    for i, seq0 in enumerate(df[SEQ].map(clean_seq)):
        seq = get_window(seq0, mode)
        L = len(seq0)
        WL = len(seq)
        uorf, longest = count_uorf(seq0)

        r = {
            "length": L,
            "window_length": WL,
            "gc_content": gc_content(seq0),
            "window_gc": gc_content(seq),
            "uaug_count": seq0.count("ATG"),
            "window_uaug_count": seq.count("ATG"),
            "cpg_count": seq0.count("CG"),
            "window_cpg_count": seq.count("CG"),
            "first_aug_pos": seq0.find("ATG"),
            "aug_density": seq0.count("ATG") / L if L else 0,
            "uorf_count": uorf,
            "longest_uorf_len": longest,
        }

        for b in "ACGT":
            r[f"{b.lower()}_fraction"] = seq0.count(b) / L if L else 0.0
            r[f"window_{b.lower()}_fraction"] = seq.count(b) / WL if WL else 0.0
            r[f"poly{b}_max_run"] = longest_run(seq0, b)
            r[f"window_poly{b}_max_run"] = longest_run(seq, b)

        # Local features near cap and start codon.
        for w in [20, 30, 50, 100]:
            head = seq0[:w]
            tail = seq0[-w:] if L >= w else seq0
            r[f"head{w}_gc"] = gc_content(head)
            r[f"tail{w}_gc"] = gc_content(tail)
            r[f"head{w}_uaug"] = head.count("ATG")
            r[f"tail{w}_uaug"] = tail.count("ATG")

        r.update(kmer_features(seq, ks=ks, prefix=f"{mode}_"))
        if strategy.get("add_full_kmer5", False) and mode != "full":
            r.update(kmer_features(seq0, ks=(5,), prefix="full_"))
        if use_onehot:
            r.update(onehot100(seq, prefix=f"{mode}_onehot_"))

        rows.append(r)
        if (i + 1) % 5000 == 0:
            print(f"  feature rows {i+1:,}/{len(df):,}")

    return pd.DataFrame(rows)

def make_regressor(name, n_estimators=1500, rs=42):
    if name == "RandomForest":
        return Pipeline([
            ("imputer", SimpleImputer(strategy="median")),
            ("model", RandomForestRegressor(
                n_estimators=n_estimators,
                max_features="sqrt",
                min_samples_leaf=5,
                random_state=rs,
                n_jobs=-1
            )),
        ])
    if name == "ExtraTrees":
        return Pipeline([
            ("imputer", SimpleImputer(strategy="median")),
            ("model", ExtraTreesRegressor(
                n_estimators=n_estimators,
                max_features="sqrt",
                min_samples_leaf=5,
                random_state=rs,
                n_jobs=-1
            )),
        ])
    raise ValueError(name)

def make_classifier(name, n_estimators=1500, rs=42):
    if name == "RandomForest":
        return Pipeline([
            ("imputer", SimpleImputer(strategy="median")),
            ("model", RandomForestClassifier(
                n_estimators=n_estimators,
                max_features="sqrt",
                min_samples_leaf=5,
                class_weight="balanced",
                random_state=rs,
                n_jobs=-1
            )),
        ])
    if name == "ExtraTrees":
        return Pipeline([
            ("imputer", SimpleImputer(strategy="median")),
            ("model", ExtraTreesClassifier(
                n_estimators=n_estimators,
                max_features="sqrt",
                min_samples_leaf=5,
                class_weight="balanced",
                random_state=rs,
                n_jobs=-1
            )),
        ])
    raise ValueError(name)

def split_idx(df, mode, rs=42, test_size=0.2):
    if mode == "random":
        idx = np.arange(len(df))
        return train_test_split(idx, test_size=test_size, random_state=rs)
    groups = df["gene_name"].astype(str).fillna("NA").values if "gene_name" in df.columns else df["utr_id"].astype(str).values
    unique = np.array(sorted(pd.unique(groups)))
    tr_g, te_g = train_test_split(unique, test_size=test_size, random_state=rs)
    return np.where(np.isin(groups, tr_g))[0], np.where(np.isin(groups, te_g))[0]

def reg_metrics(y, p):
    out = {
        "spearman": spearmanr(y, p).correlation if len(y) >= 3 else np.nan,
        "pearson": pearsonr(y, p)[0] if len(y) >= 3 else np.nan,
        "r2": r2_score(y, p),
        "rmse": float(math.sqrt(mean_squared_error(y, p))),
        "mae": float(mean_absolute_error(y, p)),
    }
    for frac in [0.05, 0.10, 0.20]:
        k = max(1, int(len(y) * frac))
        top = np.argsort(p)[-k:]
        thr = np.quantile(y, 1 - frac)
        out[f"top{int(frac*100)}_enrichment"] = float(np.mean(y[top] >= thr))
    return out

def load_label():
    for p in LABEL_CANDIDATES:
        if p.exists():
            print("[LOAD]", p)
            return pd.read_csv(p), p
    raise SystemExit("No label table found.")

def prep(df):
    df = df.copy()
    df[SEQ] = df[SEQ].map(clean_seq)
    if "utr5_length_final" in df.columns:
        df["length_for_filter"] = df["utr5_length_final"]
    elif "utr5_length_tss_corrected" in df.columns:
        df["length_for_filter"] = df["utr5_length_tss_corrected"]
    else:
        df["length_for_filter"] = df[SEQ].str.len()
    if "gc_content" not in df.columns:
        df["gc_content"] = df[SEQ].map(gc_content)
    if "uaug_count" not in df.columns:
        df["uaug_count"] = df[SEQ].str.count("ATG")
    if "has_proteomics_label" not in df.columns:
        df["has_proteomics_label"] = df.get("protein_abundance_rank", pd.Series(np.nan, index=df.index)).notna()
    return df

def filter_df(df, name):
    # Keep final-selection-relevant windows plus wider windows.
    if name == "50_100_strict":
        mask = df["length_for_filter"].between(50, 100) & df["gc_content"].between(0.30, 0.75) & (df["uaug_count"] <= 1)
    elif name == "40_200_strict":
        mask = df["length_for_filter"].between(40, 200) & df["gc_content"].between(0.30, 0.75) & (df["uaug_count"] <= 1)
    elif name == "20_500_relaxed":
        mask = df["length_for_filter"].between(20, 500) & df["gc_content"].between(0.25, 0.80) & (df["uaug_count"] <= 3)
    elif name == "proteomics_20_500_relaxed":
        mask = df["length_for_filter"].between(20, 500) & df["gc_content"].between(0.25, 0.80) & (df["uaug_count"] <= 3) & df["has_proteomics_label"].astype(bool)
    else:
        raise ValueError(name)
    mask &= df[SEQ].str.len() > 0
    mask &= ~df[SEQ].str.contains("N", regex=False)
    return df[mask].copy().reset_index(drop=True)

def plot_results(reg_df):
    sub = reg_df[reg_df["split_mode"] == "gene_split"].copy()
    if sub.empty:
        return
    sub["label"] = sub["target"] + "\n" + sub["filter_name"] + "\n" + sub["strategy"] + "\n" + sub["model"]
    sub = sub.sort_values("spearman", ascending=True).tail(25)
    plt.figure(figsize=(13, max(7, 0.45 * len(sub))))
    plt.barh(sub["label"], sub["spearman"])
    plt.xlabel("Gene-split Spearman")
    plt.title("NatureComm-style k=5 / tree=1500 benchmark")
    plt.tight_layout()
    plt.savefig(OUT_PLOT, dpi=200)
    plt.close()

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--n-estimators", type=int, default=1500)
    ap.add_argument("--fast", action="store_true", help="Only run the most relevant 40-200 and 50-100 windows.")
    args = ap.parse_args()

    df, label_path = load_label()
    df = prep(df)

    strategies = [
        {"strategy": "full_k5", "window_mode": "full", "kmers": [5], "onehot100": False},
        {"strategy": "full_k345", "window_mode": "full", "kmers": [3,4,5], "onehot100": False},
        {"strategy": "tail100_k5_plus_fullk5", "window_mode": "tail100", "kmers": [5], "onehot100": False, "add_full_kmer5": True},
        {"strategy": "tail100_k5_onehot", "window_mode": "tail100", "kmers": [5], "onehot100": True},
        {"strategy": "pad100_k5_onehot", "window_mode": "pad100", "kmers": [5], "onehot100": True},
    ]

    filters = ["50_100_strict", "40_200_strict"] if args.fast else ["50_100_strict", "40_200_strict", "20_500_relaxed", "proteomics_20_500_relaxed"]
    targets = [c for c in ["robust_public_te_rank", "multi_omics_utr_rank", "protein_residual_rank", "protein_abundance_rank"] if c in df.columns]
    models = ["RandomForest", "ExtraTrees"]

    reg_rows = []
    clf_rows = []

    for filt in filters:
        sub0 = filter_df(df, filt)
        print("\n" + "="*100)
        print("[FILTER]", filt, "rows", len(sub0), "proteomics", int(sub0["has_proteomics_label"].sum()))
        print("="*100)
        if len(sub0) < 500:
            print("[SKIP] too few rows")
            continue

        for strat in strategies:
            # pad100 strategy is most meaningful for 50-100 and 40-120-ish, but still runs.
            print("\n[FEATURE]", filt, strat["strategy"])
            X0 = make_features(sub0, strat)

            for target in targets:
                valid = pd.to_numeric(sub0[target], errors="coerce").notna()
                sub = sub0[valid].copy().reset_index(drop=True)
                X = X0.loc[valid].reset_index(drop=True)
                if len(sub) < 500:
                    continue
                if target.startswith("protein") and int(sub["has_proteomics_label"].sum()) < 500:
                    continue

                y = pd.to_numeric(sub[target], errors="coerce").values

                for split_mode in ["random", "gene_split"]:
                    tr, te = split_idx(sub, split_mode)
                    for model_name in models:
                        print("[REG]", filt, strat["strategy"], target, split_mode, model_name)
                        model = make_regressor(model_name, n_estimators=args.n_estimators)
                        model.fit(X.iloc[tr], y[tr])
                        pred = np.clip(model.predict(X.iloc[te]), 0, 1)
                        met = reg_metrics(y[te], pred)
                        reg_rows.append({
                            "filter_name": filt,
                            "strategy": strat["strategy"],
                            "target": target,
                            "split_mode": split_mode,
                            "model": model_name,
                            "n_estimators": args.n_estimators,
                            "n_rows": len(sub),
                            "n_train": len(tr),
                            "n_test": len(te),
                            "proteomics_mapped_rows": int(sub["has_proteomics_label"].sum()),
                            **met
                        })
                        print("  spearman", round(met["spearman"], 4), "pearson", round(met["pearson"], 4), "top10", round(met["top10_enrichment"], 4))

                # Classification: only once per target/strategy, using gene_split and random.
                hi = np.quantile(y, 0.80)
                lo = np.quantile(y, 0.30)
                cmask = (y >= hi) | (y <= lo)
                if cmask.sum() >= 300 and len(np.unique((y[cmask] >= hi).astype(int))) == 2:
                    cdf = sub.loc[cmask].copy().reset_index(drop=True)
                    Xc = X.loc[cmask].reset_index(drop=True)
                    yc = (pd.to_numeric(cdf[target], errors="coerce").values >= hi).astype(int)

                    for split_mode in ["random", "gene_split"]:
                        if split_mode == "random":
                            idx = np.arange(len(cdf))
                            tr, te = train_test_split(idx, test_size=0.2, random_state=42, stratify=yc)
                        else:
                            tr, te = split_idx(cdf, split_mode)
                        for model_name in models:
                            print("[CLF]", filt, strat["strategy"], target, split_mode, model_name)
                            clf = make_classifier(model_name, n_estimators=args.n_estimators)
                            clf.fit(Xc.iloc[tr], yc[tr])
                            pp = clf.predict_proba(Xc.iloc[te])[:, 1]
                            clf_rows.append({
                                "filter_name": filt,
                                "strategy": strat["strategy"],
                                "target": target,
                                "split_mode": split_mode,
                                "model": model_name,
                                "n_estimators": args.n_estimators,
                                "n_rows": len(cdf),
                                "n_train": len(tr),
                                "n_test": len(te),
                                "roc_auc": roc_auc_score(yc[te], pp),
                                "average_precision": average_precision_score(yc[te], pp),
                            })

    reg = pd.DataFrame(reg_rows)
    clf = pd.DataFrame(clf_rows)
    reg.to_csv(OUT_REG, index=False)
    clf.to_csv(OUT_CLF, index=False)
    plot_results(reg)

    lines = [
        "NatureComm-style k=5 / tree=1500 benchmark summary",
        "=" * 100,
        f"label_path: {label_path}",
        f"n_estimators: {args.n_estimators}",
        "",
        "[Top gene_split regression by Spearman]",
        reg[reg["split_mode"] == "gene_split"].sort_values("spearman", ascending=False).head(30).to_string(index=False) if len(reg) else "No regression rows.",
        "",
        "[Top gene_split regression by top10_enrichment]",
        reg[reg["split_mode"] == "gene_split"].sort_values("top10_enrichment", ascending=False).head(30).to_string(index=False) if len(reg) else "No regression rows.",
        "",
        "[Top gene_split classification by ROC-AUC]",
        clf[clf["split_mode"] == "gene_split"].sort_values("roc_auc", ascending=False).head(30).to_string(index=False) if len(clf) else "No classification rows.",
        "",
        f"Saved regression: {OUT_REG}",
        f"Saved classification: {OUT_CLF}",
        f"Saved plot: {OUT_PLOT}",
    ]
    OUT_SUMMARY.write_text("\n".join(lines), encoding="utf-8")
    print("[SAVED]", OUT_REG)
    print("[SAVED]", OUT_CLF)
    print("[SAVED]", OUT_SUMMARY)
    print("[SAVED]", OUT_PLOT)

if __name__ == "__main__":
    main()
