from __future__ import annotations

from pathlib import Path
from collections import Counter
from itertools import product
import argparse
import math
import warnings

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

from scipy.stats import spearmanr, pearsonr
from sklearn.model_selection import train_test_split
from sklearn.pipeline import Pipeline
from sklearn.impute import SimpleImputer
from sklearn.ensemble import ExtraTreesRegressor, RandomForestRegressor, HistGradientBoostingRegressor
from sklearn.metrics import r2_score, mean_squared_error, mean_absolute_error

warnings.filterwarnings("ignore")

BASE = Path.cwd()
SEQ = "utr5_sequence_tss_corrected"

LABEL_CANDIDATES = [
    BASE / "04_te_labeling/tables/tss_corrected_5utr_multiomics_labels.csv",
    BASE / "04_te_labeling/tables/tss_corrected_5utr_robust_public_te_labels.csv",
]

OUT_TABLE = BASE / "06_modeling/tables/filter_window_sensitivity_results.csv"
OUT_SUMMARY = BASE / "06_modeling/tables/filter_window_sensitivity_summary.txt"
OUT_DIAG = BASE / "04_te_labeling/qc/filter_window_proteomics_coverage_diagnostics.txt"
OUT_PLOT = BASE / "06_modeling/plots/filter_window_gene_split_spearman.png"

for p in [OUT_TABLE.parent, OUT_DIAG.parent, OUT_PLOT.parent]:
    p.mkdir(parents=True, exist_ok=True)

def clean_seq(x):
    if pd.isna(x):
        return ""
    return str(x).upper().replace("U", "T").replace(" ", "").replace("\n", "")

def gc_content(seq):
    seq = clean_seq(seq)
    return (seq.count("G") + seq.count("C")) / len(seq) if len(seq) else np.nan

def longest_run(seq, base):
    best = cur = 0
    for b in clean_seq(seq):
        if b == base:
            cur += 1
            best = max(best, cur)
        else:
            cur = 0
    return best

def count_uorf(seq):
    seq = clean_seq(seq)
    stops = {"TAA", "TAG", "TGA"}
    n = 0
    longest = 0
    for i in range(max(0, len(seq)-2)):
        if seq[i:i+3] == "ATG":
            for j in range(i+3, len(seq)-2, 3):
                if seq[j:j+3] in stops:
                    n += 1
                    longest = max(longest, j+3-i)
                    break
    return n, longest

def kmer_features(seq, ks=(3,4,5), prefix=""):
    seq = clean_seq(seq)
    out = {}
    for k in ks:
        all_kmers = ["".join(x) for x in product("ACGT", repeat=k)]
        cnt = Counter(seq[i:i+k] for i in range(max(0, len(seq)-k+1)) if set(seq[i:i+k]) <= set("ACGT"))
        tot = sum(cnt.values())
        for km in all_kmers:
            out[f"{prefix}{k}mer_{km}"] = cnt.get(km, 0) / tot if tot else 0.0
    return out

def make_features(df, k_values=(3,4,5), include_tail100=True):
    rows = []
    for i, seq in enumerate(df[SEQ].map(clean_seq)):
        L = len(seq)
        tail100 = seq[-100:] if L > 100 else seq
        head100 = seq[:100]
        uorf, longest = count_uorf(seq)
        r = {
            "length": L,
            "gc_content": gc_content(seq),
            "tail100_gc": gc_content(tail100),
            "head100_gc": gc_content(head100),
            "uaug_count": seq.count("ATG"),
            "tail100_uaug": tail100.count("ATG"),
            "head100_uaug": head100.count("ATG"),
            "cpg_count": seq.count("CG"),
            "first_aug_pos": seq.find("ATG"),
            "aug_density": seq.count("ATG") / L if L else 0,
            "uorf_count": uorf,
            "longest_uorf_len": longest,
        }
        for b in "ACGT":
            r[f"{b.lower()}_fraction"] = seq.count(b) / L if L else 0
            r[f"poly{b}_max_run"] = longest_run(seq, b)
            r[f"tail100_{b.lower()}_fraction"] = tail100.count(b) / len(tail100) if len(tail100) else 0
        r.update(kmer_features(seq, ks=k_values, prefix="full_"))
        if include_tail100:
            r.update(kmer_features(tail100, ks=k_values, prefix="tail100_"))
            r.update(kmer_features(head100, ks=(3,4), prefix="head100_"))
        rows.append(r)
        if (i+1) % 5000 == 0:
            print(f"  feature rows {i+1:,}/{len(df):,}")
    return pd.DataFrame(rows)

def make_model(name, rs=42, n_estimators=700):
    if name == "ExtraTrees":
        return Pipeline([
            ("imputer", SimpleImputer(strategy="median")),
            ("model", ExtraTreesRegressor(n_estimators=n_estimators, max_features="sqrt", min_samples_leaf=5, random_state=rs, n_jobs=-1)),
        ])
    if name == "RandomForest":
        return Pipeline([
            ("imputer", SimpleImputer(strategy="median")),
            ("model", RandomForestRegressor(n_estimators=n_estimators, max_features="sqrt", min_samples_leaf=5, random_state=rs, n_jobs=-1)),
        ])
    if name == "HistGradientBoosting":
        return Pipeline([
            ("imputer", SimpleImputer(strategy="median")),
            ("model", HistGradientBoostingRegressor(max_iter=600, learning_rate=0.04, max_leaf_nodes=31, l2_regularization=0.03, random_state=rs)),
        ])
    raise ValueError(name)

def split_idx(df, mode, rs=42, test_size=0.2):
    if mode == "random":
        idx = np.arange(len(df))
        return train_test_split(idx, test_size=test_size, random_state=rs)
    groups = df["gene_name"].astype(str).fillna("NA").values if "gene_name" in df.columns else df["utr_id"].astype(str).values
    uniq = np.array(sorted(pd.unique(groups)))
    tr_g, te_g = train_test_split(uniq, test_size=test_size, random_state=rs)
    return np.where(np.isin(groups, tr_g))[0], np.where(np.isin(groups, te_g))[0]

def metrics(y, p):
    out = {
        "spearman": spearmanr(y, p).correlation if len(y) >= 3 else np.nan,
        "pearson": pearsonr(y, p)[0] if len(y) >= 3 else np.nan,
        "r2": r2_score(y, p),
        "rmse": float(math.sqrt(mean_squared_error(y, p))),
        "mae": float(mean_absolute_error(y, p)),
    }
    for frac in [0.05, 0.10, 0.20]:
        k = max(1, int(len(y) * frac))
        top = np.argsort(p)[-k:]
        thr = np.quantile(y, 1-frac)
        out[f"top{int(frac*100)}_enrichment"] = float(np.mean(y[top] >= thr))
    return out

def load_label():
    for p in LABEL_CANDIDATES:
        if p.exists():
            print("[LOAD]", p)
            return pd.read_csv(p), p
    raise SystemExit("No label table found. Need multiomics or robust public TE label CSV.")

def prepare(df):
    df = df.copy()
    df[SEQ] = df[SEQ].map(clean_seq)
    if "utr5_length_final" in df.columns:
        df["length_for_filter"] = df["utr5_length_final"]
    elif "utr5_length_tss_corrected" in df.columns:
        df["length_for_filter"] = df["utr5_length_tss_corrected"]
    else:
        df["length_for_filter"] = df[SEQ].str.len()
    if "gc_content" not in df.columns:
        df["gc_content"] = df[SEQ].map(gc_content)
    if "uaug_count" not in df.columns:
        df["uaug_count"] = df[SEQ].str.count("ATG")
    if "has_proteomics_label" not in df.columns:
        df["has_proteomics_label"] = df.get("protein_abundance_rank", pd.Series(np.nan, index=df.index)).notna()
    return df

def filter_df(df, window):
    min_len, max_len = window["min_len"], window["max_len"]
    mask = df["length_for_filter"].between(min_len, max_len)
    mask &= df[SEQ].str.len() > 0
    mask &= ~df[SEQ].str.contains("N", regex=False)
    if window["gc_min"] is not None:
        mask &= df["gc_content"].between(window["gc_min"], window["gc_max"])
    if window["uaug_max"] is not None:
        mask &= df["uaug_count"] <= window["uaug_max"]
    if window.get("proteomics_only", False):
        mask &= df["has_proteomics_label"].astype(bool)
    if window.get("require_te_label", True) and "robust_public_te_rank" in df.columns:
        mask &= df["robust_public_te_rank"].notna()
    return df[mask].copy().reset_index(drop=True)

def diagnostics(df):
    windows = [
        ("all_label_rows", 0, 100000, None, None, None),
        ("50_100_strict", 50, 100, 0.30, 0.75, 1),
        ("40_200_strict", 40, 200, 0.30, 0.75, 1),
        ("20_300_relaxed", 20, 300, 0.25, 0.80, 3),
        ("20_500_relaxed", 20, 500, 0.25, 0.80, 3),
        ("20_1000_relaxed", 20, 1000, 0.20, 0.85, 5),
        ("proteomics_20_500_relaxed", 20, 500, 0.25, 0.80, 3),
    ]
    rows = []
    for name, a, b, gcmin, gcmax, uaug in windows:
        wd = {"min_len": a, "max_len": b, "gc_min": gcmin, "gc_max": gcmax, "uaug_max": uaug, "proteomics_only": name.startswith("proteomics")}
        sub = filter_df(df, wd)
        rows.append({
            "filter": name,
            "rows": len(sub),
            "proteomics_mapped_rows": int(sub["has_proteomics_label"].sum()) if "has_proteomics_label" in sub else np.nan,
            "proteomics_fraction": float(sub["has_proteomics_label"].mean()) if len(sub) and "has_proteomics_label" in sub else np.nan,
            "length_min": sub["length_for_filter"].min() if len(sub) else np.nan,
            "length_median": sub["length_for_filter"].median() if len(sub) else np.nan,
            "length_max": sub["length_for_filter"].max() if len(sub) else np.nan,
            "robust_rank_mean": sub["robust_public_te_rank"].mean() if "robust_public_te_rank" in sub else np.nan,
        })
    dd = pd.DataFrame(rows)
    OUT_DIAG.write_text(
        "Filter/window proteomics coverage diagnostics\n"
        + "="*90 + "\n"
        + dd.to_string(index=False) + "\n\n"
        + "Interpretation:\n"
        + "- If proteomics_mapped_rows rises strongly in relaxed windows, final 50-100 selection is losing proteomics coverage.\n"
        + "- If full/relaxed model does not improve gene_split Spearman, model ceiling is likely due to label/context noise.\n",
        encoding="utf-8"
    )
    print("[SAVED]", OUT_DIAG)
    print(dd.to_string(index=False))
    return dd

def plot_results(res):
    sub = res[res["split_mode"] == "gene_split"].copy()
    if sub.empty:
        return
    sub["label"] = sub["target"] + "\n" + sub["filter_name"] + "\n" + sub["model"]
    sub = sub.sort_values("spearman", ascending=True).tail(30)
    plt.figure(figsize=(12, max(6, 0.35 * len(sub))))
    plt.barh(sub["label"], sub["spearman"])
    plt.xlabel("Gene-split Spearman")
    plt.title("Filter/window sensitivity benchmark")
    plt.tight_layout()
    plt.savefig(OUT_PLOT, dpi=200)
    plt.close()

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--fast", action="store_true", help="Use k=3,4 only and fewer trees.")
    parser.add_argument("--full", action="store_true", help="Include slow all-length 20-1000 window.")
    args = parser.parse_args()

    df, label_path = load_label()
    df = prepare(df)
    diagnostics(df)

    k_values = (3,4) if args.fast else (3,4,5)
    n_estimators = 350 if args.fast else 700
    models = ["ExtraTrees", "RandomForest", "HistGradientBoosting"] if not args.fast else ["ExtraTrees", "RandomForest"]

    windows = [
        {"filter_name": "50_100_strict", "min_len": 50, "max_len": 100, "gc_min": 0.30, "gc_max": 0.75, "uaug_max": 1},
        {"filter_name": "40_200_strict", "min_len": 40, "max_len": 200, "gc_min": 0.30, "gc_max": 0.75, "uaug_max": 1},
        {"filter_name": "20_300_relaxed", "min_len": 20, "max_len": 300, "gc_min": 0.25, "gc_max": 0.80, "uaug_max": 3},
        {"filter_name": "20_500_relaxed", "min_len": 20, "max_len": 500, "gc_min": 0.25, "gc_max": 0.80, "uaug_max": 3},
        {"filter_name": "proteomics_20_500_relaxed", "min_len": 20, "max_len": 500, "gc_min": 0.25, "gc_max": 0.80, "uaug_max": 3, "proteomics_only": True},
    ]
    if args.full:
        windows.append({"filter_name": "20_1000_relaxed", "min_len": 20, "max_len": 1000, "gc_min": 0.20, "gc_max": 0.85, "uaug_max": 5})

    targets = [c for c in ["robust_public_te_rank", "multi_omics_utr_rank", "protein_residual_rank", "protein_abundance_rank"] if c in df.columns]

    results = []
    for win in windows:
        sub0 = filter_df(df, win)
        print("\n" + "="*90)
        print("[WINDOW]", win["filter_name"], "rows", len(sub0), "proteomics", int(sub0["has_proteomics_label"].sum()) if "has_proteomics_label" in sub0 else "NA")
        print("="*90)
        if len(sub0) < 500:
            print("[SKIP] too few rows")
            continue

        print("[FEATURES] k =", k_values)
        X = make_features(sub0, k_values=k_values, include_tail100=True)

        for target in targets:
            sub = sub0[pd.to_numeric(sub0[target], errors="coerce").notna()].copy().reset_index(drop=True)
            if len(sub) < 500:
                continue
            # Align X by sub index from sub0 before reset
            idx = sub0[pd.to_numeric(sub0[target], errors="coerce").notna()].index
            X_sub = X.loc[idx].reset_index(drop=True)
            y = pd.to_numeric(sub[target], errors="coerce").values

            # For protein-specific targets, skip non-proteomics windows unless enough mapped rows are present.
            if target.startswith("protein") and int(sub.get("has_proteomics_label", pd.Series(False, index=sub.index)).sum()) < 500:
                continue

            for split_mode in ["random", "gene_split"]:
                tr, te = split_idx(sub, split_mode)
                for model_name in models:
                    print("[FIT]", win["filter_name"], target, split_mode, model_name)
                    model = make_model(model_name, n_estimators=n_estimators)
                    model.fit(X_sub.iloc[tr], y[tr])
                    pred = np.clip(model.predict(X_sub.iloc[te]), 0, 1)
                    met = metrics(y[te], pred)
                    row = {
                        "filter_name": win["filter_name"],
                        "target": target,
                        "split_mode": split_mode,
                        "model": model_name,
                        "n_rows": len(sub),
                        "n_train": len(tr),
                        "n_test": len(te),
                        "proteomics_mapped_rows": int(sub["has_proteomics_label"].sum()) if "has_proteomics_label" in sub else np.nan,
                        **met,
                    }
                    results.append(row)
                    print("  spearman", round(met["spearman"], 4), "pearson", round(met["pearson"], 4), "top10", round(met["top10_enrichment"], 4))

    res = pd.DataFrame(results)
    res.to_csv(OUT_TABLE, index=False)
    plot_results(res)

    if len(res):
        summary = [
            "Filter/window sensitivity benchmark summary",
            "="*90,
            f"label_path: {label_path}",
            f"k_values: {k_values}",
            f"n_estimators: {n_estimators}",
            "",
            "[Top gene_split rows by Spearman]",
            res[res["split_mode"] == "gene_split"].sort_values("spearman", ascending=False).head(30).to_string(index=False),
            "",
            "[Top gene_split rows by top10_enrichment]",
            res[res["split_mode"] == "gene_split"].sort_values("top10_enrichment", ascending=False).head(30).to_string(index=False),
            "",
            f"Saved table: {OUT_TABLE}",
            f"Saved plot: {OUT_PLOT}",
            f"Saved diagnostics: {OUT_DIAG}",
        ]
    else:
        summary = ["No results generated."]
    OUT_SUMMARY.write_text("\n".join(summary), encoding="utf-8")
    print("[SAVED]", OUT_TABLE)
    print("[SAVED]", OUT_SUMMARY)
    print("[SAVED]", OUT_PLOT)

if __name__ == "__main__":
    main()
