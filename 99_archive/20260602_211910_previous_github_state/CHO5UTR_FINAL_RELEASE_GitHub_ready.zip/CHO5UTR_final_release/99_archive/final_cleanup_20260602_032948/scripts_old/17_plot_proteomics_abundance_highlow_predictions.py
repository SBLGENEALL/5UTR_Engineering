from __future__ import annotations

from pathlib import Path
from collections import Counter
from itertools import product
import math
import argparse
import warnings

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

from scipy.stats import spearmanr, pearsonr
from sklearn.model_selection import train_test_split
from sklearn.pipeline import Pipeline
from sklearn.impute import SimpleImputer
from sklearn.ensemble import (
    RandomForestRegressor,
    ExtraTreesRegressor,
    HistGradientBoostingRegressor,
    RandomForestClassifier,
    ExtraTreesClassifier,
    HistGradientBoostingClassifier,
)
from sklearn.metrics import (
    roc_auc_score,
    average_precision_score,
    roc_curve,
    precision_recall_curve,
    confusion_matrix,
    r2_score,
    mean_squared_error,
    mean_absolute_error,
)
import joblib

warnings.filterwarnings("ignore")

BASE = Path.cwd()
SEQ = "utr5_sequence_tss_corrected"

LABEL = BASE / "04_te_labeling/tables/tss_corrected_5utr_multiomics_labels.csv"
SEARCH = BASE / "06_modeling/tables/automl_autorank_model_search_results.csv"

OUTDIR = BASE / "06_modeling/plots/proteomics_abundance_highlow"
TABLEDIR = BASE / "06_modeling/tables"
MODELDIR = BASE / "06_modeling/models/proteomics_abundance_highlow"
OUTDIR.mkdir(parents=True, exist_ok=True)
TABLEDIR.mkdir(parents=True, exist_ok=True)
MODELDIR.mkdir(parents=True, exist_ok=True)

def clean_seq(x):
    if pd.isna(x):
        return ""
    return str(x).upper().replace("U", "T").replace(" ", "").replace("\n", "")

def gc_content(seq):
    seq = clean_seq(seq)
    return (seq.count("G") + seq.count("C")) / len(seq) if len(seq) else np.nan

def longest_run(seq, base):
    best = cur = 0
    for b in clean_seq(seq):
        if b == base:
            cur += 1
            best = max(best, cur)
        else:
            cur = 0
    return best

def count_uorf(seq):
    seq = clean_seq(seq)
    stops = {"TAA", "TAG", "TGA"}
    n, longest = 0, 0
    for i in range(max(0, len(seq) - 2)):
        if seq[i:i+3] == "ATG":
            for j in range(i + 3, len(seq) - 2, 3):
                if seq[j:j+3] in stops:
                    n += 1
                    longest = max(longest, j + 3 - i)
                    break
    return n, longest

def get_window(seq, mode):
    seq = clean_seq(seq)
    if mode == "full":
        return seq
    if mode == "tail100":
        return seq[-100:] if len(seq) > 100 else seq
    if mode == "head100":
        return seq[:100]
    if mode == "pad100":
        return seq[:100]
    raise ValueError(mode)

def kmer_features(seq, ks=(5,), prefix=""):
    seq = clean_seq(seq)
    out = {}
    for k in ks:
        all_kmers = ["".join(x) for x in product("ACGT", repeat=k)]
        cnt = Counter(seq[i:i+k] for i in range(max(0, len(seq)-k+1)) if set(seq[i:i+k]) <= set("ACGT"))
        total = sum(cnt.values())
        for km in all_kmers:
            out[f"{prefix}{k}mer_{km}"] = cnt.get(km, 0) / total if total else 0.0
    return out

def onehot100(seq, prefix="onehot_"):
    seq = clean_seq(seq)[:100]
    out = {}
    for i in range(100):
        b = seq[i] if i < len(seq) else "N"
        for x in "ACGT":
            out[f"{prefix}{i:03d}_{x}"] = 1.0 if b == x else 0.0
    return out

STRATEGIES = {
    "full_k5": {"strategy": "full_k5", "window_mode": "full", "kmers": [5], "onehot100": False},
    "full_k345": {"strategy": "full_k345", "window_mode": "full", "kmers": [3,4,5], "onehot100": False},
    "tail100_k5_plus_fullk5": {"strategy": "tail100_k5_plus_fullk5", "window_mode": "tail100", "kmers": [5], "onehot100": False, "add_full_kmer5": True},
    "tail100_k5_onehot": {"strategy": "tail100_k5_onehot", "window_mode": "tail100", "kmers": [5], "onehot100": True},
    "pad100_k5_onehot": {"strategy": "pad100_k5_onehot", "window_mode": "pad100", "kmers": [5], "onehot100": True},
}

def make_features(df, strategy):
    mode = strategy["window_mode"]
    ks = tuple(strategy["kmers"])
    use_onehot = strategy.get("onehot100", False)
    add_full_k5 = strategy.get("add_full_kmer5", False)

    rows = []
    for i, seq0 in enumerate(df[SEQ].map(clean_seq)):
        seq = get_window(seq0, mode)
        L = len(seq0)
        WL = len(seq)
        uorf, longest = count_uorf(seq0)

        r = {
            "length": L,
            "window_length": WL,
            "gc_content": gc_content(seq0),
            "window_gc": gc_content(seq),
            "uaug_count": seq0.count("ATG"),
            "window_uaug_count": seq.count("ATG"),
            "cpg_count": seq0.count("CG"),
            "window_cpg_count": seq.count("CG"),
            "first_aug_pos": seq0.find("ATG"),
            "aug_density": seq0.count("ATG") / L if L else 0,
            "uorf_count": uorf,
            "longest_uorf_len": longest,
        }

        for b in "ACGT":
            r[f"{b.lower()}_fraction"] = seq0.count(b) / L if L else 0.0
            r[f"window_{b.lower()}_fraction"] = seq.count(b) / WL if WL else 0.0
            r[f"poly{b}_max_run"] = longest_run(seq0, b)
            r[f"window_poly{b}_max_run"] = longest_run(seq, b)

        for w in [20, 30, 50, 100]:
            head = seq0[:w]
            tail = seq0[-w:] if L >= w else seq0
            r[f"head{w}_gc"] = gc_content(head)
            r[f"tail{w}_gc"] = gc_content(tail)
            r[f"head{w}_uaug"] = head.count("ATG")
            r[f"tail{w}_uaug"] = tail.count("ATG")

        r.update(kmer_features(seq, ks=ks, prefix=f"{mode}_"))

        if add_full_k5 and mode != "full":
            r.update(kmer_features(seq0, ks=(5,), prefix="full_"))

        if use_onehot:
            r.update(onehot100(seq, prefix=f"{mode}_onehot_"))

        rows.append(r)
        if (i + 1) % 5000 == 0:
            print(f"  feature rows {i+1:,}/{len(df):,}")

    return pd.DataFrame(rows)

def make_regressor(name, n_estimators=700, rs=42):
    if name == "RandomForest":
        return Pipeline([
            ("imputer", SimpleImputer(strategy="median")),
            ("model", RandomForestRegressor(n_estimators=n_estimators, max_features="sqrt", min_samples_leaf=5, random_state=rs, n_jobs=-1)),
        ])
    if name == "ExtraTrees":
        return Pipeline([
            ("imputer", SimpleImputer(strategy="median")),
            ("model", ExtraTreesRegressor(n_estimators=n_estimators, max_features="sqrt", min_samples_leaf=5, random_state=rs, n_jobs=-1)),
        ])
    if name == "HistGradientBoosting":
        return Pipeline([
            ("imputer", SimpleImputer(strategy="median")),
            ("model", HistGradientBoostingRegressor(max_iter=600, learning_rate=0.04, max_leaf_nodes=31, l2_regularization=0.03, random_state=rs)),
        ])
    raise ValueError(name)

def make_classifier(name, n_estimators=700, rs=42):
    if name == "RandomForest":
        return Pipeline([
            ("imputer", SimpleImputer(strategy="median")),
            ("model", RandomForestClassifier(n_estimators=n_estimators, max_features="sqrt", min_samples_leaf=5, class_weight="balanced", random_state=rs, n_jobs=-1)),
        ])
    if name == "ExtraTrees":
        return Pipeline([
            ("imputer", SimpleImputer(strategy="median")),
            ("model", ExtraTreesClassifier(n_estimators=n_estimators, max_features="sqrt", min_samples_leaf=5, class_weight="balanced", random_state=rs, n_jobs=-1)),
        ])
    if name == "HistGradientBoosting":
        return Pipeline([
            ("imputer", SimpleImputer(strategy="median")),
            ("model", HistGradientBoostingClassifier(max_iter=600, learning_rate=0.04, max_leaf_nodes=31, l2_regularization=0.03, random_state=rs)),
        ])
    raise ValueError(name)

def split_idx(df, rs=42, test_size=0.2):
    groups = df["gene_name"].astype(str).fillna("NA").values if "gene_name" in df.columns else df["utr_id"].astype(str).values
    unique = np.array(sorted(pd.unique(groups)))
    tr_g, te_g = train_test_split(unique, test_size=test_size, random_state=rs)
    return np.where(np.isin(groups, tr_g))[0], np.where(np.isin(groups, te_g))[0]

def prep(df):
    df = df.copy()
    df[SEQ] = df[SEQ].map(clean_seq)
    if "utr5_length_final" in df.columns:
        df["length_for_filter"] = df["utr5_length_final"]
    elif "utr5_length_tss_corrected" in df.columns:
        df["length_for_filter"] = df["utr5_length_tss_corrected"]
    else:
        df["length_for_filter"] = df[SEQ].str.len()
    if "gc_content" not in df.columns:
        df["gc_content"] = df[SEQ].map(gc_content)
    if "uaug_count" not in df.columns:
        df["uaug_count"] = df[SEQ].str.count("ATG")
    return df

def filter_df(df, name):
    if name == "50_100_strict":
        mask = df["length_for_filter"].between(50, 100) & df["gc_content"].between(0.30, 0.75) & (df["uaug_count"] <= 1)
    elif name == "40_200_strict":
        mask = df["length_for_filter"].between(40, 200) & df["gc_content"].between(0.30, 0.75) & (df["uaug_count"] <= 1)
    elif name == "20_500_relaxed":
        mask = df["length_for_filter"].between(20, 500) & df["gc_content"].between(0.25, 0.80) & (df["uaug_count"] <= 3)
    elif name == "proteomics_20_500_relaxed":
        mask = df["length_for_filter"].between(20, 500) & df["gc_content"].between(0.25, 0.80) & (df["uaug_count"] <= 3)
        if "has_proteomics_label" in df.columns:
            mask &= df["has_proteomics_label"].astype(bool)
    else:
        raise ValueError(name)
    mask &= df[SEQ].str.len() > 0
    mask &= ~df[SEQ].str.contains("N", regex=False)
    return df[mask].copy().reset_index(drop=True)

def choose_best_config(task, target, fallback):
    if not SEARCH.exists():
        return fallback

    s = pd.read_csv(SEARCH)
    s = s[(s["split_mode"] == "gene_split") & (s["task"] == task) & (s["target"] == target)].copy()
    if len(s) == 0:
        return fallback

    sort_col = "selection_metric" if "selection_metric" in s.columns else ("roc_auc" if task == "classification" else "spearman")
    s = s.sort_values(sort_col, ascending=False)
    r = s.iloc[0].to_dict()
    return {
        "filter_name": r.get("filter_name", fallback["filter_name"]),
        "strategy": r.get("strategy", fallback["strategy"]),
        "model": r.get("model", fallback["model"]),
        "n_estimators": int(r.get("n_estimators", fallback.get("n_estimators", 700))) if not pd.isna(r.get("n_estimators", np.nan)) else fallback.get("n_estimators", 700),
        "source": "automl_search",
        "validation_row": r,
    }

def jitter(x, amount=0.04, seed=42):
    rng = np.random.default_rng(seed)
    return x + rng.normal(0, amount, size=len(x))

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--target", default="protein_abundance_rank", choices=["protein_abundance_rank", "protein_residual_rank"])
    ap.add_argument("--filter", default="auto", help="auto or one of 50_100_strict, 40_200_strict, 20_500_relaxed, proteomics_20_500_relaxed")
    ap.add_argument("--strategy", default="auto", help="auto or strategy name such as full_k345/full_k5/tail100_k5_plus_fullk5")
    ap.add_argument("--model", default="auto", help="auto or RandomForest/ExtraTrees/HistGradientBoosting")
    ap.add_argument("--n-estimators", type=int, default=None)
    args = ap.parse_args()

    if not LABEL.exists():
        raise SystemExit(f"Missing label table: {LABEL}")

    df = prep(pd.read_csv(LABEL))
    target = args.target

    fallback_clf = {
        "filter_name": "40_200_strict",
        "strategy": "full_k5",
        "model": "RandomForest",
        "n_estimators": 700,
        "source": "fallback",
    }
    fallback_reg = {
        "filter_name": "50_100_strict",
        "strategy": "full_k345",
        "model": "RandomForest",
        "n_estimators": 700,
        "source": "fallback",
    }

    clf_cfg = choose_best_config("classification", target, fallback_clf)
    reg_cfg = choose_best_config("regression", target, fallback_reg)

    if args.filter != "auto":
        clf_cfg["filter_name"] = args.filter
        reg_cfg["filter_name"] = args.filter
    if args.strategy != "auto":
        clf_cfg["strategy"] = args.strategy
        reg_cfg["strategy"] = args.strategy
    if args.model != "auto":
        clf_cfg["model"] = args.model
        reg_cfg["model"] = args.model
    if args.n_estimators is not None:
        clf_cfg["n_estimators"] = args.n_estimators
        reg_cfg["n_estimators"] = args.n_estimators

    print("[CLASSIFIER CONFIG]", clf_cfg)
    print("[REGRESSION CONFIG]", reg_cfg)

    # Classification dataset: top 20% high vs bottom 30% low within filtered set.
    clf_df = filter_df(df, clf_cfg["filter_name"])
    clf_df = clf_df[pd.to_numeric(clf_df[target], errors="coerce").notna()].reset_index(drop=True)
    y_rank = pd.to_numeric(clf_df[target], errors="coerce").values
    hi = np.quantile(y_rank, 0.80)
    lo = np.quantile(y_rank, 0.30)
    cmask = (y_rank >= hi) | (y_rank <= lo)
    clf_df = clf_df.loc[cmask].reset_index(drop=True)
    yc = (pd.to_numeric(clf_df[target], errors="coerce").values >= hi).astype(int)
    clf_df["actual_class"] = np.where(yc == 1, "high", "low")

    Xc = make_features(clf_df, STRATEGIES[clf_cfg["strategy"]])
    tr, te = split_idx(clf_df)

    clf = make_classifier(clf_cfg["model"], n_estimators=int(clf_cfg["n_estimators"]))
    clf.fit(Xc.iloc[tr], yc[tr])
    prob = clf.predict_proba(Xc.iloc[te])[:, 1]
    pred_class = (prob >= 0.5).astype(int)

    clf_test = clf_df.iloc[te].copy()
    clf_test["actual_binary"] = yc[te]
    clf_test["predicted_high_probability"] = prob
    clf_test["predicted_binary_0p5"] = pred_class

    roc = roc_auc_score(yc[te], prob)
    ap_score = average_precision_score(yc[te], prob)
    cm = confusion_matrix(yc[te], pred_class)

    # Regression dataset
    reg_df = filter_df(df, reg_cfg["filter_name"])
    reg_df = reg_df[pd.to_numeric(reg_df[target], errors="coerce").notna()].reset_index(drop=True)
    yr = pd.to_numeric(reg_df[target], errors="coerce").values
    Xr = make_features(reg_df, STRATEGIES[reg_cfg["strategy"]])
    trr, ter = split_idx(reg_df)

    reg = make_regressor(reg_cfg["model"], n_estimators=int(reg_cfg["n_estimators"]))
    reg.fit(Xr.iloc[trr], yr[trr])
    pred_rank = np.clip(reg.predict(Xr.iloc[ter]), 0, 1)

    reg_test = reg_df.iloc[ter].copy()
    reg_test["true_rank"] = yr[ter]
    reg_test["predicted_rank"] = pred_rank

    sp = spearmanr(yr[ter], pred_rank).correlation
    pr = pearsonr(yr[ter], pred_rank)[0]
    r2 = r2_score(yr[ter], pred_rank)
    rmse = math.sqrt(mean_squared_error(yr[ter], pred_rank))
    mae = mean_absolute_error(yr[ter], pred_rank)

    # Save tables
    clf_path = TABLEDIR / f"proteomics_{target}_highlow_classifier_gene_split_predictions.csv"
    reg_path = TABLEDIR / f"proteomics_{target}_regression_gene_split_predictions.csv"
    clf_test.to_csv(clf_path, index=False)
    reg_test.to_csv(reg_path, index=False)

    joblib.dump({"model": clf, "config": clf_cfg, "target": target, "roc_auc": roc, "average_precision": ap_score}, MODELDIR / f"proteomics_{target}_highlow_classifier.joblib")
    joblib.dump({"model": reg, "config": reg_cfg, "target": target, "spearman": sp, "pearson": pr}, MODELDIR / f"proteomics_{target}_regressor.joblib")

    # Plot 1: probability by actual class
    low_prob = clf_test.loc[clf_test["actual_binary"] == 0, "predicted_high_probability"].values
    high_prob = clf_test.loc[clf_test["actual_binary"] == 1, "predicted_high_probability"].values

    plt.figure(figsize=(7, 6))
    plt.boxplot([low_prob, high_prob], labels=["Actual low", "Actual high"])
    plt.scatter(jitter(np.zeros(len(low_prob)) + 1), low_prob, s=12, alpha=0.45)
    plt.scatter(jitter(np.zeros(len(high_prob)) + 2), high_prob, s=12, alpha=0.45)
    plt.ylabel("Predicted probability of high proteomics abundance")
    plt.title(f"{target}: high/low classifier\nROC-AUC={roc:.3f}, AP={ap_score:.3f}, n_test={len(clf_test)}")
    plt.tight_layout()
    p1 = OUTDIR / f"proteomics_{target}_highlow_probability_by_actual_class.png"
    plt.savefig(p1, dpi=220)
    plt.close()

    # Plot 2: ROC and PR
    fpr, tpr, _ = roc_curve(yc[te], prob)
    precision, recall, _ = precision_recall_curve(yc[te], prob)

    plt.figure(figsize=(7, 6))
    plt.plot(fpr, tpr, label=f"ROC-AUC={roc:.3f}")
    plt.plot([0, 1], [0, 1], linestyle="--")
    plt.xlabel("False positive rate")
    plt.ylabel("True positive rate")
    plt.title(f"{target}: ROC curve")
    plt.legend()
    plt.tight_layout()
    p2 = OUTDIR / f"proteomics_{target}_highlow_ROC.png"
    plt.savefig(p2, dpi=220)
    plt.close()

    plt.figure(figsize=(7, 6))
    plt.plot(recall, precision, label=f"AP={ap_score:.3f}")
    plt.xlabel("Recall")
    plt.ylabel("Precision")
    plt.title(f"{target}: precision-recall curve")
    plt.legend()
    plt.tight_layout()
    p3 = OUTDIR / f"proteomics_{target}_highlow_precision_recall.png"
    plt.savefig(p3, dpi=220)
    plt.close()

    # Plot 3: regression predicted vs true
    plt.figure(figsize=(7, 6))
    plt.scatter(yr[ter], pred_rank, s=14, alpha=0.35)
    plt.plot([0, 1], [0, 1], linestyle="--")
    plt.xlabel(f"True {target}")
    plt.ylabel(f"Predicted {target}")
    plt.title(f"{target}: regression predicted vs true\nSpearman={sp:.3f}, Pearson={pr:.3f}, n_test={len(reg_test)}")
    plt.tight_layout()
    p4 = OUTDIR / f"proteomics_{target}_regression_predicted_vs_true.png"
    plt.savefig(p4, dpi=220)
    plt.close()

    # Plot 4: predicted distribution
    plt.figure(figsize=(8, 5))
    plt.hist(low_prob, bins=30, alpha=0.6, label="Actual low")
    plt.hist(high_prob, bins=30, alpha=0.6, label="Actual high")
    plt.xlabel("Predicted probability of high proteomics abundance")
    plt.ylabel("Count")
    plt.title(f"{target}: predicted probability distribution")
    plt.legend()
    plt.tight_layout()
    p5 = OUTDIR / f"proteomics_{target}_highlow_probability_histogram.png"
    plt.savefig(p5, dpi=220)
    plt.close()

    summary = [
        f"Proteomics {target} high/low prediction plot summary",
        "=" * 90,
        "",
        "[Classifier]",
        f"config: {clf_cfg}",
        f"gene_split test n: {len(clf_test)}",
        f"ROC-AUC: {roc:.4f}",
        f"Average precision: {ap_score:.4f}",
        f"Confusion matrix at 0.5 threshold [[TN, FP], [FN, TP]]: {cm.tolist()}",
        "",
        "[Regression]",
        f"config: {reg_cfg}",
        f"gene_split test n: {len(reg_test)}",
        f"Spearman: {sp:.4f}",
        f"Pearson: {pr:.4f}",
        f"R2: {r2:.4f}",
        f"RMSE: {rmse:.4f}",
        f"MAE: {mae:.4f}",
        "",
        "[Saved plots]",
        str(p1),
        str(p2),
        str(p3),
        str(p4),
        str(p5),
        "",
        "[Saved tables]",
        str(clf_path),
        str(reg_path),
    ]
    summary_path = TABLEDIR / f"proteomics_{target}_prediction_plot_summary.txt"
    summary_path.write_text("\n".join(summary), encoding="utf-8")

    print("\n".join(summary))
    print("[SAVED]", summary_path)

if __name__ == "__main__":
    main()
