from pathlib import Path
import subprocess
import sys

cmd = [sys.executable, "01_pipeline/scripts/13_make_hybrid_final_libraries.py"]
print("RUN", " ".join(cmd))
r = subprocess.run(cmd)
if r.returncode != 0:
    raise SystemExit("FAILED")
print("DONE")
