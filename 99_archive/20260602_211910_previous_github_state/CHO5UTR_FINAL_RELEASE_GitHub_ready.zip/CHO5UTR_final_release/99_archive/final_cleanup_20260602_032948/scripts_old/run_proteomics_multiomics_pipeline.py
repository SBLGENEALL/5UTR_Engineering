from pathlib import Path
import subprocess
import sys

steps = [
    "09_integrate_proteomics_multiomics.py",
    "10_model_multiomics_40_200bp.py",
    "11_select_1000_multiomics_proteomics_library.py",
]

script_dir = Path("01_pipeline") / "scripts"

for step in steps:
    print("\n" + "=" * 80)
    print("RUN", step)
    print("=" * 80)
    r = subprocess.run([sys.executable, str(script_dir / step)])
    if r.returncode != 0:
        raise SystemExit(f"FAILED: {step}")

print("\nDONE: proteomics multi-omics pipeline completed.")
