from pathlib import Path
import pandas as pd
import numpy as np

BASE = Path.cwd()
SEQ = "utr5_sequence_tss_corrected"

LABEL = BASE / "04_te_labeling/tables/tss_corrected_5utr_multiomics_labels.csv"
PUBLIC_LIB = BASE / "07_library_design/tables/selected_1000_50_100bp_publicTE_40_200train_model_assisted_library.csv"

OUT = BASE / "07_library_design/tables/selected_1000_50_100bp_proteomics_enriched_library.csv"
FA = BASE / "07_library_design/fasta/selected_1000_50_100bp_proteomics_enriched_library.fasta"
SUMMARY = BASE / "07_library_design/qc/selected_1000_50_100bp_proteomics_enriched_summary.txt"
OVERLAP = BASE / "07_library_design/qc/overlap_publicTE_vs_proteomics_enriched.txt"

OUT.parent.mkdir(parents=True, exist_ok=True)
FA.parent.mkdir(parents=True, exist_ok=True)
SUMMARY.parent.mkdir(parents=True, exist_ok=True)

def clean_seq(x):
    if pd.isna(x):
        return ""
    return str(x).upper().replace("U", "T").replace(" ", "").replace("\n", "")

def gc_content(seq):
    seq = clean_seq(seq)
    return (seq.count("G") + seq.count("C")) / len(seq) if len(seq) else np.nan

def write_fasta(df, path, seq_col=SEQ, id_col="utr_id"):
    with open(path, "w", encoding="utf-8") as out:
        for i, r in df.iterrows():
            uid = str(r.get(id_col, f"row_{i}")).replace(" ", "_").replace("/", "_")
            seq = clean_seq(r[seq_col])
            out.write(f">{uid}|{r.get('gene_name','NA')}|len={len(seq)}|group={r.get('library_group','NA')}\n")
            for j in range(0, len(seq), 80):
                out.write(seq[j:j+80] + "\n")

def forbidden_sites(seq):
    sites = {
        "BsaI_GGTCTC": "GGTCTC",
        "BsaI_GAGACC": "GAGACC",
        "BsmBI_CGTCTC": "CGTCTC",
        "BsmBI_GAGACG": "GAGACG",
        "EcoRI_GAATTC": "GAATTC",
        "XhoI_CTCGAG": "CTCGAG",
        "NheI_GCTAGC": "GCTAGC",
        "AgeI_ACCGGT": "ACCGGT",
        "NotI_GCGGCCGC": "GCGGCCGC",
    }
    seq = clean_seq(seq)
    return ";".join([name for name, site in sites.items() if site in seq])

def pick(pool, n, sort_cols, group, ascending=False):
    if len(pool) == 0 or n <= 0:
        return pool.head(0).copy()
    x = pool.sort_values(sort_cols, ascending=[ascending] * len(sort_cols)).head(n).copy()
    x["library_group"] = group
    return x

def main():
    if not LABEL.exists():
        raise SystemExit(f"Missing multiomics label file: {LABEL}")

    df = pd.read_csv(LABEL)
    df[SEQ] = df[SEQ].apply(clean_seq)

    if "utr5_length_final" in df.columns:
        df["length"] = df["utr5_length_final"]
    elif "utr5_length_tss_corrected" in df.columns:
        df["length"] = df["utr5_length_tss_corrected"]
    else:
        df["length"] = df[SEQ].str.len()

    if "gc_content" not in df.columns:
        df["gc_content"] = df[SEQ].apply(gc_content)
    if "uaug_count" not in df.columns:
        df["uaug_count"] = df[SEQ].str.count("ATG")
    if "has_proteomics_label" not in df.columns:
        df["has_proteomics_label"] = df["protein_abundance_rank"].notna() | df["protein_residual_rank"].notna()

    df["forbidden_sites"] = df[SEQ].apply(forbidden_sites)
    df["has_forbidden_site"] = df["forbidden_sites"].astype(str).str.len() > 0

    # Strict 50-100 bp synthesis/QC filter.
    base = df[
        df["length"].between(50, 100)
        & df["gc_content"].between(0.30, 0.75)
        & (df["uaug_count"] <= 1)
        & (~df["has_forbidden_site"])
        & (~df[SEQ].str.contains("N", regex=False))
        & df["robust_public_te_rank"].notna()
    ].copy()

    # Exact duplicate sequence removal.
    base = base.sort_values(["robust_public_te_rank"], ascending=False).drop_duplicates(subset=[SEQ]).copy()

    # This score intentionally makes proteomics stronger among mapped genes.
    # It is NOT used as a universal label because unmapped rows dominate the full dataset.
    base["protein_residual_rank_filled"] = base["protein_residual_rank"].fillna(0)
    base["protein_abundance_rank_filled"] = base["protein_abundance_rank"].fillna(0)
    base["day_consensus_TE_rank_filled"] = base["day_consensus_TE_rank"].fillna(0)
    base["tss_confidence_score_filled"] = base["tss_confidence_score"].fillna(0)
    base["ribo_abundance_rank_filled"] = base["ribo_abundance_rank"].fillna(0)

    base["proteomics_enriched_score"] = (
        0.35 * base["robust_public_te_rank"].fillna(0)
        + 0.25 * base["protein_residual_rank_filled"]
        + 0.20 * base["protein_abundance_rank_filled"]
        + 0.10 * base["day_consensus_TE_rank_filled"]
        + 0.05 * base["tss_confidence_score_filled"]
        + 0.05 * base["ribo_abundance_rank_filled"]
    )

    mapped = base[base["has_proteomics_label"].astype(bool)].copy()
    unmapped = base[~base["has_proteomics_label"].astype(bool)].copy()

    print("Total 50-100 candidates:", len(base))
    print("Proteomics-mapped 50-100 candidates:", len(mapped))
    print("Unmapped 50-100 candidates:", len(unmapped))

    selected = []
    used = set()

    def avail(pool):
        return pool[~pool[SEQ].isin(used)].copy()

    def add(x):
        if len(x):
            selected.append(x)
            used.update(x[SEQ].tolist())

    # Quotas designed to force proteomics prior into the final design.
    # Total = 1000
    quota = {
        "A_mapped_TE_protein_consensus": 250,
        "B_protein_residual_high_TE_supported": 250,
        "C_protein_abundance_high_TE_supported": 150,
        "D_proteomics_orthogonal_midTE": 125,
        "E_TSS_supported_mapped_high": 100,
        "F_publicTE_high_unmapped_fill": 100,
        "G_low_TE_negative": 25,
    }

    # A: high combined score among mapped candidates
    add(pick(
        avail(mapped),
        quota["A_mapped_TE_protein_consensus"],
        ["proteomics_enriched_score", "robust_public_te_rank"],
        "A_mapped_TE_protein_consensus"
    ))

    # B: protein/RNA residual high + TE reasonably high
    pool = avail(mapped)
    pool = pool[(pool["protein_residual_rank"].fillna(0) >= 0.75) & (pool["robust_public_te_rank"].fillna(0) >= 0.55)]
    add(pick(
        pool,
        quota["B_protein_residual_high_TE_supported"],
        ["protein_residual_rank", "robust_public_te_rank", "proteomics_enriched_score"],
        "B_protein_residual_high_TE_supported"
    ))

    # C: high protein abundance + TE reasonably high
    pool = avail(mapped)
    pool = pool[(pool["protein_abundance_rank"].fillna(0) >= 0.75) & (pool["robust_public_te_rank"].fillna(0) >= 0.55)]
    add(pick(
        pool,
        quota["C_protein_abundance_high_TE_supported"],
        ["protein_abundance_rank", "robust_public_te_rank", "proteomics_enriched_score"],
        "C_protein_abundance_high_TE_supported"
    ))

    # D: orthogonal proteomics signal: protein residual high, but not already extreme robust TE.
    # This creates a different comparison set rather than simply reproducing publicTE top candidates.
    pool = avail(mapped)
    pool = pool[
        (pool["protein_residual_rank"].fillna(0) >= 0.80)
        & (pool["robust_public_te_rank"].fillna(0).between(0.35, 0.85))
    ]
    add(pick(
        pool,
        quota["D_proteomics_orthogonal_midTE"],
        ["protein_residual_rank", "protein_abundance_rank", "proteomics_enriched_score"],
        "D_proteomics_orthogonal_midTE"
    ))

    # E: TSS-supported mapped high candidates
    pool = avail(mapped)
    if "tss_confidence" in pool.columns:
        pool = pool[
            (pool["tss_confidence"].astype(str) == "tss_supported_with_signal")
            & (pool["proteomics_enriched_score"].fillna(0) >= 0.60)
        ]
    add(pick(
        pool,
        quota["E_TSS_supported_mapped_high"],
        ["proteomics_enriched_score", "robust_public_te_rank"],
        "E_TSS_supported_mapped_high"
    ))

    # F: keep some high publicTE candidates even if proteomics is unavailable.
    pool = avail(unmapped)
    pool = pool[pool["robust_public_te_rank"].fillna(0) >= 0.85]
    add(pick(
        pool,
        quota["F_publicTE_high_unmapped_fill"],
        ["robust_public_te_rank", "day_consensus_TE_rank"],
        "F_publicTE_high_unmapped_fill"
    ))

    # G: negative controls, preferably mapped if available
    pool = avail(mapped)
    pool = pool[pool["robust_public_te_rank"].fillna(1) <= 0.25]
    neg = pick(pool, quota["G_low_TE_negative"], ["gc_content"], "G_low_TE_negative")
    if len(neg) < quota["G_low_TE_negative"]:
        pool2 = avail(base)
        pool2 = pool2[pool2["robust_public_te_rank"].fillna(1) <= 0.25]
        extra = pick(pool2, quota["G_low_TE_negative"] - len(neg), ["gc_content"], "G_low_TE_negative")
        neg = pd.concat([neg, extra]).drop_duplicates(subset=[SEQ])
    add(neg)

    out = pd.concat(selected).drop_duplicates(subset=[SEQ]) if selected else base.head(0)

    # If quotas fail due to sparse mapped rows, fill with mapped high proteomics_enriched_score first,
    # then publicTE high from all candidates.
    if len(out) < 1000:
        fill1 = avail(mapped).sort_values(["proteomics_enriched_score", "robust_public_te_rank"], ascending=False).head(1000 - len(out)).copy()
        fill1["library_group"] = "H_fill_mapped_high_score"
        add(fill1)
        out = pd.concat(selected).drop_duplicates(subset=[SEQ])

    if len(out) < 1000:
        fill2 = avail(base).sort_values(["robust_public_te_rank", "proteomics_enriched_score"], ascending=False).head(1000 - len(out)).copy()
        fill2["library_group"] = "I_fill_publicTE_high"
        add(fill2)
        out = pd.concat(selected).drop_duplicates(subset=[SEQ])

    out = out.head(1000).copy()
    out["library_index"] = range(1, len(out) + 1)

    front = [c for c in [
        "library_index", "library_group", "utr_id", "gene_id", "gene_name", SEQ,
        "length", "gc_content", "uaug_count", "tss_confidence",
        "robust_public_te_rank", "multi_omics_utr_rank", "proteomics_enriched_score",
        "protein_residual_rank", "protein_abundance_rank", "day_consensus_TE_rank",
        "ribo_abundance_rank", "has_proteomics_label", "proteomics_mapping_mode",
        "forbidden_sites"
    ] if c in out.columns]
    out = out[front + [c for c in out.columns if c not in front]]

    out.to_csv(OUT, index=False)
    write_fasta(out, FA, SEQ, "utr_id")

    lines = [
        "Proteomics-enriched 50-100 bp UTR library summary",
        "=" * 80,
        f"Total selected: {len(out)}",
        f"Total 50-100 candidates passing QC: {len(base)}",
        f"Proteomics-mapped 50-100 candidates passing QC: {len(mapped)}",
        f"Unmapped 50-100 candidates passing QC: {len(unmapped)}",
        "",
        "[Group counts]",
        out["library_group"].value_counts().to_string(),
        "",
        "[has_proteomics_label]",
        out["has_proteomics_label"].value_counts(dropna=False).to_string(),
        "",
        "[proteomics_mapping_mode]",
        out["proteomics_mapping_mode"].value_counts(dropna=False).to_string() if "proteomics_mapping_mode" in out.columns else "NA",
        "",
        "[Length]",
        out["length"].describe().to_string(),
        "",
        "[Robust public TE rank]",
        out["robust_public_te_rank"].describe().to_string(),
        "",
        "[Protein residual rank]",
        out["protein_residual_rank"].describe().to_string(),
        "",
        "[Protein abundance rank]",
        out["protein_abundance_rank"].describe().to_string(),
        "",
        "[Proteomics enriched score]",
        out["proteomics_enriched_score"].describe().to_string(),
        "",
        "[uAUG]",
        out["uaug_count"].value_counts().sort_index().to_string(),
    ]

    SUMMARY.write_text("\n".join(lines), encoding="utf-8")

    # Compare with prior publicTE library if available
    if PUBLIC_LIB.exists():
        pub = pd.read_csv(PUBLIC_LIB)
        pub[SEQ] = pub[SEQ].apply(clean_seq)
        A = set(pub[SEQ])
        B = set(out[SEQ])
        overlap_lines = [
            "Overlap: publicTE library vs proteomics-enriched library",
            "=" * 80,
            f"publicTE_n: {len(A)}",
            f"proteomics_enriched_n: {len(B)}",
            f"overlap: {len(A & B)}",
            f"publicTE_only: {len(A - B)}",
            f"proteomics_enriched_only: {len(B - A)}",
            f"overlap_fraction_of_1000: {len(A & B) / 1000:.3f}",
        ]
        OVERLAP.write_text("\n".join(overlap_lines), encoding="utf-8")

    print("[SAVED]", OUT)
    print("[SAVED]", FA)
    print("[SAVED]", SUMMARY)
    if PUBLIC_LIB.exists():
        print("[SAVED]", OVERLAP)
    print(out["library_group"].value_counts().to_string())

if __name__ == "__main__":
    main()
