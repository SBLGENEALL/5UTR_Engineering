from __future__ import annotations

from pathlib import Path
from collections import Counter
from itertools import product
import argparse
import json
import math
import shutil
import subprocess
import warnings

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

from scipy.stats import spearmanr, pearsonr
from sklearn.model_selection import train_test_split
from sklearn.pipeline import Pipeline
from sklearn.impute import SimpleImputer
from sklearn.preprocessing import StandardScaler
from sklearn.ensemble import (
    ExtraTreesRegressor,
    RandomForestRegressor,
    HistGradientBoostingRegressor,
    ExtraTreesClassifier,
    RandomForestClassifier,
    HistGradientBoostingClassifier,
)
from sklearn.neural_network import MLPRegressor, MLPClassifier
from sklearn.metrics import (
    r2_score,
    mean_squared_error,
    mean_absolute_error,
    roc_auc_score,
    average_precision_score,
)
import joblib

warnings.filterwarnings("ignore")

BASE = Path.cwd()
SEQ_COL = "utr5_sequence_tss_corrected"
LABEL_PATH = BASE / "04_te_labeling/tables/tss_corrected_5utr_robust_public_te_labels.csv"
OUT = BASE / "06_modeling"
for d in ["tables", "models", "plots"]:
    (OUT / d).mkdir(parents=True, exist_ok=True)

CACHE_DIR = BASE / "05_feature_extraction/rnafold"
CACHE_DIR.mkdir(parents=True, exist_ok=True)
MFE_CACHE_PATH = CACHE_DIR / "mfe_cache.csv"


def clean_seq(x) -> str:
    if pd.isna(x):
        return ""
    return str(x).upper().replace("U", "T").replace(" ", "").replace("\n", "")


def gc(seq: str) -> float:
    seq = clean_seq(seq)
    return (seq.count("G") + seq.count("C")) / len(seq) if len(seq) else np.nan


def longest_run(seq: str, base: str) -> int:
    best = cur = 0
    for b in clean_seq(seq):
        if b == base:
            cur += 1
            best = max(best, cur)
        else:
            cur = 0
    return best


def count_uorf(seq: str):
    seq = clean_seq(seq)
    stops = {"TAA", "TAG", "TGA"}
    n = 0
    longest = 0
    for i in range(max(0, len(seq) - 2)):
        if seq[i:i+3] == "ATG":
            for j in range(i + 3, len(seq) - 2, 3):
                if seq[j:j+3] in stops:
                    n += 1
                    longest = max(longest, j + 3 - i)
                    break
    return n, longest


def seq_window(seq: str, mode: str, max_len: int = 100) -> str:
    seq = clean_seq(seq)
    if mode == "full":
        return seq
    if mode == "head100":
        return seq[:max_len]
    if mode == "tail100":
        return seq[-max_len:] if len(seq) > max_len else seq
    if mode == "pad100":
        return seq[:max_len]
    raise ValueError(f"Unknown window mode: {mode}")


def kmer_features(seq: str, ks=(3, 4, 5), prefix=""):
    seq = clean_seq(seq)
    out = {}
    alphabet = "ACGT"
    for k in ks:
        all_kmers = ["".join(x) for x in product(alphabet, repeat=k)]
        cnt = Counter(seq[i:i+k] for i in range(max(0, len(seq)-k+1)) if set(seq[i:i+k]) <= set(alphabet))
        total = sum(cnt.values())
        for km in all_kmers:
            out[f"{prefix}{k}mer_{km}"] = cnt.get(km, 0) / total if total else 0.0
    return out


def onehot100_features(seq: str, prefix="onehot_", max_len=100):
    seq = clean_seq(seq)[:max_len]
    out = {}
    for i in range(max_len):
        b = seq[i] if i < len(seq) else "N"
        for x in "ACGT":
            out[f"{prefix}{i:03d}_{x}"] = 1.0 if b == x else 0.0
    return out


def load_mfe_cache():
    if MFE_CACHE_PATH.exists():
        try:
            df = pd.read_csv(MFE_CACHE_PATH)
            return dict(zip(df["seq"], df["mfe"]))
        except Exception:
            return {}
    return {}


def save_mfe_cache(cache):
    pd.DataFrame({"seq": list(cache.keys()), "mfe": list(cache.values())}).to_csv(MFE_CACHE_PATH, index=False)


def rnafold_mfe(seq: str, cache: dict, exe="RNAfold"):
    seq = clean_seq(seq)
    if not seq:
        return np.nan
    if seq in cache:
        return cache[seq]
    try:
        p = subprocess.run([exe, "--noPS"], input=seq + "\n", text=True, capture_output=True, timeout=30)
        if p.returncode != 0:
            val = np.nan
        else:
            import re
            lines = p.stdout.strip().splitlines()
            if len(lines) < 2:
                val = np.nan
            else:
                m = re.search(r"\(([-+]?\d+\.?\d*)\)", lines[1])
                val = float(m.group(1)) if m else np.nan
    except Exception:
        val = np.nan
    cache[seq] = val
    return val


def make_feature_table(df, strategy, use_rnafold=False, mfe_cache=None):
    mode = strategy["window_mode"]
    use_onehot = strategy["use_onehot"]
    use_full_kmer = strategy.get("use_full_kmer", True)
    rows = []

    if use_rnafold and shutil.which("RNAfold") is None:
        print("[WARN] RNAfold not found in PATH. RNAfold features will be skipped.")
        use_rnafold = False

    for i, seq0 in enumerate(df[SEQ_COL].map(clean_seq)):
        wseq = seq_window(seq0, mode, 100)
        L = len(seq0)
        WL = len(wseq)

        r = {
            "utr5_length": L,
            "window_length": WL,
            "gc_content": gc(seq0),
            "window_gc": gc(wseq),
            "uaug_count": seq0.count("ATG"),
            "window_uaug_count": wseq.count("ATG"),
            "cpg_count": seq0.count("CG"),
            "window_cpg_count": wseq.count("CG"),
            "first_aug_pos": seq0.find("ATG"),
            "aug_density": seq0.count("ATG") / L if L else 0,
        }

        uorf, long = count_uorf(seq0)
        r["uorf_count"] = uorf
        r["longest_uorf_len"] = long

        for b in "ACGT":
            r[f"{b.lower()}_fraction"] = seq0.count(b) / L if L else 0
            r[f"window_{b.lower()}_fraction"] = wseq.count(b) / WL if WL else 0
            r[f"poly{b}_max_run"] = longest_run(seq0, b)
            r[f"window_poly{b}_max_run"] = longest_run(wseq, b)

        for size in [20, 30, 50]:
            head = seq0[:size]
            tail = seq0[-size:] if L >= size else seq0
            r[f"head{size}_gc"] = gc(head)
            r[f"tail{size}_gc"] = gc(tail)
            r[f"head{size}_uaug"] = head.count("ATG")
            r[f"tail{size}_uaug"] = tail.count("ATG")

        if use_full_kmer:
            r.update(kmer_features(wseq, ks=(3, 4, 5), prefix=f"{mode}_"))

        if use_onehot:
            r.update(onehot100_features(wseq, prefix=f"{mode}_onehot_"))

        if use_rnafold:
            mfe_full = rnafold_mfe(seq0, mfe_cache)
            mfe_window = rnafold_mfe(wseq, mfe_cache)
            r["mfe_full"] = mfe_full
            r["mfe_full_per_nt"] = mfe_full / L if L and pd.notna(mfe_full) else np.nan
            r["mfe_window"] = mfe_window
            r["mfe_window_per_nt"] = mfe_window / WL if WL and pd.notna(mfe_window) else np.nan
            for size in [30, 50]:
                head = seq0[:size]
                tail = seq0[-size:] if L >= size else seq0
                hm = rnafold_mfe(head, mfe_cache)
                tm = rnafold_mfe(tail, mfe_cache)
                r[f"mfe_head{size}"] = hm
                r[f"mfe_head{size}_per_nt"] = hm / len(head) if len(head) and pd.notna(hm) else np.nan
                r[f"mfe_tail{size}"] = tm
                r[f"mfe_tail{size}_per_nt"] = tm / len(tail) if len(tail) and pd.notna(tm) else np.nan

        rows.append(r)
        if (i + 1) % 2000 == 0:
            print(f"  feature rows {i+1:,}/{len(df):,} for {strategy['name']}")

    return pd.DataFrame(rows)


def make_regressor(name, rs, n_estimators=500, mlp_iter=300):
    if name == "ExtraTrees":
        return Pipeline([
            ("imputer", SimpleImputer(strategy="median")),
            ("model", ExtraTreesRegressor(n_estimators=n_estimators, max_features="sqrt", min_samples_leaf=5, random_state=rs, n_jobs=-1)),
        ])
    if name == "RandomForest":
        return Pipeline([
            ("imputer", SimpleImputer(strategy="median")),
            ("model", RandomForestRegressor(n_estimators=n_estimators, max_features="sqrt", min_samples_leaf=5, random_state=rs, n_jobs=-1)),
        ])
    if name == "HistGradientBoosting":
        return Pipeline([
            ("imputer", SimpleImputer(strategy="median")),
            ("model", HistGradientBoostingRegressor(max_iter=600, learning_rate=0.04, max_leaf_nodes=31, l2_regularization=0.03, random_state=rs)),
        ])
    if name == "MLPRegressor":
        return Pipeline([
            ("imputer", SimpleImputer(strategy="median")),
            ("scaler", StandardScaler()),
            ("model", MLPRegressor(hidden_layer_sizes=(256, 128, 64), activation="relu", alpha=1e-4, learning_rate_init=1e-3, max_iter=mlp_iter, early_stopping=True, random_state=rs)),
        ])
    raise ValueError(name)


def make_classifier(name, rs, n_estimators=500, mlp_iter=300):
    if name == "ExtraTrees":
        return Pipeline([
            ("imputer", SimpleImputer(strategy="median")),
            ("model", ExtraTreesClassifier(n_estimators=n_estimators, max_features="sqrt", min_samples_leaf=5, random_state=rs, n_jobs=-1, class_weight="balanced")),
        ])
    if name == "RandomForest":
        return Pipeline([
            ("imputer", SimpleImputer(strategy="median")),
            ("model", RandomForestClassifier(n_estimators=n_estimators, max_features="sqrt", min_samples_leaf=5, random_state=rs, n_jobs=-1, class_weight="balanced")),
        ])
    if name == "HistGradientBoosting":
        return Pipeline([
            ("imputer", SimpleImputer(strategy="median")),
            ("model", HistGradientBoostingClassifier(max_iter=600, learning_rate=0.04, max_leaf_nodes=31, l2_regularization=0.03, random_state=rs)),
        ])
    if name == "MLPClassifier":
        return Pipeline([
            ("imputer", SimpleImputer(strategy="median")),
            ("scaler", StandardScaler()),
            ("model", MLPClassifier(hidden_layer_sizes=(256, 128, 64), activation="relu", alpha=1e-4, learning_rate_init=1e-3, max_iter=mlp_iter, early_stopping=True, random_state=rs)),
        ])
    raise ValueError(name)


def split_indices(df, mode, rs=42, test_size=0.2):
    if mode == "random":
        idx = np.arange(len(df))
        return train_test_split(idx, test_size=test_size, random_state=rs)
    groups = df["gene_name"].astype(str).fillna("NA").values if "gene_name" in df.columns else df["utr_id"].astype(str).values
    unique = np.array(sorted(pd.unique(groups)))
    tr_g, te_g = train_test_split(unique, test_size=test_size, random_state=rs)
    return np.where(np.isin(groups, tr_g))[0], np.where(np.isin(groups, te_g))[0]


def reg_metrics(y, pred):
    out = {
        "spearman": spearmanr(y, pred).correlation if len(y) >= 3 else np.nan,
        "pearson": pearsonr(y, pred)[0] if len(y) >= 3 else np.nan,
        "r2": r2_score(y, pred),
        "rmse": float(math.sqrt(mean_squared_error(y, pred))),
        "mae": float(mean_absolute_error(y, pred)),
    }
    for frac in [0.05, 0.10, 0.20]:
        k = max(1, int(len(y) * frac))
        top = np.argsort(pred)[-k:]
        thr = np.quantile(y, 1 - frac)
        out[f"top{int(frac*100)}_enrichment"] = float(np.mean(y[top] >= thr))
    return out


def plot_benchmark(reg_df):
    fig_path = OUT / "plots/model_strategy_gene_split_spearman_FIXED.png"
    sub = reg_df[reg_df["split_mode"] == "gene_split"].copy()
    if sub.empty:
        return
    sub["label"] = sub["strategy"] + "\n" + sub["model"]
    sub = sub.sort_values("spearman", ascending=True).tail(20)
    plt.figure(figsize=(12, max(5, 0.35 * len(sub))))
    plt.barh(sub["label"], sub["spearman"])
    plt.xlabel("Gene-split Spearman")
    plt.title("Model strategy benchmark")
    plt.tight_layout()
    plt.savefig(fig_path, dpi=200)
    plt.close()


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--rnafold", action="store_true", help="Add RNAfold MFE features if RNAfold is installed.")
    parser.add_argument("--quick", action="store_true", help="Run fewer strategies and models for quick testing.")
    parser.add_argument("--n-estimators", type=int, default=500)
    parser.add_argument("--mlp-max-iter", type=int, default=300)
    args = parser.parse_args()

    if not LABEL_PATH.exists():
        raise SystemExit(f"Missing label file: {LABEL_PATH}")

    cfg_path = BASE / "01_pipeline/config/project_config.json"
    cfg = json.loads(cfg_path.read_text(encoding="utf-8")) if cfg_path.exists() else {}
    rs = int(cfg.get("modeling", {}).get("random_state", 42))
    test_size = float(cfg.get("modeling", {}).get("test_size", 0.2))
    target = cfg.get("modeling", {}).get("target_rank_column", "robust_public_te_rank")

    print("[1] Load label table:", LABEL_PATH)
    labels = pd.read_csv(LABEL_PATH)
    labels[SEQ_COL] = labels[SEQ_COL].map(clean_seq)
    labels["seq_len"] = labels[SEQ_COL].str.len()

    if "gc_content" not in labels.columns:
        labels["gc_content"] = labels[SEQ_COL].map(gc)
    if "uaug_count" not in labels.columns:
        labels["uaug_count"] = labels[SEQ_COL].str.count("ATG")

    base_mask = (
        labels[target].notna()
        & labels["gc_content"].between(0.30, 0.75)
        & (labels["uaug_count"] <= 1)
        & (~labels[SEQ_COL].str.contains("N", regex=False))
    )
    if "has_rna_label" in labels.columns:
        base_mask &= labels["has_rna_label"].astype(bool)
    if "has_ribo_label" in labels.columns:
        base_mask &= labels["has_ribo_label"].astype(bool)

    labels = labels[base_mask].copy().reset_index(drop=True)
    print("eligible rows:", len(labels))

    strategies = [
        {"name": "S1_50_100_full_kmer", "min_len": 50, "max_len": 100, "window_mode": "full", "use_onehot": False, "use_full_kmer": True},
        {"name": "S2_50_100_pad100_onehot", "min_len": 50, "max_len": 100, "window_mode": "pad100", "use_onehot": True, "use_full_kmer": True},
        {"name": "S3_40_120_tail100_onehot", "min_len": 40, "max_len": 120, "window_mode": "tail100", "use_onehot": True, "use_full_kmer": True},
        {"name": "S4_40_200_tail100_onehot", "min_len": 40, "max_len": 200, "window_mode": "tail100", "use_onehot": True, "use_full_kmer": True},
        {"name": "S5_40_200_head100_onehot", "min_len": 40, "max_len": 200, "window_mode": "head100", "use_onehot": True, "use_full_kmer": True},
        {"name": "S6_40_200_full_kmer", "min_len": 40, "max_len": 200, "window_mode": "full", "use_onehot": False, "use_full_kmer": True},
    ]

    if args.quick:
        strategies = [strategies[0], strategies[3], strategies[5]]
        reg_models = ["ExtraTrees", "HistGradientBoosting", "MLPRegressor"]
        clf_models = ["RandomForest", "MLPClassifier"]
    else:
        reg_models = ["ExtraTrees", "RandomForest", "HistGradientBoosting", "MLPRegressor"]
        clf_models = ["ExtraTrees", "RandomForest", "HistGradientBoosting", "MLPClassifier"]

    mfe_cache = load_mfe_cache() if args.rnafold else {}
    reg_rows = []
    clf_rows = []
    best = None
    best_payload = None

    for strat in strategies:
        mask = labels["seq_len"].between(strat["min_len"], strat["max_len"])
        df = labels[mask].copy().reset_index(drop=True)
        if len(df) < 500:
            print("[SKIP] too few rows:", strat["name"], len(df))
            continue
        y = pd.to_numeric(df[target], errors="coerce").values

        print("\n" + "=" * 80)
        print("[STRATEGY]", strat["name"], "rows", len(df))
        print("=" * 80)

        X = make_feature_table(df, strat, use_rnafold=args.rnafold, mfe_cache=mfe_cache)
        feature_cols = X.columns.tolist()

        for split_mode in ["random", "gene_split"]:
            tr, te = split_indices(df, split_mode, rs=rs, test_size=test_size)

            for model_name in reg_models:
                print("[REG]", strat["name"], split_mode, model_name)
                model = make_regressor(model_name, rs, n_estimators=args.n_estimators, mlp_iter=args.mlp_max_iter)
                model.fit(X.iloc[tr], y[tr])
                pred = np.clip(model.predict(X.iloc[te]), 0, 1)
                met = reg_metrics(y[te], pred)
                row = {
                    "strategy": strat["name"],
                    "length_min": strat["min_len"],
                    "length_max": strat["max_len"],
                    "window_mode": strat["window_mode"],
                    "use_onehot": strat["use_onehot"],
                    "use_rnafold": bool(args.rnafold),
                    "split_mode": split_mode,
                    "model": model_name,
                    "n_train": len(tr),
                    "n_test": len(te),
                    **met,
                }
                reg_rows.append(row)
                print("  spearman", round(met["spearman"], 4), "pearson", round(met["pearson"], 4), "top10", round(met["top10_enrichment"], 4))

                if split_mode == "gene_split" and (best is None or met["spearman"] > best["spearman"]):
                    best = {**row}
                    best_payload = {
                        "strategy": strat.copy(),
                        "model_name": model_name,
                        "feature_cols": feature_cols,
                        "df": df.copy(),
                        "X": X.copy(),
                    }

            # FIXED classification: make class_mask on df index and use X.loc[class_mask].
            hi = np.quantile(y, 0.80)
            lo = np.quantile(y, 0.30)
            class_mask = (df[target] >= hi) | (df[target] <= lo)
            cdf = df.loc[class_mask].copy().reset_index(drop=True)
            Xc = X.loc[class_mask].copy().reset_index(drop=True)
            yc = (cdf[target].values >= hi).astype(int)

            if len(cdf) > 200 and len(np.unique(yc)) == 2:
                if split_mode == "random":
                    idx = np.arange(len(cdf))
                    ctr, cte = train_test_split(idx, test_size=test_size, random_state=rs, stratify=yc)
                else:
                    ctr, cte = split_indices(cdf, split_mode, rs=rs, test_size=test_size)

                for model_name in clf_models:
                    print("[CLF_FIXED]", strat["name"], split_mode, model_name)
                    clf = make_classifier(model_name, rs, n_estimators=args.n_estimators, mlp_iter=args.mlp_max_iter)
                    clf.fit(Xc.iloc[ctr], yc[ctr])
                    proba = clf.predict_proba(Xc.iloc[cte])[:, 1]
                    clf_rows.append({
                        "strategy": strat["name"],
                        "length_min": strat["min_len"],
                        "length_max": strat["max_len"],
                        "window_mode": strat["window_mode"],
                        "use_onehot": strat["use_onehot"],
                        "use_rnafold": bool(args.rnafold),
                        "split_mode": split_mode,
                        "model": model_name,
                        "n_train": len(ctr),
                        "n_test": len(cte),
                        "roc_auc": roc_auc_score(yc[cte], proba),
                        "average_precision": average_precision_score(yc[cte], proba),
                    })

        if args.rnafold:
            save_mfe_cache(mfe_cache)

    reg_df = pd.DataFrame(reg_rows)
    clf_df = pd.DataFrame(clf_rows)
    reg_path = OUT / "tables/model_strategy_benchmark_regression_FIXED.csv"
    clf_path = OUT / "tables/model_strategy_benchmark_classification_FIXED.csv"
    reg_df.to_csv(reg_path, index=False)
    clf_df.to_csv(clf_path, index=False)
    plot_benchmark(reg_df)

    if best_payload is None:
        raise SystemExit("No best model found.")

    strat = best_payload["strategy"]
    df_best = best_payload["df"]
    X_best = best_payload["X"]
    y_best = pd.to_numeric(df_best[target], errors="coerce").values
    final_model = make_regressor(best_payload["model_name"], rs, n_estimators=args.n_estimators, mlp_iter=args.mlp_max_iter)
    final_model.fit(X_best, y_best)

    pred_mask = labels["seq_len"].between(50, 100)
    pred_df = labels[pred_mask].copy().reset_index(drop=True)
    X_pred = make_feature_table(pred_df, strat, use_rnafold=args.rnafold, mfe_cache=mfe_cache)
    pred_df["improved_model_pred_rank_FIXED"] = np.clip(final_model.predict(X_pred), 0, 1)
    pred_out = OUT / "tables/improved_model_predictions_50_100bp_FIXED.csv"
    keep_cols = [c for c in [
        "utr_id", "gene_name", SEQ_COL, "seq_len", "gc_content", "uaug_count",
        "log2_te_mean_norm", "robust_public_te_rank", "mean_TE_rank",
        "day_consensus_TE_rank", "residual_TE_rank", "ribo_abundance_rank",
        "tss_confidence", "tss_confidence_score", "improved_model_pred_rank_FIXED"
    ] if c in pred_df.columns]
    pred_df[keep_cols].to_csv(pred_out, index=False)

    model_path = OUT / "models/best_improved_model_FIXED.joblib"
    joblib.dump({
        "model": final_model,
        "strategy": strat,
        "feature_cols": X_best.columns.tolist(),
        "target": target,
        "best_row": best,
        "use_rnafold": bool(args.rnafold),
        "classification_indexing_fixed": True,
    }, model_path)

    summary = [
        "Improved model benchmark summary - FIXED classifier indexing",
        "=" * 80,
        "Best gene-split regression model:",
        str(best),
        "",
        f"Saved regression benchmark: {reg_path}",
        f"Saved classification benchmark: {clf_path}",
        f"Saved best model: {model_path}",
        f"Saved 50-100 bp predictions: {pred_out}",
        "",
        "Top 20 gene-split regression rows:",
        reg_df[reg_df["split_mode"] == "gene_split"].sort_values("spearman", ascending=False).head(20).to_string(index=False),
        "",
        "Top 20 gene-split classification rows:",
        clf_df[clf_df["split_mode"] == "gene_split"].sort_values("roc_auc", ascending=False).head(20).to_string(index=False) if len(clf_df) else "No classification rows.",
    ]
    summary_path = OUT / "tables/improved_model_benchmark_summary_FIXED.txt"
    summary_path.write_text("\n".join(summary), encoding="utf-8")

    print("\nDONE")
    print("[SAVED]", summary_path)
    print("[SAVED]", pred_out)
    print("[SAVED]", model_path)


if __name__ == "__main__":
    main()
