from pathlib import Path
import subprocess
import sys

steps = [
    ["01_pipeline/scripts/07_benchmark_model_strategies_FIXED.py", "--quick"],
]

for cmd in steps:
    print("\n" + "="*80)
    print("RUN", " ".join(cmd))
    print("="*80)
    r = subprocess.run([sys.executable] + cmd)
    if r.returncode != 0:
        raise SystemExit(f"FAILED: {' '.join(cmd)}")

print("\nDONE: fixed classifier-indexing benchmark completed.")
