import subprocess
import sys

cmd = [sys.executable, "01_pipeline/scripts/16_automl_autorank_selection.py", "--mode", "full", "--n-estimators", "1500", "--top-models", "12"]
print("RUN", " ".join(cmd))
r = subprocess.run(cmd)
if r.returncode != 0:
    raise SystemExit("FAILED")
print("DONE")
