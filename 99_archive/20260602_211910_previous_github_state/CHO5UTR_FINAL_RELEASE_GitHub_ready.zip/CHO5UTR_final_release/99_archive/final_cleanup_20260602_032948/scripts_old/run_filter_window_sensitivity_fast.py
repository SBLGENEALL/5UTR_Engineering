from pathlib import Path
import subprocess
import sys

# Quick mode recommended first.
cmd = [sys.executable, "01_pipeline/scripts/14_filter_window_sensitivity_benchmark.py", "--fast"]
print("RUN", " ".join(cmd))
r = subprocess.run(cmd)
if r.returncode != 0:
    raise SystemExit("FAILED")
print("DONE")
