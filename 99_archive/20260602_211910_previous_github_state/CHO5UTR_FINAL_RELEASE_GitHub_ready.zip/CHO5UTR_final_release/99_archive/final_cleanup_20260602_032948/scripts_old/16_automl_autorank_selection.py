from __future__ import annotations

from pathlib import Path
from collections import Counter
from itertools import product
import argparse
import math
import warnings

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

from scipy.stats import spearmanr, pearsonr
from sklearn.model_selection import train_test_split
from sklearn.pipeline import Pipeline
from sklearn.impute import SimpleImputer
from sklearn.ensemble import (
    ExtraTreesRegressor,
    RandomForestRegressor,
    HistGradientBoostingRegressor,
    ExtraTreesClassifier,
    RandomForestClassifier,
    HistGradientBoostingClassifier,
)
from sklearn.metrics import (
    r2_score,
    mean_squared_error,
    mean_absolute_error,
    roc_auc_score,
    average_precision_score,
)
import joblib

warnings.filterwarnings("ignore")

BASE = Path.cwd()
SEQ = "utr5_sequence_tss_corrected"

LABEL_CANDIDATES = [
    BASE / "04_te_labeling/tables/tss_corrected_5utr_multiomics_labels.csv",
    BASE / "04_te_labeling/tables/tss_corrected_5utr_robust_public_te_labels.csv",
]

OUTDIR = BASE / "06_modeling/tables"
MODELDIR = BASE / "06_modeling/models"
PLOTDIR = BASE / "06_modeling/plots"
LIBDIR = BASE / "07_library_design/tables"
FASTADIR = BASE / "07_library_design/fasta"
QCDIR = BASE / "07_library_design/qc"
for d in [OUTDIR, MODELDIR, PLOTDIR, LIBDIR, FASTADIR, QCDIR]:
    d.mkdir(parents=True, exist_ok=True)

OUT_SEARCH = OUTDIR / "automl_autorank_model_search_results.csv"
OUT_MODEL_WEIGHTS = OUTDIR / "automl_autorank_selected_model_weights.csv"
OUT_PRED = OUTDIR / "automl_autorank_50_100_candidate_scores.csv"
OUT_SUMMARY = OUTDIR / "automl_autorank_summary.txt"
OUT_PLOT = PLOTDIR / "automl_autorank_gene_split_performance.png"

OUT_LIB = LIBDIR / "selected_1000_50_100bp_AUTOML_autorank_library.csv"
OUT_FASTA = FASTADIR / "selected_1000_50_100bp_AUTOML_autorank_library.fasta"
OUT_LIB_SUMMARY = QCDIR / "selected_1000_50_100bp_AUTOML_autorank_summary.txt"

def clean_seq(x):
    if pd.isna(x):
        return ""
    return str(x).upper().replace("U", "T").replace(" ", "").replace("\n", "")

def gc_content(seq):
    seq = clean_seq(seq)
    return (seq.count("G") + seq.count("C")) / len(seq) if len(seq) else np.nan

def longest_run(seq, base):
    best = cur = 0
    for b in clean_seq(seq):
        if b == base:
            cur += 1
            best = max(best, cur)
        else:
            cur = 0
    return best

def count_uorf(seq):
    seq = clean_seq(seq)
    stops = {"TAA", "TAG", "TGA"}
    n, longest = 0, 0
    for i in range(max(0, len(seq) - 2)):
        if seq[i:i+3] == "ATG":
            for j in range(i + 3, len(seq) - 2, 3):
                if seq[j:j+3] in stops:
                    n += 1
                    longest = max(longest, j + 3 - i)
                    break
    return n, longest

def get_window(seq, mode):
    seq = clean_seq(seq)
    if mode == "full":
        return seq
    if mode == "tail100":
        return seq[-100:] if len(seq) > 100 else seq
    if mode == "head100":
        return seq[:100]
    if mode == "pad100":
        return seq[:100]
    raise ValueError(mode)

def kmer_features(seq, ks=(5,), prefix=""):
    seq = clean_seq(seq)
    out = {}
    for k in ks:
        all_kmers = ["".join(x) for x in product("ACGT", repeat=k)]
        cnt = Counter(seq[i:i+k] for i in range(max(0, len(seq)-k+1)) if set(seq[i:i+k]) <= set("ACGT"))
        total = sum(cnt.values())
        for km in all_kmers:
            out[f"{prefix}{k}mer_{km}"] = cnt.get(km, 0) / total if total else 0.0
    return out

def onehot100(seq, prefix="onehot_"):
    seq = clean_seq(seq)[:100]
    out = {}
    for i in range(100):
        b = seq[i] if i < len(seq) else "N"
        for x in "ACGT":
            out[f"{prefix}{i:03d}_{x}"] = 1.0 if b == x else 0.0
    return out

def make_features(df, strategy):
    mode = strategy["window_mode"]
    ks = tuple(strategy["kmers"])
    use_onehot = strategy.get("onehot100", False)
    add_full_k5 = strategy.get("add_full_kmer5", False)

    rows = []
    for i, seq0 in enumerate(df[SEQ].map(clean_seq)):
        seq = get_window(seq0, mode)
        L = len(seq0)
        WL = len(seq)
        uorf, longest = count_uorf(seq0)

        r = {
            "length": L,
            "window_length": WL,
            "gc_content": gc_content(seq0),
            "window_gc": gc_content(seq),
            "uaug_count": seq0.count("ATG"),
            "window_uaug_count": seq.count("ATG"),
            "cpg_count": seq0.count("CG"),
            "window_cpg_count": seq.count("CG"),
            "first_aug_pos": seq0.find("ATG"),
            "aug_density": seq0.count("ATG") / L if L else 0,
            "uorf_count": uorf,
            "longest_uorf_len": longest,
        }

        for b in "ACGT":
            r[f"{b.lower()}_fraction"] = seq0.count(b) / L if L else 0.0
            r[f"window_{b.lower()}_fraction"] = seq.count(b) / WL if WL else 0.0
            r[f"poly{b}_max_run"] = longest_run(seq0, b)
            r[f"window_poly{b}_max_run"] = longest_run(seq, b)

        for w in [20, 30, 50, 100]:
            head = seq0[:w]
            tail = seq0[-w:] if L >= w else seq0
            r[f"head{w}_gc"] = gc_content(head)
            r[f"tail{w}_gc"] = gc_content(tail)
            r[f"head{w}_uaug"] = head.count("ATG")
            r[f"tail{w}_uaug"] = tail.count("ATG")

        r.update(kmer_features(seq, ks=ks, prefix=f"{mode}_"))

        if add_full_k5 and mode != "full":
            r.update(kmer_features(seq0, ks=(5,), prefix="full_"))

        if use_onehot:
            r.update(onehot100(seq, prefix=f"{mode}_onehot_"))

        rows.append(r)
        if (i + 1) % 5000 == 0:
            print(f"  feature rows {i+1:,}/{len(df):,}")

    return pd.DataFrame(rows)

def make_regressor(name, n_estimators=700, rs=42):
    if name == "RandomForest":
        return Pipeline([
            ("imputer", SimpleImputer(strategy="median")),
            ("model", RandomForestRegressor(
                n_estimators=n_estimators,
                max_features="sqrt",
                min_samples_leaf=5,
                random_state=rs,
                n_jobs=-1,
            )),
        ])
    if name == "ExtraTrees":
        return Pipeline([
            ("imputer", SimpleImputer(strategy="median")),
            ("model", ExtraTreesRegressor(
                n_estimators=n_estimators,
                max_features="sqrt",
                min_samples_leaf=5,
                random_state=rs,
                n_jobs=-1,
            )),
        ])
    if name == "HistGradientBoosting":
        return Pipeline([
            ("imputer", SimpleImputer(strategy="median")),
            ("model", HistGradientBoostingRegressor(
                max_iter=600,
                learning_rate=0.04,
                max_leaf_nodes=31,
                l2_regularization=0.03,
                random_state=rs,
            )),
        ])
    raise ValueError(name)

def make_classifier(name, n_estimators=700, rs=42):
    if name == "RandomForest":
        return Pipeline([
            ("imputer", SimpleImputer(strategy="median")),
            ("model", RandomForestClassifier(
                n_estimators=n_estimators,
                max_features="sqrt",
                min_samples_leaf=5,
                class_weight="balanced",
                random_state=rs,
                n_jobs=-1,
            )),
        ])
    if name == "ExtraTrees":
        return Pipeline([
            ("imputer", SimpleImputer(strategy="median")),
            ("model", ExtraTreesClassifier(
                n_estimators=n_estimators,
                max_features="sqrt",
                min_samples_leaf=5,
                class_weight="balanced",
                random_state=rs,
                n_jobs=-1,
            )),
        ])
    if name == "HistGradientBoosting":
        return Pipeline([
            ("imputer", SimpleImputer(strategy="median")),
            ("model", HistGradientBoostingClassifier(
                max_iter=600,
                learning_rate=0.04,
                max_leaf_nodes=31,
                l2_regularization=0.03,
                random_state=rs,
            )),
        ])
    raise ValueError(name)

def split_idx(df, mode, rs=42, test_size=0.2):
    if mode == "random":
        idx = np.arange(len(df))
        return train_test_split(idx, test_size=test_size, random_state=rs)
    groups = df["gene_name"].astype(str).fillna("NA").values if "gene_name" in df.columns else df["utr_id"].astype(str).values
    unique = np.array(sorted(pd.unique(groups)))
    tr_g, te_g = train_test_split(unique, test_size=test_size, random_state=rs)
    return np.where(np.isin(groups, tr_g))[0], np.where(np.isin(groups, te_g))[0]

def reg_metrics(y, p):
    out = {
        "spearman": spearmanr(y, p).correlation if len(y) >= 3 else np.nan,
        "pearson": pearsonr(y, p)[0] if len(y) >= 3 else np.nan,
        "r2": r2_score(y, p),
        "rmse": float(math.sqrt(mean_squared_error(y, p))),
        "mae": float(mean_absolute_error(y, p)),
    }
    for frac in [0.05, 0.10, 0.20]:
        k = max(1, int(len(y) * frac))
        top = np.argsort(p)[-k:]
        thr = np.quantile(y, 1 - frac)
        out[f"top{int(frac*100)}_enrichment"] = float(np.mean(y[top] >= thr))
    return out

def load_label():
    for p in LABEL_CANDIDATES:
        if p.exists():
            print("[LOAD]", p)
            return pd.read_csv(p), p
    raise SystemExit("No label table found.")

def prep(df):
    df = df.copy()
    df[SEQ] = df[SEQ].map(clean_seq)
    if "utr5_length_final" in df.columns:
        df["length_for_filter"] = df["utr5_length_final"]
    elif "utr5_length_tss_corrected" in df.columns:
        df["length_for_filter"] = df["utr5_length_tss_corrected"]
    else:
        df["length_for_filter"] = df[SEQ].str.len()
    if "gc_content" not in df.columns:
        df["gc_content"] = df[SEQ].map(gc_content)
    if "uaug_count" not in df.columns:
        df["uaug_count"] = df[SEQ].str.count("ATG")
    if "has_proteomics_label" not in df.columns:
        df["has_proteomics_label"] = df.get("protein_abundance_rank", pd.Series(np.nan, index=df.index)).notna()
    return df

def filter_df(df, name):
    if name == "50_100_strict":
        mask = df["length_for_filter"].between(50, 100) & df["gc_content"].between(0.30, 0.75) & (df["uaug_count"] <= 1)
    elif name == "40_200_strict":
        mask = df["length_for_filter"].between(40, 200) & df["gc_content"].between(0.30, 0.75) & (df["uaug_count"] <= 1)
    elif name == "20_300_relaxed":
        mask = df["length_for_filter"].between(20, 300) & df["gc_content"].between(0.25, 0.80) & (df["uaug_count"] <= 3)
    elif name == "20_500_relaxed":
        mask = df["length_for_filter"].between(20, 500) & df["gc_content"].between(0.25, 0.80) & (df["uaug_count"] <= 3)
    elif name == "proteomics_20_500_relaxed":
        mask = df["length_for_filter"].between(20, 500) & df["gc_content"].between(0.25, 0.80) & (df["uaug_count"] <= 3) & df["has_proteomics_label"].astype(bool)
    else:
        raise ValueError(name)
    mask &= df[SEQ].str.len() > 0
    mask &= ~df[SEQ].str.contains("N", regex=False)
    return df[mask].copy().reset_index(drop=True)

def rank_pct(s):
    return pd.to_numeric(s, errors="coerce").rank(pct=True)

def plot_search(res):
    sub = res[res["split_mode"] == "gene_split"].copy()
    if sub.empty:
        return
    sub["metric_score"] = sub["selection_metric"]
    sub["label"] = sub["task"] + "\n" + sub["target"] + "\n" + sub["filter_name"] + "\n" + sub["strategy"] + "\n" + sub["model"]
    sub = sub.sort_values("metric_score", ascending=True).tail(30)
    plt.figure(figsize=(14, max(8, 0.5 * len(sub))))
    plt.barh(sub["label"], sub["metric_score"])
    plt.xlabel("AutoRank selection metric")
    plt.title("AutoML/AutoRank model search")
    plt.tight_layout()
    plt.savefig(OUT_PLOT, dpi=200)
    plt.close()

def forbidden_sites(seq):
    sites = {
        "BsaI_GGTCTC": "GGTCTC",
        "BsaI_GAGACC": "GAGACC",
        "BsmBI_CGTCTC": "CGTCTC",
        "BsmBI_GAGACG": "GAGACG",
        "EcoRI_GAATTC": "GAATTC",
        "XhoI_CTCGAG": "CTCGAG",
        "NheI_GCTAGC": "GCTAGC",
        "AgeI_ACCGGT": "ACCGGT",
        "NotI_GCGGCCGC": "GCGGCCGC",
    }
    seq = clean_seq(seq)
    return ";".join([name for name, site in sites.items() if site in seq])

def write_fasta(df, path, seq_col=SEQ, id_col="utr_id"):
    with open(path, "w", encoding="utf-8") as out:
        for i, r in df.iterrows():
            uid = str(r.get(id_col, f"row_{i}")).replace(" ", "_").replace("/", "_")
            group = str(r.get("automl_group", "NA")).replace(" ", "_")
            gene = str(r.get("gene_name", "NA")).replace(" ", "_").replace("/", "_")
            seq = clean_seq(r[seq_col])
            out.write(f">{uid}|{gene}|len={len(seq)}|group={group}\n")
            for j in range(0, len(seq), 80):
                out.write(seq[j:j+80] + "\n")

def select_candidate_space(df):
    x = df.copy()
    x["forbidden_sites"] = x[SEQ].apply(forbidden_sites)
    x = x[
        x["length_for_filter"].between(50, 100)
        & x["gc_content"].between(0.30, 0.75)
        & (x["uaug_count"] <= 1)
        & (~x["forbidden_sites"].fillna("").astype(str).ne(""))
        & (~x[SEQ].str.contains("N", regex=False))
        & df["robust_public_te_rank"].notna()
    ].copy()
    x = x.drop_duplicates(subset=[SEQ]).reset_index(drop=True)
    return x

def make_library(candidate):
    df = candidate.copy()

    # If no proteomics fields exist, fill with robust TE.
    for c in ["protein_residual_rank", "protein_abundance_rank", "multi_omics_utr_rank"]:
        if c not in df.columns:
            df[c] = np.nan
    df["protein_residual_rank_fill"] = df["protein_residual_rank"].fillna(df["robust_public_te_rank"])
    df["protein_abundance_rank_fill"] = df["protein_abundance_rank"].fillna(df["robust_public_te_rank"])
    df["multi_omics_utr_rank_fill"] = df["multi_omics_utr_rank"].fillna(df["robust_public_te_rank"])

    # Evidence score is deliberately not pure model prediction.
    df["automl_evidence_score"] = (
        0.45 * df["robust_public_te_rank"].fillna(0)
        + 0.15 * df["multi_omics_utr_rank_fill"].fillna(0)
        + 0.12 * df["protein_residual_rank_fill"].fillna(0)
        + 0.08 * df["protein_abundance_rank_fill"].fillna(0)
        + 0.10 * df.get("day_consensus_TE_rank", pd.Series(0, index=df.index)).fillna(0)
        + 0.10 * df["automl_ensemble_score"].fillna(0)
    )

    selected = []
    used = set()

    def avail(x):
        return x[~x[SEQ].isin(used)].copy()

    def add(x, group):
        x = x.copy()
        x["automl_group"] = group
        selected.append(x)
        used.update(x[SEQ].tolist())

    # A. Highest consensus of evidence + model
    pool = avail(df).sort_values(["automl_evidence_score", "robust_public_te_rank"], ascending=False)
    add(pool.head(450), "A_automl_evidence_top")

    # B. Model-supported public TE high
    pool = avail(df)
    pool = pool[pool["robust_public_te_rank"].fillna(0) >= 0.75].sort_values(["automl_ensemble_score", "robust_public_te_rank"], ascending=False)
    add(pool.head(200), "B_model_supported_publicTE_high")

    # C. Proteomics-supported, if available
    pool = avail(df)
    if "has_proteomics_label" in pool.columns:
        pool = pool[pool["has_proteomics_label"].astype(bool)]
    pool = pool.sort_values(["protein_residual_rank_fill", "protein_abundance_rank_fill", "robust_public_te_rank"], ascending=False)
    add(pool.head(150), "C_proteomics_supported")

    # D. Diverse mid-high candidates, not only top TE
    pool = avail(df)
    pool = pool[(pool["robust_public_te_rank"].fillna(0) >= 0.45) & (pool["automl_ensemble_score"].fillna(0) >= df["automl_ensemble_score"].quantile(0.50))]
    pool = pool.copy()
    pool["len_bin"] = pd.cut(pool["length_for_filter"], [49,60,70,80,90,100], labels=False)
    pool["gc_bin"] = pd.cut(pool["gc_content"], [0,0.4,0.5,0.6,0.75,1], labels=False)
    parts = []
    for _, sub in pool.groupby(["len_bin", "gc_bin"], dropna=True):
        parts.append(sub.sort_values(["automl_evidence_score"], ascending=False).head(4))
    diverse = pd.concat(parts).drop_duplicates(subset=[SEQ]) if parts else pool.head(0)
    add(diverse.head(175), "D_diverse_model_mid_high")

    # E. negative controls
    pool = avail(df)
    pool = pool[pool["robust_public_te_rank"].fillna(1) <= 0.25].sort_values(["robust_public_te_rank", "gc_content"], ascending=[True, False])
    add(pool.head(25), "E_low_TE_negative")

    out = pd.concat(selected).drop_duplicates(subset=[SEQ]) if selected else df.head(0)

    if len(out) < 1000:
        pool = avail(df).sort_values(["automl_evidence_score", "robust_public_te_rank"], ascending=False)
        fill = pool.head(1000 - len(out))
        add(fill, "F_fill_automl_evidence")
        out = pd.concat(selected).drop_duplicates(subset=[SEQ])

    out = out.head(1000).copy()
    out["library_index"] = range(1, len(out) + 1)

    front = [c for c in [
        "library_index", "automl_group", "utr_id", "gene_id", "gene_name", SEQ,
        "length_for_filter", "gc_content", "uaug_count", "tss_confidence",
        "robust_public_te_rank", "multi_omics_utr_rank",
        "protein_residual_rank", "protein_abundance_rank",
        "automl_ensemble_score", "automl_evidence_score",
        "has_proteomics_label", "forbidden_sites",
    ] if c in out.columns]
    out = out[front + [c for c in out.columns if c not in front]]
    return out

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--mode", choices=["quick", "full"], default="quick")
    ap.add_argument("--n-estimators", type=int, default=None, help="Override tree count.")
    ap.add_argument("--top-models", type=int, default=8)
    args = ap.parse_args()

    n_estimators = args.n_estimators if args.n_estimators else (700 if args.mode == "quick" else 1500)

    df, label_path = load_label()
    df = prep(df)

    if args.mode == "quick":
        filters = ["50_100_strict", "40_200_strict", "20_500_relaxed"]
        strategies = [
            {"strategy": "full_k5", "window_mode": "full", "kmers": [5], "onehot100": False},
            {"strategy": "full_k345", "window_mode": "full", "kmers": [3,4,5], "onehot100": False},
            {"strategy": "tail100_k5_plus_fullk5", "window_mode": "tail100", "kmers": [5], "onehot100": False, "add_full_kmer5": True},
        ]
        models = ["RandomForest", "ExtraTrees"]
    else:
        filters = ["50_100_strict", "40_200_strict", "20_300_relaxed", "20_500_relaxed", "proteomics_20_500_relaxed"]
        strategies = [
            {"strategy": "full_k5", "window_mode": "full", "kmers": [5], "onehot100": False},
            {"strategy": "full_k345", "window_mode": "full", "kmers": [3,4,5], "onehot100": False},
            {"strategy": "tail100_k5_plus_fullk5", "window_mode": "tail100", "kmers": [5], "onehot100": False, "add_full_kmer5": True},
            {"strategy": "tail100_k5_onehot", "window_mode": "tail100", "kmers": [5], "onehot100": True},
            {"strategy": "pad100_k5_onehot", "window_mode": "pad100", "kmers": [5], "onehot100": True},
        ]
        models = ["RandomForest", "ExtraTrees", "HistGradientBoosting"]

    targets = [c for c in ["robust_public_te_rank", "multi_omics_utr_rank", "protein_residual_rank", "protein_abundance_rank"] if c in df.columns]

    search_rows = []
    saved_configs = []

    feature_cache = {}

    for filt in filters:
        sub0 = filter_df(df, filt)
        print("\n" + "="*100)
        print("[FILTER]", filt, "rows", len(sub0), "proteomics", int(sub0["has_proteomics_label"].sum()))
        print("="*100)
        if len(sub0) < 500:
            continue

        for strat in strategies:
            key = (filt, strat["strategy"])
            print("\n[FEATURE]", filt, strat["strategy"])
            X0 = make_features(sub0, strat)
            feature_cache[key] = (sub0, X0, strat)

            for target in targets:
                valid = pd.to_numeric(sub0[target], errors="coerce").notna()
                sub = sub0[valid].copy().reset_index(drop=True)
                X = X0.loc[valid].reset_index(drop=True)
                if len(sub) < 500:
                    continue
                if target.startswith("protein") and int(sub["has_proteomics_label"].sum()) < 500:
                    continue

                y = pd.to_numeric(sub[target], errors="coerce").values

                for split_mode in ["random", "gene_split"]:
                    tr, te = split_idx(sub, split_mode)
                    for model_name in models:
                        # Regression
                        print("[REG]", filt, strat["strategy"], target, split_mode, model_name)
                        model = make_regressor(model_name, n_estimators=n_estimators)
                        model.fit(X.iloc[tr], y[tr])
                        pred = np.clip(model.predict(X.iloc[te]), 0, 1)
                        met = reg_metrics(y[te], pred)
                        selection_metric = (
                            0.50 * max(0, met["spearman"])
                            + 0.25 * met["top10_enrichment"]
                            + 0.25 * met["top20_enrichment"]
                        )
                        row = {
                            "task": "regression",
                            "filter_name": filt,
                            "strategy": strat["strategy"],
                            "target": target,
                            "split_mode": split_mode,
                            "model": model_name,
                            "n_estimators": n_estimators,
                            "n_rows": len(sub),
                            "n_train": len(tr),
                            "n_test": len(te),
                            "proteomics_mapped_rows": int(sub["has_proteomics_label"].sum()),
                            "selection_metric": selection_metric,
                            **met,
                        }
                        search_rows.append(row)
                        print("  metric", round(selection_metric, 4), "spearman", round(met["spearman"],4), "top10", round(met["top10_enrichment"],4))

                # Classification high/low
                hi = np.quantile(y, 0.80)
                lo = np.quantile(y, 0.30)
                cmask = (y >= hi) | (y <= lo)
                if cmask.sum() >= 300 and len(np.unique((y[cmask] >= hi).astype(int))) == 2:
                    cdf = sub.loc[cmask].copy().reset_index(drop=True)
                    Xc = X.loc[cmask].reset_index(drop=True)
                    yc = (pd.to_numeric(cdf[target], errors="coerce").values >= hi).astype(int)

                    for split_mode in ["random", "gene_split"]:
                        if split_mode == "random":
                            idx = np.arange(len(cdf))
                            tr, te = train_test_split(idx, test_size=0.2, random_state=42, stratify=yc)
                        else:
                            tr, te = split_idx(cdf, split_mode)

                        for model_name in models:
                            print("[CLF]", filt, strat["strategy"], target, split_mode, model_name)
                            clf = make_classifier(model_name, n_estimators=n_estimators)
                            clf.fit(Xc.iloc[tr], yc[tr])
                            pp = clf.predict_proba(Xc.iloc[te])[:, 1]
                            roc = roc_auc_score(yc[te], pp)
                            ap_score = average_precision_score(yc[te], pp)
                            selection_metric = 0.45 * roc + 0.55 * ap_score
                            search_rows.append({
                                "task": "classification",
                                "filter_name": filt,
                                "strategy": strat["strategy"],
                                "target": target,
                                "split_mode": split_mode,
                                "model": model_name,
                                "n_estimators": n_estimators,
                                "n_rows": len(cdf),
                                "n_train": len(tr),
                                "n_test": len(te),
                                "proteomics_mapped_rows": int(cdf["has_proteomics_label"].sum()) if "has_proteomics_label" in cdf.columns else np.nan,
                                "selection_metric": selection_metric,
                                "roc_auc": roc,
                                "average_precision": ap_score,
                                "spearman": np.nan,
                                "pearson": np.nan,
                                "r2": np.nan,
                                "rmse": np.nan,
                                "mae": np.nan,
                                "top5_enrichment": np.nan,
                                "top10_enrichment": np.nan,
                                "top20_enrichment": np.nan,
                            })
                            print("  metric", round(selection_metric, 4), "roc", round(roc,4), "ap", round(ap_score,4))

    search = pd.DataFrame(search_rows)
    search.to_csv(OUT_SEARCH, index=False)
    plot_search(search)

    # Select best gene-split models for final ensemble.
    gene = search[search["split_mode"] == "gene_split"].copy()
    gene = gene.sort_values("selection_metric", ascending=False)
    selected = gene.head(args.top_models).copy()
    selected.to_csv(OUT_MODEL_WEIGHTS, index=False)

    print("\n[SELECTED MODELS]")
    print(selected[["task","filter_name","strategy","target","model","selection_metric","spearman","top10_enrichment","roc_auc","average_precision"]].to_string(index=False))

    # Train selected models on full data and predict 50-100 candidate space.
    cand = select_candidate_space(df)
    print("\nCandidate space for final scoring:", len(cand))

    pred_cols = []
    for rank, row in selected.reset_index(drop=True).iterrows():
        filt = row["filter_name"]
        strategy_name = row["strategy"]
        target = row["target"]
        model_name = row["model"]
        task = row["task"]

        # Find strategy object
        strat = None
        for s in strategies:
            if s["strategy"] == strategy_name:
                strat = s
                break
        if strat is None:
            continue

        train0 = filter_df(df, filt)
        valid = pd.to_numeric(train0[target], errors="coerce").notna()
        train = train0[valid].copy().reset_index(drop=True)
        Xtrain = make_features(train, strat)
        y = pd.to_numeric(train[target], errors="coerce").values

        Xcand = make_features(cand, strat)

        col = f"automl_model_{rank+1:02d}_{task}_{target}_{filt}_{strategy_name}_{model_name}"
        print("[FINAL FIT]", col)

        if task == "regression":
            model = make_regressor(model_name, n_estimators=n_estimators)
            model.fit(Xtrain, y)
            pred = np.clip(model.predict(Xcand), 0, 1)
        else:
            hi = np.quantile(y, 0.80)
            lo = np.quantile(y, 0.30)
            cmask = (y >= hi) | (y <= lo)
            Xc = Xtrain.loc[cmask].reset_index(drop=True)
            yc = (y[cmask] >= hi).astype(int)
            model = make_classifier(model_name, n_estimators=n_estimators)
            model.fit(Xc, yc)
            pred = model.predict_proba(Xcand)[:, 1]

        cand[col] = pred
        pred_cols.append(col)

        joblib.dump(
            {"model": model, "strategy": strat, "target": target, "task": task, "filter_name": filt, "score": row.to_dict()},
            MODELDIR / f"{col}.joblib"
        )

    if pred_cols:
        # Weighted average by positive validation metric.
        weights = selected["selection_metric"].clip(lower=0).values[:len(pred_cols)]
        if weights.sum() <= 0:
            weights = np.ones(len(pred_cols))
        weights = weights / weights.sum()
        pred_matrix = cand[pred_cols].fillna(0).values
        cand["automl_ensemble_score"] = pred_matrix.dot(weights)
        cand["automl_ensemble_rank"] = rank_pct(cand["automl_ensemble_score"])
    else:
        cand["automl_ensemble_score"] = cand["robust_public_te_rank"]
        cand["automl_ensemble_rank"] = rank_pct(cand["automl_ensemble_score"])

    cand.to_csv(OUT_PRED, index=False)

    lib = make_library(cand)
    lib.to_csv(OUT_LIB, index=False)
    write_fasta(lib, OUT_FASTA)

    lib_lines = [
        "AutoML/AutoRank selected 1000 50-100 bp UTR library",
        "=" * 100,
        f"Total selected: {len(lib)}",
        f"Candidate space: {len(cand)}",
        "",
        "[Group counts]",
        lib["automl_group"].value_counts().to_string(),
        "",
        "[Length]",
        lib["length_for_filter"].describe().to_string(),
        "",
        "[Robust public TE rank]",
        lib["robust_public_te_rank"].describe().to_string(),
        "",
        "[AutoML ensemble score]",
        lib["automl_ensemble_score"].describe().to_string(),
        "",
        "[has proteomics label]",
        lib["has_proteomics_label"].value_counts(dropna=False).to_string() if "has_proteomics_label" in lib.columns else "NA",
        "",
        "[uAUG]",
        lib["uaug_count"].value_counts().sort_index().to_string(),
        "",
        "[duplicate check]",
        f"unique sequences: {lib[SEQ].nunique()}",
        f"duplicates: {len(lib) - lib[SEQ].nunique()}",
    ]
    OUT_LIB_SUMMARY.write_text("\n".join(lib_lines), encoding="utf-8")

    summary = [
        "AutoML / AutoRank model search summary",
        "=" * 100,
        f"label_path: {label_path}",
        f"mode: {args.mode}",
        f"n_estimators: {n_estimators}",
        f"top_models: {args.top_models}",
        "",
        "[Selected gene-split models for ensemble]",
        selected[["task","filter_name","strategy","target","model","selection_metric","spearman","top10_enrichment","top20_enrichment","roc_auc","average_precision"]].to_string(index=False),
        "",
        "[Top 30 gene-split overall]",
        gene.head(30).to_string(index=False),
        "",
        f"Saved search results: {OUT_SEARCH}",
        f"Saved selected model weights: {OUT_MODEL_WEIGHTS}",
        f"Saved candidate predictions: {OUT_PRED}",
        f"Saved final library: {OUT_LIB}",
        f"Saved final FASTA: {OUT_FASTA}",
        f"Saved plot: {OUT_PLOT}",
    ]
    OUT_SUMMARY.write_text("\n".join(summary), encoding="utf-8")

    print("[SAVED]", OUT_SEARCH)
    print("[SAVED]", OUT_MODEL_WEIGHTS)
    print("[SAVED]", OUT_PRED)
    print("[SAVED]", OUT_SUMMARY)
    print("[SAVED]", OUT_LIB)
    print("[SAVED]", OUT_FASTA)
    print("[SAVED]", OUT_LIB_SUMMARY)

if __name__ == "__main__":
    main()
