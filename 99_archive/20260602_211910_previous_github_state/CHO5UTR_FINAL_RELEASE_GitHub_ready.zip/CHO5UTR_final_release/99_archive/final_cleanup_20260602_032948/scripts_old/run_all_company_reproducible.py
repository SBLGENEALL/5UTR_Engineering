from pathlib import Path
import subprocess
import sys

# Full reproducible workflow:
# 1. download all databases
# 2. generate public TE labels
# 3. build 40-200 model and 50-100 selected library
# 4. benchmark RNAfold/fixed-representation model strategies
# 5. map Heffner proteomics via NCBI gene files
# 6. generate proteomics-assisted multi-omics library

steps = [
    ["00_download_all_databases.py"],
    ["run_base_publicTE_pipeline.py"],
    ["07_benchmark_model_strategies_FIXED.py", "--rnafold"],
    ["run_heffner_ncbi_mapped_multiomics_pipeline.py"],
]

script_dir = Path("01_pipeline") / "scripts"
for cmd in steps:
    print("\n" + "="*80)
    print("RUN", " ".join(cmd))
    print("="*80)
    r = subprocess.run([sys.executable, str(script_dir / cmd[0])] + cmd[1:])
    if r.returncode != 0:
        raise SystemExit(f"FAILED: {' '.join(cmd)}")
print("\nDONE: full company reproducible workflow completed.")
