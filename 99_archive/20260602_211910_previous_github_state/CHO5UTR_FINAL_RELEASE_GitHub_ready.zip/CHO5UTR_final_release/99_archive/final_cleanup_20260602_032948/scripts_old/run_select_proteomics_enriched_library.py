from pathlib import Path
import subprocess
import sys

cmd = [sys.executable, "01_pipeline/scripts/12_select_1000_proteomics_enriched_orthogonal_library.py"]
print("RUN", " ".join(cmd))
r = subprocess.run(cmd)
if r.returncode != 0:
    raise SystemExit("FAILED")
print("DONE")
