import subprocess
import sys

cmd = [sys.executable, "01_pipeline/scripts/16_automl_autorank_selection.py", "--mode", "quick", "--top-models", "8"]
print("RUN", " ".join(cmd))
r = subprocess.run(cmd)
if r.returncode != 0:
    raise SystemExit("FAILED")
print("DONE")
