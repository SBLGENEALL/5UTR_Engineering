import subprocess, sys
cmd=[sys.executable,"01_pipeline/scripts/17_plot_proteomics_abundance_highlow_predictions.py","--target","protein_abundance_rank"]
print("RUN"," ".join(cmd))
r=subprocess.run(cmd)
raise SystemExit(r.returncode)
