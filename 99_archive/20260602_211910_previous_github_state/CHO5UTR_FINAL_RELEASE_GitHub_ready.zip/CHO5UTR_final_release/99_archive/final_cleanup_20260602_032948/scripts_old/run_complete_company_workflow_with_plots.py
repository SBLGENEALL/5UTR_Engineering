from pathlib import Path
import subprocess
import sys

steps = [
    ["00_download_all_databases.py"],
    ["00_check_inputs.py"],
    ["run_base_publicTE_pipeline.py"],
    ["run_heffner_ncbi_mapped_multiomics_pipeline.py"],
    ["run_automl_autorank_quick.py"],
    ["run_plot_proteomics_abundance_highlow.py"],
    ["run_select_proteomics_enriched_library.py"],
    ["run_make_hybrid_final_libraries.py"],
]

script_dir = Path("01_pipeline") / "scripts"

for cmd in steps:
    print("\n" + "=" * 90)
    print("RUN", " ".join(cmd))
    print("=" * 90)
    r = subprocess.run([sys.executable, str(script_dir / cmd[0])] + cmd[1:])
    if r.returncode != 0:
        raise SystemExit(f"FAILED: {' '.join(cmd)}")

print("\nDONE: complete reproducible CHO 5UTR workflow finished.")
