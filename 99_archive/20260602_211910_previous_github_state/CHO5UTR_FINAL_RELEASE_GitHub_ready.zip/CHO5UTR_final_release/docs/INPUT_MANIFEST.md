# INPUT MANIFEST

## 00_raw_data/01_ncbi_genome_annotation
- GCF_003668045.1_CriGri-PICR_genomic.fna.gz
- GCF_003668045.1_CriGri-PICR_genomic.gff.gz

## 00_raw_data/02_tss_atlas_picr3
- GSE159044_eTSS_NCBI_picr.bed.gz
- GSE159044_eTSS_NCBI_picr.meta.tsv.gz

## 00_raw_data/03_gse79512_rna_ribo
- GSE79512_RNASeq_rawCount.txt.gz
- GSE79512_RiboSeq_rawCount.txt.gz

## 00_raw_data/05_cho_proteomics
- Heffner_minimal.tsv  (data_assets/Heffner_minimal.tsv.gz 해제)
- ncbi_gene_mapping/gene2accession.gz
- ncbi_gene_mapping/gene_info.gz

## 주의
사내 NASCA/DRM 때문에 Heffner xlsx/csv가 깨질 수 있으므로, final release에서는 `data_assets/Heffner_minimal.tsv.gz`를 사용한다.
