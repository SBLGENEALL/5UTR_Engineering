# GITHUB RELEASE GUIDE

## 1. 정리 전 확인
```bash
git status
python tools/finalize_repo.py --dry-run
```

## 2. archive 적용
```bash
python tools/finalize_repo.py --apply
```

## 3. raw/result 파일은 commit하지 않기
`.gitignore`에 의해 `00_raw_data`의 대용량 파일, `06_modeling/models`, plot/result CSV 대부분은 제외된다. 단 `.gitkeep`와 README는 유지한다.

## 4. commit
```bash
git add README.md docs tools 01_pipeline/config 01_pipeline/scripts .gitignore RUN_FINAL_MAIN.sh RUN_FINAL_MAIN.bat
git commit -m "Finalize CHO 5UTR engineering pipeline v1.0"
git tag -a v1.0.0 -m "CHO 5UTR pipeline final release"
git push origin main --tags
```

## 5. 팀 배포 문구
이 repo는 CHO 5′UTR 후보 2000개 선별 pipeline입니다. `README.md`의 빠른 실행 순서와 `docs/FINAL_RUNBOOK.md`를 따라 실행하면 NCBI/TSS/Ribo/RNA/proteomics 기반 multiomics label을 만들고 Jaccard cluster-aware validation 후 최종 library CSV/FASTA를 생성합니다.
