# FINAL RUNBOOK — CHO 5′UTR Engineering Pipeline

## 목적
CHO에서 GFP/recombinant protein 발현을 높일 가능성이 있는 50–100 bp 5′UTR 후보를 2000개 선별한다.

## 핵심 해석
- `robust_public_te_rank`: Ribo/RNA 기반 translation proxy. 최종 선별의 main evidence.
- `protein_abundance_rank`: proteomics에서 protein이 많이 검출되는 gene의 rank.
- `protein_residual_rank`: RNA abundance로 설명되는 protein abundance를 제거한 뒤에도 protein output이 높은 gene의 rank. 즉 RNA로 normalization해도 protein이 높은 후보군을 찾기 위한 지표.
- `multi_omics_utr_rank`: TE/proteomics/protein residual/TSS confidence를 섞은 composite. TE와 correlation이 너무 높으면 사실상 TE 중심으로 해석.
- `ROC-AUC`: high 후보 하나와 low 후보 하나를 무작위로 뽑았을 때, 모델이 high 후보에 더 높은 점수를 줄 확률. 0.5는 랜덤, 0.6 이상은 weak signal, 0.65–0.70이면 후보군 enrichment에 사용 가능.

## 실행 순서

```bash
conda activate /home/MCET03/conda_envs/utr_env
cd /home/MCET03/03_ChatGPT_5UTR_pipeline
python 01_pipeline/scripts/00_check_inputs.py
python 01_pipeline/scripts/run_base_publicTE_pipeline.py
gunzip -c data_assets/Heffner_minimal.tsv.gz > 00_raw_data/05_cho_proteomics/Heffner_minimal.tsv
python 01_pipeline/scripts/run_heffner_ncbi_mapped_multiomics_pipeline.py
python 01_pipeline/scripts/run_plot_multiomics_distributions.py
python 01_pipeline/scripts/run_heavy_rnafold_kmer6_automl.py
python 01_pipeline/scripts/run_jaccard_2000_full_pipeline.py
```

## 결과 확인 순서

1. `04_te_labeling/qc/proteomics_mapping_summary.txt`에서 proteomics mapping 수 확인.
2. `04_te_labeling/qc/multiomics_distribution_qc_summary.txt`와 plots에서 TE/proteomics 분포 확인.
3. `06_modeling/tables/cluster_aware_classification_summary.txt`에서 gene_seq_cluster_split ROC-AUC 확인.
4. `07_library_design/qc/selected_2000_50_100bp_cluster_diverse_evidence_balanced_summary.txt`에서 최종 2000개 group/length/GC/uAUG/cluster 분포 확인.

## 최종 판단 기준
- regression Spearman보다 classification ROC-AUC/AP를 우선한다.
- random split은 참고용이고, gene_split 및 gene_seq_cluster_split을 최종 기준으로 본다.
- 최종 후보는 model score top이 아니라 evidence-balanced quota로 해석한다.
