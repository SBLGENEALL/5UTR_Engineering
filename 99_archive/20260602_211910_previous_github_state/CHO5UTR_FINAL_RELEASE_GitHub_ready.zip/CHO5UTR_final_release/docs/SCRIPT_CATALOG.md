# SCRIPT CATALOG

| Script | 역할 | 핵심 입력 | 핵심 출력 | 해석 |
|---|---|---|---|---|
| `common.py` | 공통 함수: table reader, feature utilities 등 여러 스크립트에서 import | 상위 pipeline 결과/설정 | runner 또는 보조 결과 | 실행 보조 |
| `00_check_inputs.py` | raw input 존재 여부 확인 | 00_raw_data/* | PASS/MISSING table | 누락 파일을 먼저 해결 |
| `00_download_all_databases.py` | 외부망에서 raw DB 자동 다운로드. 사내망에서는 수동 배치 권장 | 상위 pipeline 결과/설정 | runner 또는 보조 결과 | 실행 보조 |
| `01_build_utr_database.py` | NCBI GFF/FASTA에서 5′UTR 후보 생성 | NCBI genome/gff | 02_utr_database/tables/*.csv | annotation 기반 후보 |
| `02_tss_correction.py` | TSS atlas로 5′UTR 보정 | 02_utr_database + TSS atlas | 03_tss_correction/tables/tss_corrected_5utr_database.csv | TSS-supported 여부 중요 |
| `03_map_rna_ribo_robust_public_te.py` | RNA/Ribo를 매핑하여 robust public TE rank 생성 | tss_corrected DB + RNA/Ribo count | 04_te_labeling/tables/tss_corrected_5utr_robust_public_te_labels.csv | main evidence |
| `04b_extract_features_train_40_200bp.py` | 기본 feature 추출 fallback | 상위 pipeline 결과/설정 | runner 또는 보조 결과 | 실행 보조 |
| `05b_model_train_40_200bp.py` | 기본 publicTE regression/classification fallback | 상위 pipeline 결과/설정 | runner 또는 보조 결과 | 실행 보조 |
| `06b_select_1000_50_100bp_from_40_200train.py` | 기본 1000개 publicTE 후보 선별 fallback | 상위 pipeline 결과/설정 | runner 또는 보조 결과 | 실행 보조 |
| `09c_preprocess_heffner_with_ncbi_gene_mapping.py` | Heffner proteomics abundance proxy 생성 및 NCBI mapping | Heffner_minimal.tsv + gene2accession/gene_info | Heffner_2020_CHO_hamster_proteomics_ncbi_mapped_for_5utr.csv | NASCA 회피 위해 tsv.gz 사용 |
| `09_integrate_proteomics_multiomics.py` | UTR table에 protein abundance/residual 통합 | publicTE label + mapped proteomics | tss_corrected_5utr_multiomics_labels.csv | protein residual = RNA 보정 후 protein output |
| `10_model_multiomics_40_200bp.py` | multiomics 기본 모델 평가 | multiomics labels | multiomics_model_results_40_200bp.csv | 기본 성능 확인 |
| `18_heavy_rnafold_kmer6_automl.py` | RNAfold/k-mer6/tree2000 heavy 모델 | multiomics labels | heavy_rnafold_kmer6_* | classification 중심 해석 |
| `21_plot_multiomics_distributions.py` | 분포/coverage/correlation QC | multiomics labels | multiomics_distributions plots | multiomics가 TE와 너무 유사한지 확인 |
| `22_jaccard_sequence_cluster_qc.py` | Jaccard cluster 생성 | multiomics labels | tss_corrected_5utr_with_seq_clusters.csv | 유사서열 redundancy 감소 |
| `23_cluster_aware_classification_benchmark.py` | cluster-aware classification 평가 | clustered labels | cluster_aware_classification_benchmark.csv | gene_seq_cluster_split이 핵심 |
| `24_select_2000_cluster_diverse_library.py` | 최종 2000개 후보 선별 | clustered labels + model scores | selected_2000_*.csv/fasta | evidence-balanced + diversity-balanced |
| `run_base_publicTE_pipeline.py` | 01→03→04b→05b→06b 기본 publicTE pipeline runner | 상위 pipeline 결과/설정 | runner 또는 보조 결과 | 실행 보조 |
| `run_heffner_ncbi_mapped_multiomics_pipeline.py` | 09c→09→10 proteomics/multiomics runner | 상위 pipeline 결과/설정 | runner 또는 보조 결과 | 실행 보조 |
| `run_heavy_rnafold_kmer6_automl.py` | heavy RNAfold/k-mer6 model runner | 상위 pipeline 결과/설정 | runner 또는 보조 결과 | 실행 보조 |
| `run_heavy_kmer6_no_rnafold.py` | RNAfold 미설치시 k-mer6 heavy fallback runner | 상위 pipeline 결과/설정 | runner 또는 보조 결과 | 실행 보조 |
| `run_plot_multiomics_distributions.py` | multiomics 분포 QC plot runner | 상위 pipeline 결과/설정 | runner 또는 보조 결과 | 실행 보조 |
| `run_jaccard_cluster_qc.py` | Jaccard cluster QC runner | 상위 pipeline 결과/설정 | runner 또는 보조 결과 | 실행 보조 |
| `run_cluster_aware_classification_benchmark.py` | cluster-aware benchmark runner | 상위 pipeline 결과/설정 | runner 또는 보조 결과 | 실행 보조 |
| `run_select_2000_cluster_diverse_library.py` | 최종 2000개 선별 runner | 상위 pipeline 결과/설정 | runner 또는 보조 결과 | 실행 보조 |
| `run_jaccard_2000_full_pipeline.py` | Jaccard QC→cluster-aware benchmark→2000개 선별 통합 runner | 상위 pipeline 결과/설정 | runner 또는 보조 결과 | 실행 보조 |
