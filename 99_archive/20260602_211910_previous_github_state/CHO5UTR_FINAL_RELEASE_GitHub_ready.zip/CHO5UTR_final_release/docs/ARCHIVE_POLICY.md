# ARCHIVE POLICY

## 원칙
삭제하지 않는다. 최종본에 필요 없는 시행착오 스크립트는 `99_archive/final_cleanup_<timestamp>/scripts_old/`로 이동한다.

## 최종 scripts에 남길 allowlist
- `common.py`
- `00_check_inputs.py`
- `00_download_all_databases.py`
- `01_build_utr_database.py`
- `02_tss_correction.py`
- `03_map_rna_ribo_robust_public_te.py`
- `04b_extract_features_train_40_200bp.py`
- `05b_model_train_40_200bp.py`
- `06b_select_1000_50_100bp_from_40_200train.py`
- `09c_preprocess_heffner_with_ncbi_gene_mapping.py`
- `09_integrate_proteomics_multiomics.py`
- `10_model_multiomics_40_200bp.py`
- `18_heavy_rnafold_kmer6_automl.py`
- `21_plot_multiomics_distributions.py`
- `22_jaccard_sequence_cluster_qc.py`
- `23_cluster_aware_classification_benchmark.py`
- `24_select_2000_cluster_diverse_library.py`
- `run_base_publicTE_pipeline.py`
- `run_heffner_ncbi_mapped_multiomics_pipeline.py`
- `run_heavy_rnafold_kmer6_automl.py`
- `run_heavy_kmer6_no_rnafold.py`
- `run_plot_multiomics_distributions.py`
- `run_jaccard_cluster_qc.py`
- `run_cluster_aware_classification_benchmark.py`
- `run_select_2000_cluster_diverse_library.py`
- `run_jaccard_2000_full_pipeline.py`

## archive 후보
- `*_patch.py`, `*_old.py`, `*_backup.py`, `test_*.py`, `debug_*.py`
- v1/v2/v3 시행착오 스크립트
- NatureComm external validation은 main final pipeline에는 필요 없으므로 선택적으로 `99_archive/optional_external_validation/`에 보관
- 과거 1000개 선별용 script는 fallback 목적 외에는 main 실행에서 제외

## 실행
```bash
python tools/finalize_repo.py --dry-run
python tools/finalize_repo.py --apply
```
