#!/usr/bin/env python3
"""Safe final cleanup utility for CHO5UTR repo.

It moves non-final scripts to 99_archive instead of deleting them.
Run with --dry-run first.
"""
from pathlib import Path
from datetime import datetime
import argparse, shutil, json

ROOT = Path.cwd()
SCRIPTS = ROOT / "01_pipeline" / "scripts"
ARCHIVE_ROOT = ROOT / "99_archive"
KEEP = set([
  "common.py",
  "00_check_inputs.py",
  "00_download_all_databases.py",
  "01_build_utr_database.py",
  "02_tss_correction.py",
  "03_map_rna_ribo_robust_public_te.py",
  "04b_extract_features_train_40_200bp.py",
  "05b_model_train_40_200bp.py",
  "06b_select_1000_50_100bp_from_40_200train.py",
  "09c_preprocess_heffner_with_ncbi_gene_mapping.py",
  "09_integrate_proteomics_multiomics.py",
  "10_model_multiomics_40_200bp.py",
  "18_heavy_rnafold_kmer6_automl.py",
  "21_plot_multiomics_distributions.py",
  "22_jaccard_sequence_cluster_qc.py",
  "23_cluster_aware_classification_benchmark.py",
  "24_select_2000_cluster_diverse_library.py",
  "run_base_publicTE_pipeline.py",
  "run_heffner_ncbi_mapped_multiomics_pipeline.py",
  "run_heavy_rnafold_kmer6_automl.py",
  "run_heavy_kmer6_no_rnafold.py",
  "run_plot_multiomics_distributions.py",
  "run_jaccard_cluster_qc.py",
  "run_cluster_aware_classification_benchmark.py",
  "run_select_2000_cluster_diverse_library.py",
  "run_jaccard_2000_full_pipeline.py"
])
OPTIONAL_KEEP_PREFIXES = {}

# Optional external validation scripts are useful but not required for final library generation.
OPTIONAL_ARCHIVE = {
    "19_download_naturecomm_2021_data.py",
    "20_validate_CHO_model_on_naturecomm_2021.py",
    "run_naturecomm_validation.py",
    "run_naturecomm_inspect.py",
}

REQUIRED_DIRS = [
    "00_raw_data/01_ncbi_genome_annotation",
    "00_raw_data/02_tss_atlas_picr3",
    "00_raw_data/03_gse79512_rna_ribo",
    "00_raw_data/04_reference_controls",
    "00_raw_data/05_cho_proteomics/ncbi_gene_mapping",
    "01_pipeline/config",
    "01_pipeline/scripts",
    "02_utr_database/tables", "02_utr_database/fasta", "02_utr_database/qc",
    "03_tss_correction/tables", "03_tss_correction/fasta", "03_tss_correction/qc",
    "04_te_labeling/tables", "04_te_labeling/qc",
    "05_feature_extraction/tables", "05_feature_extraction/rnafold", "05_feature_extraction/qc",
    "06_modeling/tables", "06_modeling/models", "06_modeling/plots",
    "07_library_design/tables", "07_library_design/fasta", "07_library_design/qc",
    "08_reports", "docs", "tools", "99_archive",
]

def ensure_dirs(apply: bool):
    for d in REQUIRED_DIRS:
        p = ROOT / d
        print(("CREATE" if not p.exists() else "OK"), p)
        if apply:
            p.mkdir(parents=True, exist_ok=True)
            gitkeep = p / ".gitkeep"
            if not gitkeep.exists() and any(x in d for x in ["tables","fasta","qc","models","plots"]):
                gitkeep.write_text("")

def classify_script(p: Path):
    name = p.name
    if name in KEEP:
        return "keep"
    if name in OPTIONAL_ARCHIVE:
        return "archive_optional_external_validation"
    if name.startswith("__") or name.endswith(".pyc") or "__pycache__" in str(p):
        return "archive_cache"
    if name.endswith(".py"):
        return "archive_nonfinal_script"
    return "keep_non_py"

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--apply", action="store_true", help="Actually move files. Without this, dry-run only.")
    ap.add_argument("--include-optional", action="store_true", help="Keep NatureComm optional validation scripts in scripts folder.")
    args = ap.parse_args()
    apply = args.apply
    print("MODE:", "APPLY" if apply else "DRY-RUN")
    ensure_dirs(apply)
    if not SCRIPTS.exists():
        raise SystemExit(f"Scripts folder not found: {SCRIPTS}")
    ts = datetime.now().strftime("%Y%m%d_%H%M%S")
    archive = ARCHIVE_ROOT / f"final_cleanup_{ts}" / "scripts_old"
    moves = []
    for p in sorted(SCRIPTS.rglob("*")):
        if p.is_dir():
            continue
        rel = p.relative_to(SCRIPTS)
        if "__pycache__" in rel.parts:
            action = "archive_cache"
        else:
            action = classify_script(p)
        if args.include_optional and action == "archive_optional_external_validation":
            action = "keep_optional"
        if action.startswith("archive"):
            dest = archive / rel
            moves.append((p, dest, action))
        else:
            print("KEEP", rel, action)
    for src, dest, action in moves:
        print("ARCHIVE", src.relative_to(ROOT), "->", dest.relative_to(ROOT), action)
        if apply:
            dest.parent.mkdir(parents=True, exist_ok=True)
            shutil.move(str(src), str(dest))
    print(f"\nSummary: {len(moves)} files would be archived." if not apply else f"\nSummary: {len(moves)} files archived.")
    print("Final scripts kept:")
    for n in sorted(KEEP): print(" -", n)

if __name__ == "__main__":
    main()
