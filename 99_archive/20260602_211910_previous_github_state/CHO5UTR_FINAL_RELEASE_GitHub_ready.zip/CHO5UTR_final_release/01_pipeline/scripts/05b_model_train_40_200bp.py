from pathlib import Path
import json, warnings
import numpy as np
import pandas as pd
import joblib
import matplotlib.pyplot as plt
from scipy.stats import spearmanr, pearsonr
from sklearn.model_selection import train_test_split
from sklearn.pipeline import Pipeline
from sklearn.impute import SimpleImputer
from sklearn.ensemble import ExtraTreesRegressor, RandomForestRegressor, HistGradientBoostingRegressor, ExtraTreesClassifier, RandomForestClassifier, HistGradientBoostingClassifier
from sklearn.metrics import r2_score, mean_squared_error, mean_absolute_error, roc_auc_score, average_precision_score

warnings.filterwarnings("ignore")

BASE = Path.cwd()
cfg = json.loads((BASE / "01_pipeline/config/project_config.json").read_text(encoding="utf-8"))
mcfg = cfg["modeling"]

IN_CSV = BASE / "05_feature_extraction/tables/ml_feature_table_train_40_200bp.csv"
COLS = BASE / "05_feature_extraction/tables/ml_feature_columns_train_40_200bp.txt"
OUT = BASE / "06_modeling"

for d in ["tables", "models", "plots"]:
    (OUT / d).mkdir(parents=True, exist_ok=True)

def reg_model(name, rs):
    if name == "ExtraTrees":
        return Pipeline([("imp", SimpleImputer(strategy="median")),
                         ("model", ExtraTreesRegressor(n_estimators=1000, max_features="sqrt", min_samples_leaf=5, random_state=rs, n_jobs=-1))])
    if name == "RandomForest":
        return Pipeline([("imp", SimpleImputer(strategy="median")),
                         ("model", RandomForestRegressor(n_estimators=1000, max_features="sqrt", min_samples_leaf=5, random_state=rs, n_jobs=-1))])
    if name == "HistGradientBoosting":
        return Pipeline([("imp", SimpleImputer(strategy="median")),
                         ("model", HistGradientBoostingRegressor(max_iter=600, learning_rate=0.04, max_leaf_nodes=31, l2_regularization=0.03, random_state=rs))])
    raise ValueError(name)

def clf_model(name, rs):
    if name == "ExtraTrees":
        return Pipeline([("imp", SimpleImputer(strategy="median")),
                         ("model", ExtraTreesClassifier(n_estimators=1000, max_features="sqrt", min_samples_leaf=5, random_state=rs, n_jobs=-1, class_weight="balanced"))])
    if name == "RandomForest":
        return Pipeline([("imp", SimpleImputer(strategy="median")),
                         ("model", RandomForestClassifier(n_estimators=1000, max_features="sqrt", min_samples_leaf=5, random_state=rs, n_jobs=-1, class_weight="balanced"))])
    if name == "HistGradientBoosting":
        return Pipeline([("imp", SimpleImputer(strategy="median")),
                         ("model", HistGradientBoostingClassifier(max_iter=600, learning_rate=0.04, max_leaf_nodes=31, l2_regularization=0.03, random_state=rs))])
    raise ValueError(name)

def metric_dict(y, p):
    out = {
        "spearman": spearmanr(y, p).correlation if len(y) >= 3 else np.nan,
        "pearson": pearsonr(y, p)[0] if len(y) >= 3 else np.nan,
        "r2": r2_score(y, p),
        "rmse": float(np.sqrt(mean_squared_error(y, p))),
        "mae": float(mean_absolute_error(y, p)),
    }
    for frac in mcfg.get("topk_fracs", [0.05, 0.1, 0.2]):
        k = max(1, int(len(y) * frac))
        top = np.argsort(p)[-k:]
        thr = np.quantile(y, 1 - frac)
        out[f"top{int(frac*100)}_enrichment"] = float(np.mean(y[top] >= thr))
    return out

def split_idx(df, mode):
    rs = int(mcfg.get("random_state", 42))
    ts = float(mcfg.get("test_size", 0.2))
    if mode == "random":
        idx = np.arange(len(df))
        return train_test_split(idx, test_size=ts, random_state=rs)
    gcol = mcfg.get("gene_group_column", "gene_name")
    groups = df[gcol].astype(str).fillna("NA").values if gcol in df.columns else df["utr_id"].astype(str).values
    uniq = np.array(sorted(pd.unique(groups)))
    tr_g, te_g = train_test_split(uniq, test_size=ts, random_state=rs)
    return np.where(np.isin(groups, tr_g))[0], np.where(np.isin(groups, te_g))[0]

print("[1] Load 40-200 bp feature table")
df = pd.read_csv(IN_CSV)
feats = [x.strip() for x in COLS.read_text(encoding="utf-8").splitlines() if x.strip()]
feats = [c for c in feats if c in df.columns]
target = mcfg.get("target_rank_column", "robust_public_te_rank")

df = df[pd.to_numeric(df[target], errors="coerce").notna()].reset_index(drop=True)
X = df[feats].apply(pd.to_numeric, errors="coerce")
y = pd.to_numeric(df[target], errors="coerce").values
rs = int(mcfg.get("random_state", 42))

print("rows:", len(df), "features:", len(feats), "target:", target)
print("50-100 rows inside training table:", df["utr5_length"].between(50,100).sum())

rows = []
best = None
for mode in ["random", "gene_split"]:
    tr, te = split_idx(df, mode)
    for name in mcfg.get("models", ["ExtraTrees", "RandomForest", "HistGradientBoosting"]):
        print("[REG]", mode, name)
        mod = reg_model(name, rs)
        mod.fit(X.iloc[tr], y[tr])
        pred = np.clip(mod.predict(X.iloc[te]), 0, 1)
        met = metric_dict(y[te], pred)
        row = {"task": "regression", "training_window": "40_200bp", "split_mode": mode, "model": name, "n_train": len(tr), "n_test": len(te), **met}
        rows.append(row)
        print({k: round(v,4) if isinstance(v, float) else v for k,v in row.items() if k in ["split_mode","model","spearman","pearson","top10_enrichment","top20_enrichment"]})
        if mode == "gene_split" and (best is None or met["spearman"] > best["spearman"]):
            best = {"model_name": name, "model": mod, "spearman": met["spearman"], "test_idx": te, "pred": pred}

reg_results = pd.DataFrame(rows)
reg_results.to_csv(OUT / "tables/rank_regression_results_train_40_200bp.csv", index=False)

# classification top vs bottom on wider training set
class_rows = []
qpos = float(mcfg.get("classification_positive_quantile", 0.80))
qneg = float(mcfg.get("classification_negative_quantile", 0.30))
hi = np.quantile(y, qpos)
lo = np.quantile(y, qneg)
cls = df[(df[target] >= hi) | (df[target] <= lo)].copy()
cls["class_y"] = (cls[target] >= hi).astype(int)

if cls["class_y"].nunique() == 2 and len(cls) > 100:
    Xc = cls[feats].apply(pd.to_numeric, errors="coerce")
    yc = cls["class_y"].values
    for mode in ["random", "gene_split"]:
        if mode == "random":
            idx = np.arange(len(cls))
            tr, te = train_test_split(idx, test_size=float(mcfg.get("test_size", 0.2)), random_state=rs, stratify=yc)
        else:
            gcol = mcfg.get("gene_group_column", "gene_name")
            groups = cls[gcol].astype(str).values if gcol in cls.columns else cls["utr_id"].astype(str).values
            uniq = np.array(sorted(pd.unique(groups)))
            tr_g, te_g = train_test_split(uniq, test_size=float(mcfg.get("test_size", 0.2)), random_state=rs)
            tr = np.where(np.isin(groups, tr_g))[0]
            te = np.where(np.isin(groups, te_g))[0]
        for name in mcfg.get("models", ["ExtraTrees", "RandomForest", "HistGradientBoosting"]):
            print("[CLF]", mode, name)
            cm = clf_model(name, rs)
            cm.fit(Xc.iloc[tr], yc[tr])
            pp = cm.predict_proba(Xc.iloc[te])[:, 1]
            class_rows.append({
                "task": "classification",
                "training_window": "40_200bp",
                "split_mode": mode,
                "model": name,
                "n_train": len(tr),
                "n_test": len(te),
                "roc_auc": roc_auc_score(yc[te], pp),
                "average_precision": average_precision_score(yc[te], pp),
            })

clf_results = pd.DataFrame(class_rows)
clf_results.to_csv(OUT / "tables/top_bottom_classification_results_train_40_200bp.csv", index=False)

# final regression model on all 40-200 data, predictions for all rows including 50-100
final = reg_model(best["model_name"], rs)
final.fit(X, y)
all_pred = np.clip(final.predict(X), 0, 1)

pred_df = df[[c for c in [
    "utr_id", "gene_name", "utr5_sequence_tss_corrected", "utr5_length",
    "log2_te_mean_norm", target, "mean_TE_rank", "day_consensus_TE_rank",
    "residual_TE_rank", "ribo_abundance_rank", "tss_confidence_score", "tss_confidence"
] if c in df.columns]].copy()
pred_df["model_pred_rank_40_200train"] = all_pred
pred_df.to_csv(OUT / "tables/all_candidates_40_200train_model_predictions.csv", index=False)

te = best["test_idx"]
test_pred = df.iloc[te][[c for c in ["utr_id", "gene_name", "utr5_sequence_tss_corrected", "utr5_length", target] if c in df.columns]].copy()
test_pred["y_true_rank"] = y[te]
test_pred["y_pred_rank"] = best["pred"]
test_pred.to_csv(OUT / "tables/best_model_holdout_predictions_train_40_200bp.csv", index=False)

joblib.dump(
    {"model": final, "feature_cols": feats, "target": target, "model_name": best["model_name"], "config": cfg, "training_window": "40_200bp"},
    OUT / "models/best_rank_regression_model_train_40_200bp.joblib"
)

plt.figure(figsize=(6, 6))
plt.scatter(test_pred["y_true_rank"], test_pred["y_pred_rank"], s=14, alpha=0.35)
plt.plot([0, 1], [0, 1], linestyle="--")
sp = spearmanr(test_pred["y_true_rank"], test_pred["y_pred_rank"]).correlation
pr = pearsonr(test_pred["y_true_rank"], test_pred["y_pred_rank"])[0]
plt.text(.05, .95, f"Spearman={sp:.3f}\nPearson={pr:.3f}\nn={len(test_pred):,}", transform=plt.gca().transAxes, va="top")
plt.xlabel("True robust public TE rank")
plt.ylabel("Predicted rank")
plt.title("40–200 bp training model: predicted vs true rank")
plt.tight_layout()
plt.savefig(OUT / "plots/best_rank_pred_vs_true_rank_train_40_200bp.png", dpi=200)
plt.close()

summary = [
    "40–200 bp training / 50–100 bp selection modeling summary",
    "=" * 80,
    f"Best regression model: {best['model_name']}",
    f"Gene-split Spearman: {sp:.4f}",
    f"Gene-split Pearson: {pr:.4f}",
    "",
    "Regression results:",
    reg_results.to_string(index=False),
    "",
    "Classification results:",
    clf_results.to_string(index=False) if len(clf_results) else "No classification results.",
]
(OUT / "tables/modeling_summary_train_40_200bp.txt").write_text("\n".join(summary), encoding="utf-8")

print("[SAVED]", OUT / "tables/modeling_summary_train_40_200bp.txt")
