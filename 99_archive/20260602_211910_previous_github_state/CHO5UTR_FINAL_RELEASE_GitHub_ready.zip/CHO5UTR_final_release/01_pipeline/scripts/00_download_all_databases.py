from pathlib import Path
import subprocess
import sys
import shutil

BASE = Path.cwd()

URLS = [
    ("00_raw_data/01_ncbi_genome_annotation/GCF_003668045.1_CriGri-PICR_genomic.fna.gz",
     "https://ftp.ncbi.nlm.nih.gov/genomes/all/GCF/003/668/045/GCF_003668045.1_CriGri-PICR/GCF_003668045.1_CriGri-PICR_genomic.fna.gz"),
    ("00_raw_data/01_ncbi_genome_annotation/GCF_003668045.1_CriGri-PICR_genomic.gff.gz",
     "https://ftp.ncbi.nlm.nih.gov/genomes/all/GCF/003/668/045/GCF_003668045.1_CriGri-PICR/GCF_003668045.1_CriGri-PICR_genomic.gff.gz"),
    ("00_raw_data/02_tss_atlas_picr3/GSE159044_eTSS_NCBI_picr.bed.gz",
     "https://ftp.ncbi.nlm.nih.gov/geo/series/GSE159nnn/GSE159044/suppl/GSE159044_eTSS_NCBI_picr.bed.gz"),
    ("00_raw_data/02_tss_atlas_picr3/GSE159044_eTSS_NCBI_picr.meta.tsv.gz",
     "https://ftp.ncbi.nlm.nih.gov/geo/series/GSE159nnn/GSE159044/suppl/GSE159044_eTSS_NCBI_picr.meta.tsv.gz"),
    ("00_raw_data/03_gse79512_rna_ribo/GSE79512_RNASeq_rawCount.txt.gz",
     "https://ftp.ncbi.nlm.nih.gov/geo/series/GSE79nnn/GSE79512/suppl/GSE79512_RNASeq_rawCount.txt.gz"),
    ("00_raw_data/03_gse79512_rna_ribo/GSE79512_RiboSeq_rawCount.txt.gz",
     "https://ftp.ncbi.nlm.nih.gov/geo/series/GSE79nnn/GSE79512/suppl/GSE79512_RiboSeq_rawCount.txt.gz"),
    ("00_raw_data/05_cho_proteomics/Heffner_2020_CHO_hamster_proteomics_supp_table1.xlsx",
     "https://static-content.springer.com/esm/art%3A10.1038%2Fs41598-020-72959-8/MediaObjects/41598_2020_72959_MOESM2_ESM.xlsx"),
    ("00_raw_data/05_cho_proteomics/ncbi_gene_mapping/gene2accession.gz",
     "https://ftp.ncbi.nlm.nih.gov/gene/DATA/gene2accession.gz"),
    ("00_raw_data/05_cho_proteomics/ncbi_gene_mapping/gene_info.gz",
     "https://ftp.ncbi.nlm.nih.gov/gene/DATA/gene_info.gz"),
]

def download_one(rel, url):
    out = BASE / rel
    out.parent.mkdir(parents=True, exist_ok=True)
    if out.exists() and out.stat().st_size > 0:
        print("[SKIP exists]", rel, out.stat().st_size)
        return
    if shutil.which("curl"):
        exe = "curl.exe" if sys.platform.startswith("win") else "curl"
        cmd = [exe, "-L", "-C", "-", "-o", str(out), url]
    elif shutil.which("wget"):
        cmd = ["wget", "-c", "-O", str(out), url]
    else:
        raise SystemExit("curl or wget is required.")
    print("[DOWNLOAD]", url)
    subprocess.check_call(cmd)

def main():
    for rel, url in URLS:
        download_one(rel, url)
    print("\nDONE. Downloaded/checked files:")
    for rel, _ in URLS:
        p = BASE / rel
        print(rel, "OK" if p.exists() and p.stat().st_size > 0 else "MISSING", p.stat().st_size if p.exists() else "")

if __name__ == "__main__":
    main()
