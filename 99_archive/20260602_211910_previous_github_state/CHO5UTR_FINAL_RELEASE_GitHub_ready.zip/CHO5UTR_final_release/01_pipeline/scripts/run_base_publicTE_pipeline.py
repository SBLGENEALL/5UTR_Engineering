from pathlib import Path
import subprocess
import sys

steps = [
    "00_check_inputs.py",
    "01_build_utr_database.py",
    "02_tss_correction.py",
    "03_map_rna_ribo_robust_public_te.py",
    "04b_extract_features_train_40_200bp.py",
    "05b_model_train_40_200bp.py",
    "06b_select_1000_50_100bp_from_40_200train.py",
]

script_dir = Path("01_pipeline") / "scripts"
for step in steps:
    print("\n" + "="*80)
    print("RUN", step)
    print("="*80)
    r = subprocess.run([sys.executable, str(script_dir / step)])
    if r.returncode != 0:
        raise SystemExit(f"FAILED: {step}")
print("\nDONE: base public-TE pipeline completed.")
