from pathlib import Path
from itertools import product
from collections import Counter
import subprocess, json, re
import pandas as pd
import numpy as np
from common import clean_seq, gc_content, ensure_dir

BASE = Path.cwd()
cfg = json.loads((BASE / "01_pipeline/config/project_config.json").read_text(encoding="utf-8"))

IN_LABEL = BASE / "04_te_labeling/tables/tss_corrected_5utr_robust_public_te_labels.csv"
OUT = BASE / "05_feature_extraction/tables/ml_feature_table_train_40_200bp.csv"
COLS = BASE / "05_feature_extraction/tables/ml_feature_columns_train_40_200bp.txt"
QC = BASE / "05_feature_extraction/qc/train_40_200bp_filter_summary.txt"
ensure_dir(OUT.parent)
ensure_dir(QC.parent)

SEQ = "utr5_sequence_tss_corrected"
fcfg = cfg["feature_extraction"]

TRAIN_MIN = 40
TRAIN_MAX = 200
GC_MIN = 0.30
GC_MAX = 0.75
UAUG_MAX = 1

def base_frac(seq, b):
    seq = clean_seq(seq)
    return seq.count(b) / len(seq) if len(seq) else 0

def longest_run(seq, b):
    best = cur = 0
    for x in clean_seq(seq):
        if x == b:
            cur += 1
            best = max(best, cur)
        else:
            cur = 0
    return best

def count_uorf(seq):
    seq = clean_seq(seq)
    stops = {"TAA", "TAG", "TGA"}
    n = 0
    longest = 0
    for i in range(max(0, len(seq)-2)):
        if seq[i:i+3] == "ATG":
            for j in range(i+3, len(seq)-2, 3):
                if seq[j:j+3] in stops:
                    n += 1
                    longest = max(longest, j+3-i)
                    break
    return n, longest

def kmer_freq(seq, k, prefix):
    seq = clean_seq(seq)
    kmers = ["".join(x) for x in product("ACGT", repeat=k)]
    cnt = Counter(seq[i:i+k] for i in range(max(0, len(seq)-k+1)) if set(seq[i:i+k]) <= set("ACGT"))
    tot = sum(cnt.values())
    return {f"{prefix}{k}mer_{km}": (cnt.get(km, 0) / tot if tot else 0) for km in kmers}

def rnafold(seq, exe):
    try:
        p = subprocess.run([exe, "--noPS"], input=seq+"\n", text=True, capture_output=True, timeout=20)
        if p.returncode != 0:
            return np.nan
        lines = p.stdout.strip().splitlines()
        if len(lines) < 2:
            return np.nan
        m = re.search(r'\(([-+]?\d+\.?\d*)\)', lines[1])
        return float(m.group(1)) if m else np.nan
    except Exception:
        return np.nan

print("[1] Load robust public TE labels:", IN_LABEL)
df0 = pd.read_csv(IN_LABEL)
df0[SEQ] = df0[SEQ].apply(clean_seq)

# Use wider training window but preserve final selection as 50-100 in later script.
df0["length_for_filter"] = df0[SEQ].str.len()
if "gc_content" not in df0.columns:
    df0["gc_content"] = df0[SEQ].apply(gc_content)
if "uaug_count" not in df0.columns:
    df0["uaug_count"] = df0[SEQ].str.count("ATG")

mask = (
    df0["length_for_filter"].between(TRAIN_MIN, TRAIN_MAX)
    & df0["robust_public_te_rank"].notna()
    & df0["gc_content"].between(GC_MIN, GC_MAX)
    & (df0["uaug_count"] <= UAUG_MAX)
    & (~df0[SEQ].str.contains("N", regex=False))
)

# Keep only rows with public omics support when columns exist.
if "has_rna_label" in df0.columns:
    mask &= df0["has_rna_label"].astype(bool)
if "has_ribo_label" in df0.columns:
    mask &= df0["has_ribo_label"].astype(bool)

df = df0[mask].copy().reset_index(drop=True)

summary = []
summary.append("40-200 bp training-set filter summary")
summary.append("=" * 70)
summary.append(f"input_rows: {len(df0)}")
summary.append(f"train_40_200_rows: {len(df)}")
summary.append(f"50_100_rows_within_train: {df['length_for_filter'].between(50,100).sum()}")
summary.append("")
summary.append("Length distribution:")
summary.append(df["length_for_filter"].describe().to_string())
summary.append("")
summary.append("Robust public TE rank distribution:")
summary.append(df["robust_public_te_rank"].describe().to_string())
QC.write_text("\n".join(summary), encoding="utf-8")
print("\n".join(summary))

records = []
for i, seq in enumerate(df[SEQ]):
    L = len(seq)
    r = {}
    r["utr5_length"] = L
    r["gc_content"] = gc_content(seq)

    for b in "ACGT":
        r[f"{b.lower()}_fraction"] = base_frac(seq, b)
        r[f"poly{b}_max_run"] = longest_run(seq, b)

    r["uaug_count"] = seq.count("ATG")
    uorf, long = count_uorf(seq)
    r["uorf_count"] = uorf
    r["longest_uorf_len"] = long
    r["cpg_count"] = seq.count("CG")
    r["first_aug_pos"] = seq.find("ATG")
    r["aug_density"] = r["uaug_count"] / L if L else 0

    for w in fcfg.get("position_windows", [30, 50]):
        head = seq[:w]
        tail = seq[-w:] if L >= w else seq
        r[f"head{w}_gc"] = gc_content(head)
        r[f"tail{w}_gc"] = gc_content(tail)
        r[f"head{w}_uaug_count"] = head.count("ATG")
        r[f"tail{w}_uaug_count"] = tail.count("ATG")
        for k in fcfg.get("position_kmers", [3, 4]):
            r.update(kmer_freq(head, k, f"head{w}_"))
            r.update(kmer_freq(tail, k, f"tail{w}_"))

    for k in fcfg.get("global_kmers", [3, 4, 5]):
        r.update(kmer_freq(seq, k, "global_"))

    if fcfg.get("run_rnafold", False):
        exe = fcfg.get("rnafold_executable", "RNAfold")
        mfe = rnafold(seq, exe)
        r["mfe_full"] = mfe
        r["mfe_per_nt"] = mfe / L if L and pd.notna(mfe) else np.nan
        for w in fcfg.get("position_windows", [30, 50]):
            head = seq[:w]
            tail = seq[-w:] if L >= w else seq
            hm = rnafold(head, exe)
            tm = rnafold(tail, exe)
            r[f"mfe_head{w}"] = hm
            r[f"mfe_head{w}_per_nt"] = hm / len(head) if len(head) and pd.notna(hm) else np.nan
            r[f"mfe_tail{w}"] = tm
            r[f"mfe_tail{w}_per_nt"] = tm / len(tail) if len(tail) and pd.notna(tm) else np.nan

    records.append(r)
    if (i + 1) % 1000 == 0:
        print(f"processed {i+1:,}/{len(df):,}")

feat = pd.DataFrame(records)

meta = [c for c in [
    "utr_id", "gene_id", "gene_name", "transcript_id", "seqname", "strand", SEQ,
    "log2_te_mean_norm", "robust_public_te_score", "robust_public_te_rank",
    "mean_TE_rank", "day_consensus_TE_rank", "residual_TE_rank",
    "ribo_abundance_rank", "tss_confidence_score", "tss_confidence"
] if c in df.columns]

out = pd.concat([df[meta].reset_index(drop=True), feat.reset_index(drop=True)], axis=1)
out.to_csv(OUT, index=False)
COLS.write_text("\n".join(feat.columns), encoding="utf-8")

print("[SAVED]", OUT, out.shape)
print("[SAVED]", COLS, len(feat.columns))
print("[SAVED]", QC)
