from pathlib import Path
import subprocess
import sys

steps = [
    "09b_download_ncbi_gene_mapping.py",
    "09c_preprocess_heffner_with_ncbi_gene_mapping.py",
    "09_integrate_proteomics_multiomics.py",
    "10_model_multiomics_40_200bp.py",
    "11_select_1000_multiomics_proteomics_library.py",
]

script_dir = Path("01_pipeline") / "scripts"
for step in steps:
    print("\n" + "=" * 80)
    print("RUN", step)
    print("=" * 80)
    r = subprocess.run([sys.executable, str(script_dir / step)])
    if r.returncode != 0:
        raise SystemExit(f"FAILED: {step}")

print("\nDONE: Heffner NCBI-mapped proteomics multi-omics pipeline completed.")
