from pathlib import Path
import json

BASE = Path.cwd()
cfg = json.loads((BASE/"01_pipeline/config/project_config.json").read_text(encoding="utf-8"))
print("=== INPUT CHECK ===")
ok = True
for k,v in cfg["paths"].items():
    required = k != "tss_meta_file"
    p = BASE / v
    status = "OK" if p.exists() and p.stat().st_size > 0 else ("OPTIONAL_MISSING" if not required else "MISSING")
    print(f"{k:18s} {status:18s} {p}")
    if required and status == "MISSING":
        ok = False
extra = [
    "00_raw_data/05_cho_proteomics/Heffner_2020_CHO_hamster_proteomics_supp_table1.xlsx",
    "00_raw_data/05_cho_proteomics/ncbi_gene_mapping/gene2accession.gz",
    "00_raw_data/05_cho_proteomics/ncbi_gene_mapping/gene_info.gz",
]
print("\nProteomics/mapping:")
for rel in extra:
    p = BASE/rel
    status = "OK" if p.exists() and p.stat().st_size > 0 else "MISSING"
    print(f"{status:18s} {p}")
if ok:
    print("\nPASS")
else:
    raise SystemExit("\nERROR: required inputs missing")
