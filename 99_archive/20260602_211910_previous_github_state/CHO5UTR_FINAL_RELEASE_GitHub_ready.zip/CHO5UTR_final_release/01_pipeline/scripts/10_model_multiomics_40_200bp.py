from __future__ import annotations

from pathlib import Path
import json
import math
import warnings

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import joblib

from scipy.stats import spearmanr, pearsonr
from sklearn.model_selection import train_test_split
from sklearn.pipeline import Pipeline
from sklearn.impute import SimpleImputer
from sklearn.ensemble import ExtraTreesRegressor, RandomForestRegressor, HistGradientBoostingRegressor
from sklearn.metrics import r2_score, mean_squared_error, mean_absolute_error

warnings.filterwarnings("ignore")

BASE = Path.cwd()
FEATURE_PATH = BASE / "05_feature_extraction/tables/ml_feature_table_train_40_200bp.csv"
FEATURE_COLS_PATH = BASE / "05_feature_extraction/tables/ml_feature_columns_train_40_200bp.txt"
MULTIOMICS_LABEL = BASE / "04_te_labeling/tables/tss_corrected_5utr_multiomics_labels.csv"

OUT = BASE / "06_modeling"
for d in ["tables", "models", "plots"]:
    (OUT / d).mkdir(parents=True, exist_ok=True)

TARGET = "multi_omics_utr_rank"


def make_model(name, rs=42):
    if name == "ExtraTrees":
        return Pipeline([
            ("imputer", SimpleImputer(strategy="median")),
            ("model", ExtraTreesRegressor(n_estimators=1000, max_features="sqrt", min_samples_leaf=5, random_state=rs, n_jobs=-1)),
        ])
    if name == "RandomForest":
        return Pipeline([
            ("imputer", SimpleImputer(strategy="median")),
            ("model", RandomForestRegressor(n_estimators=1000, max_features="sqrt", min_samples_leaf=5, random_state=rs, n_jobs=-1)),
        ])
    if name == "HistGradientBoosting":
        return Pipeline([
            ("imputer", SimpleImputer(strategy="median")),
            ("model", HistGradientBoostingRegressor(max_iter=600, learning_rate=0.04, max_leaf_nodes=31, l2_regularization=0.03, random_state=rs)),
        ])
    raise ValueError(name)


def split_idx(df, mode, rs=42, test_size=0.2):
    if mode == "random":
        idx = np.arange(len(df))
        return train_test_split(idx, test_size=test_size, random_state=rs)
    groups = df["gene_name"].astype(str).fillna("NA").values if "gene_name" in df.columns else df["utr_id"].astype(str).values
    unique = np.array(sorted(pd.unique(groups)))
    tr_g, te_g = train_test_split(unique, test_size=test_size, random_state=rs)
    return np.where(np.isin(groups, tr_g))[0], np.where(np.isin(groups, te_g))[0]


def metrics(y, p):
    out = {
        "spearman": spearmanr(y, p).correlation if len(y) >= 3 else np.nan,
        "pearson": pearsonr(y, p)[0] if len(y) >= 3 else np.nan,
        "r2": r2_score(y, p),
        "rmse": float(math.sqrt(mean_squared_error(y, p))),
        "mae": float(mean_absolute_error(y, p)),
    }
    for frac in [0.05, 0.10, 0.20]:
        k = max(1, int(len(y) * frac))
        top = np.argsort(p)[-k:]
        thr = np.quantile(y, 1 - frac)
        out[f"top{int(frac*100)}_enrichment"] = float(np.mean(y[top] >= thr))
    return out


def main():
    if not FEATURE_PATH.exists():
        raise SystemExit(
            f"Missing feature table: {FEATURE_PATH}\n"
            "Run 40-200 feature extraction first, e.g.\n"
            "python 01_pipeline/scripts/04b_extract_features_train_40_200bp.py"
        )
    if not MULTIOMICS_LABEL.exists():
        raise SystemExit(
            f"Missing multi-omics label table: {MULTIOMICS_LABEL}\n"
            "Run:\n"
            "python 01_pipeline/scripts/09_integrate_proteomics_multiomics.py"
        )

    print("[1] Load 40-200 feature table")
    feat = pd.read_csv(FEATURE_PATH)
    feature_cols = [x.strip() for x in FEATURE_COLS_PATH.read_text(encoding="utf-8").splitlines() if x.strip()]
    feature_cols = [c for c in feature_cols if c in feat.columns]

    print("[2] Load multi-omics labels")
    lab = pd.read_csv(MULTIOMICS_LABEL)
    keep = ["utr_id", TARGET, "protein_abundance_rank", "protein_residual_rank", "multi_omics_utr_score", "has_proteomics_label"]
    keep = [c for c in keep if c in lab.columns]
    df = feat.merge(lab[keep].drop_duplicates("utr_id"), on="utr_id", how="left")
    df = df[pd.to_numeric(df[TARGET], errors="coerce").notna()].reset_index(drop=True)

    X = df[feature_cols].apply(pd.to_numeric, errors="coerce")
    y = pd.to_numeric(df[TARGET], errors="coerce").values

    print("rows:", len(df), "features:", len(feature_cols))
    print("rows with proteomics label:", int(df.get("has_proteomics_label", pd.Series(False, index=df.index)).sum()))

    rs = 42
    rows = []
    best = None

    for split_mode in ["random", "gene_split"]:
        tr, te = split_idx(df, split_mode, rs=rs, test_size=0.2)
        for model_name in ["ExtraTrees", "RandomForest", "HistGradientBoosting"]:
            print("[FIT]", split_mode, model_name)
            m = make_model(model_name, rs)
            m.fit(X.iloc[tr], y[tr])
            pred = np.clip(m.predict(X.iloc[te]), 0, 1)
            met = metrics(y[te], pred)
            row = {"target": TARGET, "split_mode": split_mode, "model": model_name, "n_train": len(tr), "n_test": len(te), **met}
            rows.append(row)
            print("  spearman", round(met["spearman"], 4), "pearson", round(met["pearson"], 4), "top10", round(met["top10_enrichment"], 4))
            if split_mode == "gene_split" and (best is None or met["spearman"] > best["spearman"]):
                best = {"model_name": model_name, "model": m, "spearman": met["spearman"], "test_idx": te, "pred": pred}

    res = pd.DataFrame(rows)
    res_path = OUT / "tables/multiomics_model_results_40_200bp.csv"
    res.to_csv(res_path, index=False)

    # final model
    final = make_model(best["model_name"], rs)
    final.fit(X, y)
    all_pred = np.clip(final.predict(X), 0, 1)

    pred_df = df[[c for c in [
        "utr_id", "gene_name", "utr5_sequence_tss_corrected", "utr5_length",
        "robust_public_te_rank", TARGET, "protein_abundance_rank", "protein_residual_rank",
        "has_proteomics_label"
    ] if c in df.columns]].copy()
    pred_df["multiomics_model_pred_rank"] = all_pred
    pred_path = OUT / "tables/multiomics_model_predictions_40_200bp.csv"
    pred_df.to_csv(pred_path, index=False)

    model_path = OUT / "models/best_multiomics_model_40_200bp.joblib"
    joblib.dump(
        {"model": final, "feature_cols": feature_cols, "target": TARGET, "best": best, "training_window": "40_200bp"},
        model_path,
    )

    te = best["test_idx"]
    yte = y[te]
    pte = best["pred"]

    plt.figure(figsize=(6, 6))
    plt.scatter(yte, pte, s=14, alpha=0.35)
    plt.plot([0, 1], [0, 1], linestyle="--")
    sp = spearmanr(yte, pte).correlation
    pr = pearsonr(yte, pte)[0]
    plt.text(0.05, 0.95, f"Spearman={sp:.3f}\nPearson={pr:.3f}\nn={len(yte):,}", transform=plt.gca().transAxes, va="top")
    plt.xlabel("True multi-omics UTR rank")
    plt.ylabel("Predicted rank")
    plt.title("Multi-omics model: gene-split holdout")
    plt.tight_layout()
    plot_path = OUT / "plots/multiomics_model_pred_vs_true.png"
    plt.savefig(plot_path, dpi=200)
    plt.close()

    summary = [
        "Multi-omics model summary",
        "=" * 80,
        f"Best gene-split model: {best['model_name']}",
        f"Best gene-split Spearman: {sp:.4f}",
        f"Best gene-split Pearson: {pr:.4f}",
        "",
        res.to_string(index=False),
        "",
        f"Saved results: {res_path}",
        f"Saved predictions: {pred_path}",
        f"Saved model: {model_path}",
        f"Saved plot: {plot_path}",
    ]
    summary_path = OUT / "tables/multiomics_model_summary_40_200bp.txt"
    summary_path.write_text("\n".join(summary), encoding="utf-8")

    print("[SAVED]", summary_path)
    print("[SAVED]", pred_path)
    print("[SAVED]", model_path)


if __name__ == "__main__":
    main()
