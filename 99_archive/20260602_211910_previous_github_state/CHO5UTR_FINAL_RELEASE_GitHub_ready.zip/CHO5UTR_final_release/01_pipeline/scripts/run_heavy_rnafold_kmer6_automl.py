import subprocess
import sys

cmd = [
    sys.executable,
    "01_pipeline/scripts/18_heavy_rnafold_kmer6_automl.py",
    "--n-estimators", "2000",
    "--kmax", "6",
    "--top-models", "12",
]
print("RUN", " ".join(cmd))
r = subprocess.run(cmd)
raise SystemExit(r.returncode)
