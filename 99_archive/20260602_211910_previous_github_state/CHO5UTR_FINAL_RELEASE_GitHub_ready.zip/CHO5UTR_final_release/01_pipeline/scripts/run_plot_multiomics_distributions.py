import subprocess, sys
cmd=[sys.executable,"01_pipeline/scripts/21_plot_multiomics_distributions.py"]
print("RUN"," ".join(cmd))
r=subprocess.run(cmd)
raise SystemExit(r.returncode)
