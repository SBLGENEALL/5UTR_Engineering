from pathlib import Path
import json
import pandas as pd
import numpy as np
from common import clean_seq, gc_content, write_fasta, ensure_dir

BASE = Path.cwd()
cfg = json.loads((BASE / "01_pipeline/config/project_config.json").read_text(encoding="utf-8"))
lcfg = cfg["library_design"]

LABEL = BASE / "04_te_labeling/tables/tss_corrected_5utr_robust_public_te_labels.csv"
PRED = BASE / "06_modeling/tables/all_candidates_40_200train_model_predictions.csv"

OUT = BASE / "07_library_design/tables/selected_1000_50_100bp_publicTE_40_200train_model_assisted_library.csv"
FA = BASE / "07_library_design/fasta/selected_1000_50_100bp_publicTE_40_200train_model_assisted_library.fasta"
SUM = BASE / "07_library_design/qc/selected_1000_50_100bp_40_200train_library_summary.txt"

ensure_dir(OUT.parent)
ensure_dir(FA.parent)
ensure_dir(SUM.parent)

SEQ = "utr5_sequence_tss_corrected"

SELECT_MIN = 50
SELECT_MAX = 100
GC_MIN = 0.30
GC_MAX = 0.75
UAUG_MAX = 1

# More conservative quota because 50-100-only model was weak.
quota = {
    "robust_TE_top": 350,
    "day_consensus_high": 200,
    "residual_high_ribo_high": 150,
    "TSS_supported_high": 150,
    "sequence_quality_high_TE": 75,
    "diverse_mid_high": 50,
    "low_TE_negative": 25,
}

def sites(seq):
    seq = clean_seq(seq)
    return ";".join([name for name, site in lcfg["forbidden_sites"].items() if site in seq])

def kmerset(seq, k=8):
    seq = clean_seq(seq)
    return {seq[i:i+k] for i in range(max(0, len(seq)-k+1)) if set(seq[i:i+k]) <= set("ACGT")}

def jac(a, b):
    return len(a & b) / len(a | b) if a or b else 1

def cluster_rep(df, thr=0.90):
    reps = []
    kms = []
    for idx, r in df.iterrows():
        km = kmerset(r[SEQ])
        if all(jac(km, x) < thr for x in kms):
            reps.append(idx)
            kms.append(km)
    return df.loc[reps].copy()

def pick(df, n, sort, group):
    out = df.sort_values(sort, ascending=[False] * len(sort)).head(max(0, n)).copy()
    out["library_group"] = group
    return out

print("[1] Load robust labels")
df = pd.read_csv(LABEL)
df[SEQ] = df[SEQ].apply(clean_seq)

if PRED.exists():
    print("[2] Merge 40-200 trained model predictions")
    p = pd.read_csv(PRED)[["utr_id", "model_pred_rank_40_200train"]].drop_duplicates("utr_id")
    df = df.merge(p, on="utr_id", how="left")
else:
    print("[WARN] 40-200 model prediction file not found. Using robust public TE rank as fallback.")
    df["model_pred_rank_40_200train"] = np.nan

df["model_pred_rank_40_200train"] = df["model_pred_rank_40_200train"].fillna(df["robust_public_te_rank"])
df["length"] = df[SEQ].str.len()
df["gc_content"] = df[SEQ].apply(gc_content)
df["uaug_count"] = df[SEQ].str.count("ATG")
df["forbidden_sites"] = df[SEQ].apply(sites)
df["has_forbidden_site"] = df["forbidden_sites"].astype(str).str.len() > 0

base = df[
    df["length"].between(SELECT_MIN, SELECT_MAX)
    & df["gc_content"].between(GC_MIN, GC_MAX)
    & (df["uaug_count"] <= UAUG_MAX)
    & (~df["has_forbidden_site"])
    & (~df[SEQ].str.contains("N", regex=False))
    & df["robust_public_te_rank"].notna()
].copy()

base["sequence_quality_score"] = (
    base["length"].between(50, 100).astype(int)
    + base["gc_content"].between(0.35, 0.70).astype(int)
    + (base["uaug_count"] == 0).astype(int)
    + (base["tss_confidence"].astype(str) == "tss_supported_with_signal").astype(int)
)

# model is only weak tie-breaker: use small weighted assist score
base["final_selection_score"] = (
    0.70 * base["robust_public_te_rank"].fillna(0)
    + 0.10 * base["day_consensus_TE_rank"].fillna(0)
    + 0.10 * base["residual_TE_rank"].fillna(0)
    + 0.05 * base["ribo_abundance_rank"].fillna(0)
    + 0.05 * base["model_pred_rank_40_200train"].fillna(0)
)

base = base.sort_values(["final_selection_score", "robust_public_te_rank", "sequence_quality_score"], ascending=False).drop_duplicates(subset=[SEQ])
base = cluster_rep(base, float(lcfg.get("seqcluster_jaccard_threshold", 0.90)))

selected = []
used = set()

def avail():
    return base[~base[SEQ].isin(used)].copy()

def add(x):
    selected.append(x)
    used.update(x[SEQ].tolist())

a = pick(avail(), quota["robust_TE_top"], ["robust_public_te_rank", "sequence_quality_score"], "A_robust_TE_top")
add(a)

bpool = avail()
bpool = bpool[bpool["day_consensus_TE_rank"] >= 0.75]
b = pick(bpool, quota["day_consensus_high"], ["day_consensus_TE_rank", "robust_public_te_rank"], "B_day_consensus_high")
add(b)

cpool = avail()
cpool = cpool[(cpool["residual_TE_rank"] >= 0.75) & (cpool["ribo_abundance_rank"] >= 0.60)]
c = pick(cpool, quota["residual_high_ribo_high"], ["residual_TE_rank", "ribo_abundance_rank", "robust_public_te_rank"], "C_residual_high_ribo_high")
add(c)

dpool = avail()
dpool = dpool[(dpool["tss_confidence"].astype(str) == "tss_supported_with_signal") & (dpool["robust_public_te_rank"] >= 0.70)]
d = pick(dpool, quota["TSS_supported_high"], ["robust_public_te_rank", "sequence_quality_score"], "D_TSS_supported_high")
add(d)

epool = avail()
epool = epool[(epool["robust_public_te_rank"] >= 0.65) & (epool["sequence_quality_score"] >= 3)]
e = pick(epool, quota["sequence_quality_high_TE"], ["sequence_quality_score", "robust_public_te_rank"], "E_sequence_quality_high_TE")
add(e)

fpool = avail()
fpool = fpool[fpool["robust_public_te_rank"] >= 0.45]
fpool["len_bin"] = pd.cut(fpool["length"], [49, 60, 70, 80, 90, 100], labels=False)
fpool["gc_bin"] = pd.cut(fpool["gc_content"], [0, 0.4, 0.5, 0.6, 0.75, 1], labels=False)
parts = []
for _, sub in fpool.groupby(["len_bin", "gc_bin"], dropna=True):
    parts.append(sub.sort_values(["final_selection_score", "sequence_quality_score"], ascending=False).head(3))
f = pd.concat(parts) if parts else fpool.head(0)
f = f.drop_duplicates(subset=[SEQ]).head(quota["diverse_mid_high"]).copy()
f["library_group"] = "F_diverse_mid_high"
add(f)

gpool = avail()
gpool = gpool[gpool["robust_public_te_rank"] <= 0.25]
g = pick(gpool, quota["low_TE_negative"], ["sequence_quality_score"], "G_low_TE_negative")
add(g)

out = pd.concat(selected).drop_duplicates(subset=[SEQ]) if selected else base.head(0)

if len(out) < int(lcfg.get("n_total", 1000)):
    extra = avail().sort_values(["final_selection_score", "robust_public_te_rank", "sequence_quality_score"], ascending=False).head(int(lcfg.get("n_total", 1000)) - len(out)).copy()
    extra["library_group"] = "H_fill_remaining"
    out = pd.concat([out, extra])

out = out.head(int(lcfg.get("n_total", 1000))).copy()
out["library_index"] = range(1, len(out) + 1)

front = [c for c in [
    "library_index", "library_group", "utr_id", "gene_name", SEQ, "length", "gc_content",
    "uaug_count", "tss_confidence", "log2_te_mean_norm", "robust_public_te_rank",
    "mean_TE_rank", "day_consensus_TE_rank", "residual_TE_rank", "ribo_abundance_rank",
    "model_pred_rank_40_200train", "final_selection_score", "sequence_quality_score", "forbidden_sites"
] if c in out.columns]

out = out[front + [c for c in out.columns if c not in front]]
out.to_csv(OUT, index=False)
write_fasta(out, FA, SEQ, "utr_id")

summary = [
    "Selected 50–100 bp library summary using 40–200 bp trained model",
    "=" * 80,
    f"Total selected: {len(out)}",
    "",
    "[Group counts]",
    out["library_group"].value_counts().to_string(),
    "",
    "[Length]",
    out["length"].describe().to_string(),
    "",
    "[Robust public TE rank]",
    out["robust_public_te_rank"].describe().to_string(),
    "",
    "[Model prediction rank; weak tie-breaker only]",
    out["model_pred_rank_40_200train"].describe().to_string(),
    "",
    "[uAUG]",
    out["uaug_count"].value_counts().sort_index().to_string(),
]
SUM.write_text("\n".join(summary), encoding="utf-8")

print("[SAVED]", OUT)
print("[SAVED]", FA)
print("[SAVED]", SUM)
print(out["library_group"].value_counts().to_string())
